class MultiQuerySafe:
    def __init__(self, db): self.db = db
    def update_and_fetch(self, tenant, email, status):
        self.db.execute("UPDATE users SET status=? WHERE tenant_id=? AND email=?", [status, tenant, email])
        return self.db.execute("SELECT id,email,status FROM users WHERE tenant_id=? AND email=?", [tenant, email]).fetchone()
