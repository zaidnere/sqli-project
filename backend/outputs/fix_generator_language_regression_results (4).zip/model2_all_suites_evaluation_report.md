# Model 2 All-Suites Evaluation Report

This report consolidates the language-aware fix-generator regression, dedicated Model 2 fix suites, and full pipeline strict evaluation using official Model 1 outputs.

## Full Pipeline Strict
- Model 1 official: 594/594 (100.0%)
- Model 2 classification: 380/385 (98.7%)
- Model 2 final fix type: 380/385 (98.7%)
- Strict generated-fix validation: 379/385 (98.44%)
- Full pipeline strict: 588/594 (98.99%)

## Fix Generator Language Regression
- Passed: 6/6 (100.0%)

## Failure Review
- Total failures: 6
- By stage: `{"model2_fix_classification": 5, "strict_fix_validation": 1}`
- By language: `{"python": 4, "javascript": 2}`
- Failure CSV: `outputs\model2_all_suites_failure_review.csv`
