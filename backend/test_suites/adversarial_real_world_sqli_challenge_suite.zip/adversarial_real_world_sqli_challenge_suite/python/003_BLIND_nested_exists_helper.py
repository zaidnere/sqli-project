def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*args): pass

class Gate:
    def __init__(self, conn): self.conn = conn
    def one(self, sql): return self.conn.execute(sql).fetchone()
    def exists(self, sql): return self.one(sql) is not None
    def allowed(self, args):
        resource = norm(args.get("resource"))
        sql = "SELECT id FROM permissions WHERE actor_id='" + args["actor"] + "' AND resource='" + resource + "'"
        return self.exists(sql)
