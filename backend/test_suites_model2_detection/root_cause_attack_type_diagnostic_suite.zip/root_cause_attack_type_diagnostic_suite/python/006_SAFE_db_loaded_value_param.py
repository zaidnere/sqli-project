def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*a): pass

class SafeDbValue:
    def __init__(self, conn): self.conn = conn
    def load_department(self, user_id):
        row = self.conn.execute("SELECT department_code FROM users WHERE id=?", [int(user_id)]).fetchone()
        return row["department_code"] if row else ""
    def orders(self, request):
        dept = self.load_department(request["user_id"])
        return self.conn.execute("SELECT id FROM orders WHERE tenant_id=? AND department_code=?", [request["tenant"], dept]).fetchall()
