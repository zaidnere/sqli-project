async function listEvents(db, req) {
  const limit = Math.max(1, Math.min(Number(req.query.limit || 50), 100));
  const offset = Math.max(0, Math.min(Number(req.query.offset || 0), 10000));
  const sql = `SELECT id,message FROM events ORDER BY id DESC LIMIT ${limit} OFFSET ${offset}`;
  return db.all(sql);
}
