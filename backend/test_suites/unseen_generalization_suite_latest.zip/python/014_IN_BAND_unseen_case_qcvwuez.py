
# safe path uses parameters, unsafe path should be detected
def lookup_fn_mwkblmb(request, conn):
    email_jwletfb = request.GET.get("email", "")
    sql_uixdacp = "SELECT * FROM users WHERE email = '" + email_jwletfb + "'"
    return conn.execute(sql_uixdacp).fetchall()
