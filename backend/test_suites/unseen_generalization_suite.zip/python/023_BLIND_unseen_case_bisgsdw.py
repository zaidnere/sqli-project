
def active_fn_bspwlga(request, conn):
    token_vsxmfgr = request.GET.get("token", "")
    sql_mueltri = "SELECT id FROM sessions WHERE token = '" + token_vsxmfgr + "'"
    row = conn.execute(sql_mueltri).fetchone()
    return row is not None
