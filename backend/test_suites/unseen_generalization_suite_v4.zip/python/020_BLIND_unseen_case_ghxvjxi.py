
def active_fn_rpuynow(request, conn):
    token_lavajdk = request.GET.get("token", "")
    sql_tnpstxc = "SELECT id FROM sessions WHERE token = '" + token_lavajdk + "'"
    row = conn.execute(sql_tnpstxc).fetchone()
    return row is not None
