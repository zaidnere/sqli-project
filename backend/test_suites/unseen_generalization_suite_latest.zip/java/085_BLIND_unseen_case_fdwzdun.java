
import java.sql.*;
class Authrrwgthb {
  boolean allowed(HttpServletRequest req, Statement st) throws Exception {
    String token = req.getParameter("token");
    String sql = "SELECT id FROM sessions WHERE token='" + token + "'";
    return st.executeQuery(sql).next();
  }
}
