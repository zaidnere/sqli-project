import java.sql.*;
public class SafeDbValueParam {
  private final Connection c; public SafeDbValueParam(Connection c){this.c=c;}
  String status(String tenant)throws SQLException{ PreparedStatement ps=c.prepareStatement("SELECT default_status FROM tenant_settings WHERE tenant_id=?"); ps.setString(1,tenant); ResultSet rs=ps.executeQuery(); return rs.next()?rs.getString("default_status"):"OPEN"; }
  public ResultSet list(String tenant)throws SQLException{ PreparedStatement ps=c.prepareStatement("SELECT id FROM orders WHERE tenant_id=? AND status=?"); ps.setString(1,tenant); ps.setString(2,status(tenant)); return ps.executeQuery(); }
}
