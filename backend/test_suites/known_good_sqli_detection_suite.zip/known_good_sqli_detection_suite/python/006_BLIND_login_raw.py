def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class LoginService:
    def __init__(self, conn):
        self.conn = conn

    def login(self, request):
        email = norm(request.get("email"))
        password = norm(request.get("password"))
        sql = "SELECT id FROM users WHERE email='" + email + "' AND password_hash='" + password + "'"
        row = self.conn.execute(sql).fetchone()
        return row is not None
