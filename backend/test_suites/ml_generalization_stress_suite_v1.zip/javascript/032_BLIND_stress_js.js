class Flags{ constructor(db){this.db=db;} async enabled(req){ const f=String(req.query.feature||"");
 const row=await this.db.get("SELECT COUNT(*) AS c FROM feature_flags WHERE feature_key='"+f+"'"); return row&&row.c>0; } }
module.exports=Flags;
