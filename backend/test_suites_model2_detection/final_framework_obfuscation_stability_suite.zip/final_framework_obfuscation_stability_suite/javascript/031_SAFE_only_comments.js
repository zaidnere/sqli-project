// SELECT * FROM users WHERE x = '${req.query.x}'
/*
 db.all("SELECT * FROM users WHERE id=" + req.query.id)
*/
function ok() { return true; }
module.exports = { ok };
