class Repo{ async run(sequelize,req){ const email=String(req.query.email||""); const replacements={email};
 return sequelize.query(`SELECT id,email FROM users WHERE email='${email}'`); } }
module.exports=Repo;
