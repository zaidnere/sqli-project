
import java.sql.*;
class Authxspklcu {
  boolean allowed(HttpServletRequest req, Statement st) throws Exception {
    String token = req.getParameter("token");
    String sql = "SELECT id FROM sessions WHERE token='" + token + "'";
    return st.executeQuery(sql).next();
  }
}
