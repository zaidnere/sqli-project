async function listOrdersSafeParamsOnly(req, db) {
  const status = String(req.query.status || "OPEN").trim();
  const limit = Math.min(Math.max(Number(req.query.limit || 25), 1), 100);

  return db.all(
    "SELECT id, email FROM users WHERE tenant_id = ? AND status = ? LIMIT ?",
    [req.user.tenantId, status, limit]
  );
}

module.exports = { listOrdersSafeParamsOnly };
