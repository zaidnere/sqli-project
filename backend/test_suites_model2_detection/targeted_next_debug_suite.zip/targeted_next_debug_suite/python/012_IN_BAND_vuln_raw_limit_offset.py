import sqlite3
def list_articles(conn, size, offset):
    sql = f"SELECT id, title FROM articles ORDER BY created_at DESC LIMIT {size} OFFSET {offset}"
    cur = conn.cursor()
    cur.execute(sql)
    return cur.fetchall()
