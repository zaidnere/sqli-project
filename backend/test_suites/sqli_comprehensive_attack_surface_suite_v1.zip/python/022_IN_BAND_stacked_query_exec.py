class UnsafeScriptRunner:
    def __init__(self, db): self.db = db
    def run(self, req):
        name = req.args.get("name", "")
        script = "UPDATE users SET seen=1 WHERE name='" + name + "'; SELECT changes();"
        return self.db.executescript(script)
