<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class RealSavedFilter {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    private function loadFilter(array $q): string {
        $stmt = $this->pdo->prepare("SELECT where_clause FROM saved_filters WHERE tenant_id=? AND id=?");
        $stmt->execute([$q["tenant"], (int)$q["filter_id"]]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row["where_clause"] ?? "1=1";
    }
    public function run(array $q): array {
        $where = $this->loadFilter($q);
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? AND " . $where);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
