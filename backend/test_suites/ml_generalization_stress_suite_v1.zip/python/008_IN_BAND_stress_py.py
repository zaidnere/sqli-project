class Repo:
    def __init__(self, db): self.db = db
    def page(self, req):
        sql = "SELECT id FROM users LIMIT " + req.args.get("limit","25") + " OFFSET " + req.args.get("offset","0")
        return self.db.execute(sql).fetchall()
