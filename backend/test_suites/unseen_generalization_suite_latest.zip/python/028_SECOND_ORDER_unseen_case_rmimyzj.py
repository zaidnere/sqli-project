
def load_bhvfpbi(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_yxyhlmg(request, conn):
    frag_tjlaini = load_bhvfpbi(conn, request.user.tenant_id)
    sql_dyvrycq = "SELECT * FROM audit_log WHERE " + frag_tjlaini
    return conn.execute(sql_dyvrycq).fetchall()
