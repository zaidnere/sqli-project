function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class StoredQueryRunner {
  constructor(db) { this.db = db; }

  async loadQuery(ctx, key) {
    const row = await this.db.get(
      "SELECT sql_body FROM stored_queries WHERE tenant_id=? AND query_key=?",
      [ctx.tenantId, key]
    );
    return row ? row.sql_body : "";
  }

  async run(ctx, key) {
    const sql = await this.loadQuery(ctx, key);
    return this.db.all(sql);
  }
}
module.exports = StoredQueryRunner;
