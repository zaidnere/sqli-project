// db.all(`SELECT * FROM users WHERE email='${req.query.email}'`)
function noDatabaseHere(req) {
  const sqlLike = "SELECT id FROM users WHERE id=" + req.query.id;
  return sqlLike;
}
module.exports = { noDatabaseHere };
