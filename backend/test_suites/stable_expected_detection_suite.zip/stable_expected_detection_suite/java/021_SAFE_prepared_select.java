import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class AccountRepository {
    private final Connection c;
    public AccountRepository(Connection c) { this.c = c; }

    public ResultSet find(AppCtx ctx, long id) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "SELECT id, account_no FROM accounts WHERE tenant_id=? AND id=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setLong(2, id);
        return ps.executeQuery();
    }
}
