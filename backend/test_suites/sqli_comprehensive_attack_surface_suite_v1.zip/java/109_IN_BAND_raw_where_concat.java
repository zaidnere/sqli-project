import java.sql.*;
public class Case {
  private final Connection c; public Case(Connection c){this.c=c;}
  public ResultSet run(String raw)throws SQLException{
    String sql="SELECT id,email FROM users WHERE email LIKE '%"+raw+"%'";
    return c.createStatement().executeQuery(sql);
  }
}
