<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class SavedReportRunner {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    private function loadWhere(array $q): string {
        $stmt = $this->pdo->prepare("SELECT where_clause FROM saved_reports WHERE tenant_id=? AND report_id=?");
        $stmt->execute([$q["tenant"], to_int($q["report_id"] ?? 0)]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row["where_clause"] ?? "1=1";
    }

    public function run(array $q): array {
        $where = $this->loadWhere($q);
        $stmt = $this->pdo->prepare("SELECT id,email FROM customers WHERE tenant_id=? AND " . $where);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
