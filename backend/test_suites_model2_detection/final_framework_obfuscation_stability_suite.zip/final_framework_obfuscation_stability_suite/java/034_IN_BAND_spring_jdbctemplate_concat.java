import java.sql.*;
import java.util.*;
import java.time.Instant;

class Ctx { String tenantId; String actorId; Ctx(String t, String a) { tenantId=t; actorId=a; } }
class Page { int limit; int offset; Page(String l, String o) { limit=Math.max(1, Math.min(200, Integer.parseInt(l))); offset=Math.max(0, Math.min(10000, Integer.parseInt(o))); } }

class Helper0 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper1 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper2 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper3 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper4 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper5 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper6 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper7 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper8 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper9 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper10 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper11 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper12 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper13 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper14 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper15 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper16 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper17 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper18 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper19 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper20 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper21 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper22 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper23 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper24 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper25 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper26 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper27 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper28 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper29 { String normalize(String v) { return v == null ? "" : v.trim(); } }
public class JdbcTemplateUnsafeRepo {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;
    public JdbcTemplateUnsafeRepo(org.springframework.jdbc.core.JdbcTemplate jdbc) { this.jdbc = jdbc; }
    public Object search(String email) {
        String sql = "SELECT id,email FROM users WHERE email='" + email + "'";
        return jdbc.queryForList(sql);
    }
}
