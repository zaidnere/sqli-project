
# safe path uses parameters, unsafe path should be detected
def search_fn_xmybyas(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_gqlpzla = allowed.get(request.GET.get("sort"), "created_at")
    limit_xthtmoj = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_mdcnzah = "SELECT id, email FROM audit_log WHERE tenant_id = ? ORDER BY " + order_gqlpzla + " LIMIT ?"
    decoy = "SELECT * FROM audit_log WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_mdcnzah, (request.user.tenant_id, limit_xthtmoj)).fetchall()
