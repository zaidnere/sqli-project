import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class CustomerSearch {
    private final Connection c;
    public CustomerSearch(Connection c) { this.c = c; }

    public ResultSet search(String email) throws Exception {
        String sql = "SELECT id,email FROM customers WHERE email='" + email + "'";
        return c.createStatement().executeQuery(sql);
    }
}
