class Configured:
    def __init__(self, db, config): self.db = db; self.config = config
    def list(self, tenant):
        cfg = self.config.load_tenant_config(tenant)
        clause = cfg.get("where_clause", "1=1")
        return self.db.execute("SELECT id FROM users WHERE tenant_id=? AND " + clause, [tenant]).fetchall()
