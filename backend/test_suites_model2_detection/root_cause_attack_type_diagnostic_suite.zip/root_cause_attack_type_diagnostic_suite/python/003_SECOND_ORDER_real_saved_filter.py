def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*a): pass

class ReportRunner:
    def __init__(self, conn): self.conn = conn
    def load_filter(self, report_id):
        row = self.conn.execute("SELECT where_clause FROM saved_reports WHERE id=?", [int(report_id)]).fetchone()
        return row["where_clause"] if row else "1=1"
    def run(self, request):
        where_clause = self.load_filter(request["report_id"])
        sql = "SELECT id,email FROM users WHERE tenant_id=? AND " + where_clause
        return self.conn.execute(sql, [request["tenant"]]).fetchall()
