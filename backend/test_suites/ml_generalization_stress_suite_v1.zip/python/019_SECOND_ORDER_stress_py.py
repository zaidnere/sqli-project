class Segments:
    def __init__(self, db): self.db = db
    def report(self, req):
        row = self.db.execute("SELECT sql_fragment FROM report_segments WHERE id=?", [req.args.get("segment")]).fetchone()
        a = row["sql_fragment"]; b = a
        return self.db.execute("SELECT * FROM audit_log WHERE " + b).fetchall()
