function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class JsCountBoolReturn {
  constructor(db) { this.db = db; }

  async canExport(req) {
    const report = norm(req.query.report);
    const row = await this.db.get(
      "SELECT COUNT(*) AS c FROM permissions WHERE report_key='" + report + "'"
    );
    return row && row.c > 0;
  }
}
module.exports = JsCountBoolReturn;
