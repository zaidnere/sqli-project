import java.sql.*;
public class BlindLogin {
  private final Connection c; public BlindLogin(Connection c){this.c=c;}
  public boolean login(String e,String p)throws SQLException{ return c.createStatement().executeQuery("SELECT id FROM users WHERE email='"+e+"' AND password_hash='"+p+"'").next(); }
}
