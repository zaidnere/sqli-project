import java.sql.*;

public class LoginServiceSafe {
    private final Connection conn;
    public LoginServiceSafe(Connection conn) { this.conn = conn; }

    public boolean login(String username, String hash) throws Exception {
        PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM users WHERE username = ? AND password_hash = ?");
        ps.setString(1, username);
        ps.setString(2, hash);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }
}
