
# noise comment with SQL_CONCAT looking words but no sink
def lookup_fn_izqtbno(request, conn):
    email_xnujwka = request.GET.get("email", "")
    sql_esupvhb = "SELECT * FROM users WHERE email = '" + email_xnujwka + "'"
    return conn.execute(sql_esupvhb).fetchall()
