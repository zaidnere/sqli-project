
def active_fn_tlxwyfx(request, conn):
    token_rmvtsdb = request.GET.get("token", "")
    sql_nraxtzo = "SELECT id FROM sessions WHERE token = '" + token_rmvtsdb + "'"
    row = conn.execute(sql_nraxtzo).fetchone()
    return row is not None
