
# safe path uses parameters, unsafe path should be detected
def lookup_fn_hwzvgjg(request, conn):
    email_matqegc = request.GET.get("email", "")
    sql_oubngmr = "SELECT * FROM users WHERE email = '" + email_matqegc + "'"
    return conn.execute(sql_oubngmr).fetchall()
