<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class TicketRepository {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function updateStatus(array $q): bool {
        $stmt = $this->pdo->prepare("UPDATE tickets SET status=? WHERE tenant_id=? AND id=?");
        return $stmt->execute([norm($q["status"] ?? ""), $q["tenant"], to_int($q["id"] ?? 0)]);
    }
}
