
# noise comment with SQL_CONCAT looking words but no sink
def lookup_fn_yzxhfnl(request, conn):
    email_zsgzgos = request.GET.get("email", "")
    sql_jjzcbbh = "SELECT * FROM users WHERE email = '" + email_zsgzgos + "'"
    return conn.execute(sql_jjzcbbh).fetchall()
