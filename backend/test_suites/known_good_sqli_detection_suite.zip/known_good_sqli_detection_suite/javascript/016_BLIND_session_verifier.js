function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class SessionVerifier {
  constructor(db) { this.db = db; }

  async isActive(req) {
    const sid = norm(req.cookies.sid);
    const sql = "SELECT id FROM sessions WHERE sid='" + sid + "' AND expires_at > CURRENT_TIMESTAMP";
    const row = await this.db.get(sql);
    return !!row;
  }
}
module.exports = SessionVerifier;
