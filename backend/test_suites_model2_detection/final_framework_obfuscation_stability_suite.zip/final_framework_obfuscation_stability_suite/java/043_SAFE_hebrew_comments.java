import java.sql.*;
import java.util.*;
import java.time.Instant;

class Ctx { String tenantId; String actorId; Ctx(String t, String a) { tenantId=t; actorId=a; } }
class Page { int limit; int offset; Page(String l, String o) { limit=Math.max(1, Math.min(200, Integer.parseInt(l))); offset=Math.max(0, Math.min(10000, Integer.parseInt(o))); } }

class Helper0 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper1 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper2 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper3 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper4 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper5 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper6 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper7 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper8 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper9 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper10 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper11 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper12 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper13 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper14 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper15 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper16 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper17 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper18 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper19 { String normalize(String v) { return v == null ? "" : v.trim(); } }
// הערה: SELECT * FROM users WHERE id = " + request.getParameter("id")
public class HebrewCommentJavaSafe {
    private final Connection c;
    public HebrewCommentJavaSafe(Connection c) { this.c = c; }
    public ResultSet get(String tenant, long id) throws Exception {
        PreparedStatement ps = c.prepareStatement("SELECT id FROM users WHERE tenant_id=? AND id=?");
        ps.setString(1, tenant); ps.setLong(2, id);
        return ps.executeQuery();
    }
}
