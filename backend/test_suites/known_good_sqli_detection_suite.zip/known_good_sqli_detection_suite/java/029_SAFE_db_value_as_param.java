import java.sql.*;
import java.util.*;

class Ctx {
    String tenantId;
    String actorId;
    Ctx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class SafeDbValue {
    private final Connection c;
    public SafeDbValue(Connection c) { this.c = c; }

    private String dept(Ctx ctx, long userId) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "SELECT department_code FROM users WHERE tenant_id=? AND id=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setLong(2, userId);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("department_code") : "";
    }

    public ResultSet orders(Ctx ctx, long userId) throws Exception {
        String d = dept(ctx, userId);
        PreparedStatement ps = c.prepareStatement(
            "SELECT id FROM orders WHERE tenant_id=? AND department_code=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setString(2, d);
        return ps.executeQuery();
    }
}
