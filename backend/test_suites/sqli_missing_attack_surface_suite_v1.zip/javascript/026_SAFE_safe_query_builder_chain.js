class Repo { constructor(knex){this.knex=knex;} find(req){ return this.knex("users").where({tenant_id:req.user.tenantId,email:String(req.query.email||"")}).select("id","email"); } }
module.exports = Repo;
