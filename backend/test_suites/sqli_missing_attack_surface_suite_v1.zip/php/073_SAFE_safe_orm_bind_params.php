<?php final class Repo { public function run($db, array $q) { return $db->table("users")->where("email", "=", $q["email"])->get(); } }
