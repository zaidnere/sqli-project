import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){tenantId=t;actorId=a;} }

public class ExistsHelper {
    private final Connection c;
    public ExistsHelper(Connection c){ this.c = c; }
    private boolean exists(String sql) throws Exception {
        return c.createStatement().executeQuery(sql).next();
    }
    public boolean token(String t) throws Exception {
        return exists("SELECT id FROM tokens WHERE token='" + t + "'");
    }
}
