<?php
function pick_col($raw): string { return match(trim((string)$raw)) { "email"=>"email", "status"=>"status", default=>"created_at" }; }
final class Repo { public function __construct(private PDO $pdo) {} public function list(array $q): array { $col=pick_col($q["sort"]??"created"); $s=$this->pdo->prepare("SELECT id FROM users ORDER BY ".$col); $s->execute(); return $s->fetchAll(PDO::FETCH_ASSOC); } }
