const ALLOWED = new Set(["id", "email", "created_at"]);

async function listUsers(db, sortBy) {
  const safeCol = ALLOWED.has(sortBy) ? sortBy : "created_at";
  const sql = `SELECT id, email FROM users ORDER BY ${sortBy}`;
  return db.all(sql);
}
module.exports = { listUsers };
