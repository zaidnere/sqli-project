import java.sql.*; import java.util.*;
class Case043 {
  static final Set<String> ALLOWED = Set.of("name", "created_at", "total");
  ResultSet list(Connection c, String rawSort) throws Exception {
    String safeSort = ALLOWED.contains(rawSort) ? rawSort : "created_at";
    String sql = "SELECT id,total FROM orders ORDER BY " + safeSort;
    return c.createStatement().executeQuery(sql);
  }
}
