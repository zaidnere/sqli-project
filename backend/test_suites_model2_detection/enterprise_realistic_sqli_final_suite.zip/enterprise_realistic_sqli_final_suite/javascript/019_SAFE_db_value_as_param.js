const crypto = require("crypto");

function normalizeText(value) {
  if (value === undefined || value === null) return "";
  return String(value).trim();
}
function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function clamp(value, low, high) {
  const n = toNumber(value, low);
  return Math.max(low, Math.min(high, n));
}
function audit(logger, ctx, action, details) {
  if (logger && logger.info) logger.info({ tenantId: ctx.tenantId, actorId: ctx.actorId, requestId: ctx.requestId, action, details });
}
function stableKey(prefix, value) {
  return `${prefix}_${crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 12)}`;
}
class RequestContext {
  constructor(tenantId, actorId, requestId) { this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId; }
}

class DepartmentOrderRepository {
  constructor(db) { this.db = db; }
  async department(ctx, userId) { const row = await this.db.get("SELECT department_code FROM users WHERE tenant_id = ? AND id = ?", [ctx.tenantId, Number(userId)]); return row ? row.department_code : ""; }
  async orders(ctx, userId) { const dept = await this.department(ctx, userId); return this.db.all("SELECT id, order_no FROM orders WHERE tenant_id = ? AND department_code = ?", [ctx.tenantId, dept]); }
}
module.exports = { DepartmentOrderRepository };
