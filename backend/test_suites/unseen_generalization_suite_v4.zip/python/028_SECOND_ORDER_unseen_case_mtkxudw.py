
def load_qprjjnn(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_ltmcqof(request, conn):
    frag_sfvfmqc = load_qprjjnn(conn, request.user.tenant_id)
    sql_kolnsdw = "SELECT * FROM audit_log WHERE " + frag_sfvfmqc
    return conn.execute(sql_kolnsdw).fetchall()
