class SecondOrderOrderRepository:
    def __init__(self, db, config): self.db = db; self.config = config
    def list(self, tenant):
        cfg = self.config.load_tenant_config(tenant)
        order_clause = cfg.get("order_clause", "created_at DESC")
        return self.db.execute("SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + order_clause, [tenant]).fetchall()
