class Repo:
    def __init__(self, db): self.db = db
    def list(self, req):
        return self.db.execute("SELECT id,email FROM users ORDER BY created_at " + req.args.get("dir","ASC")).fetchall()
