def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class BulkLookup:
    def __init__(self, conn):
        self.conn = conn

    def load(self, request):
        ids = request.get("ids", [])
        joined = ",".join(ids)
        sql = "SELECT id, email FROM users WHERE id IN (" + joined + ")"
        return self.conn.execute(sql).fetchall()
