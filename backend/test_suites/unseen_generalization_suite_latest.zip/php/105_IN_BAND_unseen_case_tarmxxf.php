<?php
function search_fn_qdfufte($mysqli) {
    $email = $_GET["email"] ?? "";
    $sql = "SELECT * FROM users WHERE email='" . $email . "'";
    return mysqli_query($mysqli, $sql);
}
?>