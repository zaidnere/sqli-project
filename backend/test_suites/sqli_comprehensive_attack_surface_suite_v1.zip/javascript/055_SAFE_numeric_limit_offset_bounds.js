function clamp(v,a,b,d){ v=Number(v); if(!Number.isFinite(v)) return d; return Math.min(Math.max(Math.floor(v),a),b); }
class Repo{ constructor(db){this.db=db;} async page(req){ const limit=clamp(req.query.limit,1,100,25); const offset=clamp(req.query.offset,0,10000,0); return this.db.all("SELECT id,email FROM users LIMIT ? OFFSET ?",[limit,offset]); } }
module.exports=Repo;
