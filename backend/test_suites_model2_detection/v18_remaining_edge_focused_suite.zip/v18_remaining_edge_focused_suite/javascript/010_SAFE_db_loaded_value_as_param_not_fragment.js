function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class SafeDbValueAsParam {
  constructor(db) { this.db = db; }
  async loadDepartment(ctx, userId) {
    const row = await this.db.get("SELECT department_code FROM users WHERE tenant_id=? AND id=?", [ctx.tenantId, toInt(userId)]);
    return row ? row.department_code : "";
  }
  async listOrders(ctx, userId) {
    const dept = await this.loadDepartment(ctx, userId);
    return this.db.all("SELECT id,order_no FROM orders WHERE tenant_id=? AND department_code=?", [ctx.tenantId, dept]);
  }
}
module.exports = SafeDbValueAsParam;
