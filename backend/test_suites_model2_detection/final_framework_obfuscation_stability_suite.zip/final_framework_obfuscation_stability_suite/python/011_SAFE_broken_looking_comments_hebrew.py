import logging
from datetime import datetime, timedelta
logger = logging.getLogger(__name__)

def norm(v):
    return '' if v is None else str(v).strip()

def clamp(v, lo, hi):
    try:
        n = int(v)
    except Exception:
        n = lo
    return max(lo, min(hi, n))

def helper_0(value):
    data = {'idx': 0, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_1(value):
    data = {'idx': 1, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_2(value):
    data = {'idx': 2, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_3(value):
    data = {'idx': 3, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_4(value):
    data = {'idx': 4, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_5(value):
    data = {'idx': 5, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_6(value):
    data = {'idx': 6, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_7(value):
    data = {'idx': 7, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_8(value):
    data = {'idx': 8, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_9(value):
    data = {'idx': 9, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_10(value):
    data = {'idx': 10, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_11(value):
    data = {'idx': 11, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_12(value):
    data = {'idx': 12, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_13(value):
    data = {'idx': 13, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_14(value):
    data = {'idx': 14, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_15(value):
    data = {'idx': 15, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_16(value):
    data = {'idx': 16, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_17(value):
    data = {'idx': 17, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_18(value):
    data = {'idx': 18, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_19(value):
    data = {'idx': 19, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_20(value):
    data = {'idx': 20, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_21(value):
    data = {'idx': 21, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_22(value):
    data = {'idx': 22, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_23(value):
    data = {'idx': 23, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_24(value):
    data = {'idx': 24, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_25(value):
    data = {'idx': 25, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_26(value):
    data = {'idx': 26, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_27(value):
    data = {'idx': 27, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_28(value):
    data = {'idx': 28, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

def helper_29(value):
    data = {'idx': 29, 'value': value, 'ts': datetime.utcnow().isoformat()}
    return data

# הערה בעברית: זה נראה כמו SELECT * FROM users WHERE name = ' + input
# אבל זו רק הערה ולא קוד.
class HebrewCommentSafe:
    def __init__(self, conn): self.conn = conn
    def get(self, tenant, user_id):
        return self.conn.execute('SELECT id,email FROM users WHERE tenant_id=? AND id=?', [tenant, int(user_id)]).fetchone()
