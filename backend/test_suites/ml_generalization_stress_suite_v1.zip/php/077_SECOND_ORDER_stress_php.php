<?php
final class Jobs { public function __construct(private PDO $pdo) {} public function run(int $id): array { $s=$this->pdo->prepare("SELECT sql_body FROM jobs WHERE id=?"); $s->execute([$id]); $r=$s->fetch(PDO::FETCH_ASSOC); return $this->pdo->query($r["sql_body"])->fetchAll(PDO::FETCH_ASSOC); } }
