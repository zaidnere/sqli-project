<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class PdoOrderRepository {
    private PDO $pdo; private array $sorts = ["created" => "created_at", "status" => "status", "amount" => "total_cents"];
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function list(array $ctx, array $query): array {
        $requested = normalize_text($query["sort"] ?? "created"); $sort = $this->sorts[$requested] ?? "created_at";
        $limit = clamp_int($query["limit"] ?? 50, 1, 200, 50); $offset = clamp_int($query["offset"] ?? 0, 0, 10000, 0);
        $sql = "SELECT id, order_no, status, total_cents FROM orders WHERE tenant_id = :tenant"; $params = [":tenant" => $ctx["tenant"]];
        if (!empty($query["status"])) { $sql .= " AND status = :status"; $params[":status"] = normalize_text($query["status"]); }
        $sql .= " ORDER BY {$sort} DESC LIMIT {$limit} OFFSET {$offset}";
        $stmt = $this->pdo->prepare($sql); $stmt->execute($params); return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
