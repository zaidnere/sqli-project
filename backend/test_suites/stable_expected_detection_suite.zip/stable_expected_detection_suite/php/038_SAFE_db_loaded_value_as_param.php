<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class OrderRepository {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    private function loadDepartment(array $q): string {
        $stmt = $this->pdo->prepare("SELECT department_code FROM users WHERE tenant_id=? AND id=?");
        $stmt->execute([$q["tenant"], to_int($q["user_id"] ?? 0)]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row["department_code"] ?? "";
    }

    public function listOrders(array $q): array {
        $department = $this->loadDepartment($q);
        $stmt = $this->pdo->prepare("SELECT id FROM orders WHERE tenant_id=? AND department_code=?");
        $stmt->execute([$q["tenant"], $department]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
