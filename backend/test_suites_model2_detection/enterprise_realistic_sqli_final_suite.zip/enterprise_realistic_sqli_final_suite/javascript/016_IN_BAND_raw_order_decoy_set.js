const crypto = require("crypto");

function normalizeText(value) {
  if (value === undefined || value === null) return "";
  return String(value).trim();
}
function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function clamp(value, low, high) {
  const n = toNumber(value, low);
  return Math.max(low, Math.min(high, n));
}
function audit(logger, ctx, action, details) {
  if (logger && logger.info) logger.info({ tenantId: ctx.tenantId, actorId: ctx.actorId, requestId: ctx.requestId, action, details });
}
function stableKey(prefix, value) {
  return `${prefix}_${crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 12)}`;
}
class RequestContext {
  constructor(tenantId, actorId, requestId) { this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId; }
}

class ProductRepository {
  constructor(db) { this.db = db; this.allowed = new Set(["name", "sku", "created_at"]); }
  async list(ctx, req) {
    const rawSort = normalizeText(req.query.sort);
    const safeSort = this.allowed.has(rawSort) ? rawSort : "name";
    const sql = "SELECT id, sku, name FROM products WHERE tenant_id = ? ORDER BY " + rawSort;
    return this.db.all(sql, [ctx.tenantId]);
  }
}
module.exports = { ProductRepository };
