# hard_mixed_sqli_challenge_suite

Hard mixed SQL Injection challenge suite for the ML/SAST detector.

- Total cases: 80
- Languages: Python, JavaScript, Java, PHP
- Labels: SAFE/NONE, VULNERABLE/IN_BAND, VULNERABLE/BLIND, VULNERABLE/SECOND_ORDER
- Purpose: stress safe-evidence-aware fusion, tokenizer/normalizer signals, Java PreparedStatement handling, JS sqlite params, PHP PDO params, dynamic identifier whitelists, blind boolean sinks, second-order DB-loaded fragment propagation, and long-ish realistic decoys.

Run with the existing runner from backend:

```bat
py scripts/run_sqli_test_suite.py --suite test_suites/hard_mixed_sqli_challenge_suite.zip --email test3@test.com --password 123456
```

Or with the direct runner:

```bat
py scripts/run_local_detector_suite_direct.py --suite test_suites/hard_mixed_sqli_challenge_suite.zip
```

This suite is intentionally harder than the previous debug suites. Use it after the three baseline suites are green.
