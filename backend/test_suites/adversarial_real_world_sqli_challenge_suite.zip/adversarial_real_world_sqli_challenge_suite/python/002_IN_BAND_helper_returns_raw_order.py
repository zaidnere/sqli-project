def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*args): pass

class Repo:
    SORTS = {"created":"created_at","email":"email"}
    def __init__(self, conn): self.conn = conn
    def pick(self, args):
        raw = norm(args.get("sort"))
        safe = self.SORTS.get(raw, "created_at")
        return raw
    def list(self, args):
        sort = self.pick(args)
        return self.conn.execute("SELECT id FROM users ORDER BY " + sort).fetchall()
