def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class TicketUpdater:
    def __init__(self, conn):
        self.conn = conn

    def update_status(self, request):
        status = norm(request.get("status"))
        ticket_id = to_int(request.get("id"))
        sql = "UPDATE tickets SET status = '" + status + "' WHERE id = " + str(ticket_id)
        return self.conn.execute(sql)
