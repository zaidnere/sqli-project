class Check{ constructor(db){this.db=db;} async canExport(req){ const r=String(req.query.report||""); const row=await this.db.get("SELECT COUNT(*) AS c FROM permissions WHERE report_key='"+r+"'"); return row&&row.c>0; } }
module.exports=Check;
