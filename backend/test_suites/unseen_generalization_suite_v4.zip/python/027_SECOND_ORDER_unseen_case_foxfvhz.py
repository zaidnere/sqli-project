
def load_xztqcjl(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_tfkvyzh(request, conn):
    frag_kgvzymp = load_xztqcjl(conn, request.user.tenant_id)
    sql_rinybxb = "SELECT * FROM audit_log WHERE " + frag_kgvzymp
    return conn.execute(sql_rinybxb).fetchall()
