class SafeDbLoadedValueRepository:
    def __init__(self, db): self.db = db
    def load_status(self, tenant):
        row = self.db.execute("SELECT default_status FROM tenant_settings WHERE tenant_id=?", [tenant]).fetchone()
        return row["default_status"] if row else "OPEN"
    def list_orders(self, tenant):
        status = self.load_status(tenant)
        return self.db.execute("SELECT id,email FROM orders WHERE tenant_id=? AND status=?", [tenant, status]).fetchall()
