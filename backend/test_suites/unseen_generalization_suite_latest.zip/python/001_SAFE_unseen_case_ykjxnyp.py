
# safe path uses parameters, unsafe path should be detected
def search_fn_kvawnny(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_hqcarhq = allowed.get(request.GET.get("sort"), "created_at")
    limit_uaockem = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_wxafgkc = "SELECT id, email FROM orders WHERE tenant_id = ? ORDER BY " + order_hqcarhq + " LIMIT ?"
    decoy = "SELECT * FROM orders WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_wxafgkc, (request.user.tenant_id, limit_uaockem)).fetchall()
