import java.sql.*;
class Case042 {
  boolean exists(Connection c, String email) throws Exception {
    String sql = "SELECT 1 FROM users WHERE email = ?";
    PreparedStatement ps = c.prepareStatement(sql);
    ps.setString(1, email);
    ResultSet rs = ps.executeQuery();
    return rs.next();
  }
}
