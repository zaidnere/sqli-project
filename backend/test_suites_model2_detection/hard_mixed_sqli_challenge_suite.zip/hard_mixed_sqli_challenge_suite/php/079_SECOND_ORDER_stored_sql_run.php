<?php
function runAdminQuery($pdo, $id) {
    $stmt = $pdo->prepare("SELECT sql_text FROM admin_queries WHERE id=?");
    $stmt->execute([$id]);
    $sql = $stmt->fetchColumn();
    return $pdo->query($sql)->fetchAll();
}
?>
