class SecondOrder{ constructor(db,cache){this.db=db;this.cache=cache;} async run(req){ const row=await this.db.get("SELECT where_clause FROM saved_filters WHERE id=?",[req.query.id]); const a=row?row.where_clause:"1=1"; const b=a; return this.db.all("SELECT id,email FROM users WHERE "+b); } }
module.exports=SecondOrder;
