<?php
function canEdit($pdo, $account, $project) {
    $sql = "SELECT 1 FROM perms WHERE account='$account' AND project='$project'";
    return (bool)$pdo->query($sql)->fetchColumn();
}
?>
