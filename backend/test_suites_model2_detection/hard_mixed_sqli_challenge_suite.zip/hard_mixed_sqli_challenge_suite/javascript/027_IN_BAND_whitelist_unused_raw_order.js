const allowed = new Set(["name", "created_at"]);
async function listUsers(db, rawSort) {
  const safeSort = allowed.has(rawSort) ? rawSort : "created_at";
  const sql = "SELECT id,email FROM users ORDER BY " + rawSort;
  return db.all(sql);
}
