class Permissions:
    def __init__(self, db): self.db = db
    def can_export(self, req):
        r = req.args.get("report","")
        row = self.db.execute("SELECT COUNT(*) AS c FROM permissions WHERE report_key='" + r + "'").fetchone()
        return bool(row and row["c"] > 0)
