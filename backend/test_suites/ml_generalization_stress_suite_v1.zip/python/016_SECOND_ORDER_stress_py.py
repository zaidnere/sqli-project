class Runner:
    def __init__(self, db): self.db = db
    def load(self, tenant, fid):
        row = self.db.execute("SELECT where_clause FROM saved_filters WHERE tenant_id=? AND id=?", [tenant, fid]).fetchone()
        return row["where_clause"] if row else "1=1"
    def run(self, req):
        clause = self.load(req.tenant_id, req.args.get("filter"))
        return self.db.execute("SELECT id FROM users WHERE tenant_id=? AND " + clause, [req.tenant_id]).fetchall()
