def pick_column(raw):
    allowed = {"created": "created_at", "email": "email", "status": "status"}
    return {"column": allowed.get(str(raw or "created").strip(), "created_at")}

class SafeOrderRepository:
    def __init__(self, db): self.db = db
    def list(self, req):
        info = pick_column(req.args.get("sort"))
        selected = info["column"]
        final_column = selected
        sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + final_column
        return self.db.execute(sql, [req.tenant_id]).fetchall()
