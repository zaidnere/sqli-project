import json
class Repo:
    def __init__(self, db): self.db = db
    def report(self, req):
        row = self.db.execute("SELECT filter_json FROM reports WHERE id=?", [req.args.get("report")]).fetchone()
        cfg = json.loads(row["filter_json"])
        fragment = cfg["sql"]["where"]
        return self.db.execute("SELECT id FROM events WHERE " + fragment).fetchall()
