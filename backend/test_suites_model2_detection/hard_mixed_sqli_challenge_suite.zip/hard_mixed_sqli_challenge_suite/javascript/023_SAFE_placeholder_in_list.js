async function loadInvoices(db, ids) {
  const clean = ids.map(x => Number(x)).filter(Number.isInteger);
  const marks = clean.map(() => "?").join(",");
  const sql = `SELECT id,total FROM invoices WHERE id IN (${marks})`;
  return db.all(sql, clean);
}
