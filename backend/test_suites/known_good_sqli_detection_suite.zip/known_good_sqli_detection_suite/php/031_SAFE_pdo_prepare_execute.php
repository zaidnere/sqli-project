<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}

final class SafePdo {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function find(array $q): array {
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? AND email=?");
        $stmt->execute([$q["tenant"], norm($q["email"] ?? "")]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
