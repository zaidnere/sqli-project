async function listBySavedSort(db, profileId) {
  const row = await db.get("SELECT sort_expr FROM profiles WHERE id=?", [profileId]);
  const sql = "SELECT id,name FROM customers ORDER BY " + row.sort_expr;
  return db.all(sql);
}
