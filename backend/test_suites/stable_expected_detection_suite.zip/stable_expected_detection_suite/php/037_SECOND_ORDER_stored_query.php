<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class StoredQueryRunner {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    private function loadSql(array $q): string {
        $stmt = $this->pdo->prepare("SELECT sql_body FROM stored_queries WHERE tenant_id=? AND query_key=?");
        $stmt->execute([$q["tenant"], norm($q["key"] ?? "")]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row["sql_body"] ?? "";
    }

    public function run(array $q): array {
        $sql = $this->loadSql($q);
        $stmt = $this->pdo->query($sql);
        return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}
