class Repo{ constructor(db){this.db=db;} async find(req){ return this.db.all("SELECT id,email FROM users WHERE tenant_id=? AND email=?",[req.user.tenantId,String(req.query.email||"")]); } }
module.exports=Repo;
