def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class UserRepo:
    def __init__(self, conn):
        self.conn = conn

    def find_by_email(self, request):
        email = norm(request.get("email"))
        sql = "SELECT id, email FROM users WHERE tenant_id = ? AND email = ?"
        return self.conn.execute(sql, [request["tenant"], email]).fetchone()
