# Unseen Generalization Suite - Fixed

Generated: 2026-05-10T08:24:44.154443+00:00

Based on:
unseen_generalization_suite_latest.zip

Fixes:
1. Replaced the 8 JavaScript SAFE files that were false positives:
   javascript/033_SAFE_unseen_case_*.js through javascript/040_SAFE_unseen_case_*.js

2. Rewrote manifest.csv with runner-compatible columns:
   - expected_verdict
   - expected_type

Also kept the old columns:
   - expected_label
   - expected_attack_type

Expected distribution:
- 128 total files
- 32 SAFE / NONE
- 32 VULNERABLE / IN_BAND
- 32 VULNERABLE / BLIND
- 32 VULNERABLE / SECOND_ORDER
