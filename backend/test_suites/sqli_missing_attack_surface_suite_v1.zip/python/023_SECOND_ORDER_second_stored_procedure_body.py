class Repo:
    def __init__(self, db): self.db = db
    def run(self, req):
        row = self.db.execute("SELECT procedure_body FROM custom_procedures WHERE id=?", [req.args.get("id")]).fetchone()
        fragment = row["procedure_body"]
        return self.db.execute("SELECT id,email FROM users WHERE " + fragment).fetchall()
