import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){tenantId=t;actorId=a;} }

public class TimeProbe {
    private final Connection c;
    public TimeProbe(Connection c){ this.c = c; }
    public boolean run(String email) throws Exception {
        String sql = "SELECT CASE WHEN email='" + email + "' THEN SLEEP(5) ELSE 0 END FROM users";
        c.createStatement().executeQuery(sql);
        return true;
    }
}
