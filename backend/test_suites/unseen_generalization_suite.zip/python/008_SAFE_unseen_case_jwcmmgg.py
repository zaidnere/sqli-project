
# noise comment with SQL_CONCAT looking words but no sink
def search_fn_ehxaltr(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_dozxcqj = allowed.get(request.GET.get("sort"), "created_at")
    limit_sydyfar = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_igntioz = "SELECT id, email FROM audit_log WHERE tenant_id = ? ORDER BY " + order_dozxcqj + " LIMIT ?"
    decoy = "SELECT * FROM audit_log WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_igntioz, (request.user.tenant_id, limit_sydyfar)).fetchall()
