<?php
function runConfiguredReport($pdo) {
    $frag = $pdo->query("SELECT value FROM app_config WHERE name='report_predicate'")->fetchColumn();
    return $pdo->query("SELECT id,total FROM orders WHERE status='open' AND " . $frag)->fetchAll();
}
?>
