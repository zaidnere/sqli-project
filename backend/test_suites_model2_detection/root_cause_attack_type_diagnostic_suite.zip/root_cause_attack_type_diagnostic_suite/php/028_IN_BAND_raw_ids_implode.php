<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class RawIdsImplode {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function load(array $q): array {
        $ids = $q["ids"] ?? [];
        $joined = implode(",", $ids);
        $stmt = $this->pdo->query("SELECT id,email FROM users WHERE id IN (" . $joined . ")");
        return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}
