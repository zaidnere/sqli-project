// Broken Java syntax sample; scanner should not crash.
public class BrokenJava {
    public void x( {
        String sql = "SELECT id FROM users WHERE id = ?";
}
