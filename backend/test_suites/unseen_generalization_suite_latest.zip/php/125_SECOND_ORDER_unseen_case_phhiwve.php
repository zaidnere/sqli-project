<?php
function load_f_jkfwuno($pdo, $id) {
    $stmt = $pdo->prepare("SELECT where_clause FROM saved_filters WHERE id=?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row["where_clause"];
}
function run_fn_gwbskba($pdo, $id) {
    $where = load_f_jbcgcht($pdo, $id);
    $sql = "SELECT * FROM audit_log WHERE " . $where;
    return $pdo->query($sql)->fetchAll();
}
?>