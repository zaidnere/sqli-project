<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}

final class UnsafeMysqli {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }

    public function search(array $q): array {
        $email = norm($q["email"] ?? "");
        $r = $this->db->query("SELECT id,email FROM users WHERE email='" . $email . "'");
        return $r ? $r->fetch_all(MYSQLI_ASSOC) : [];
    }
}
