class Repo:
    def __init__(self, db): self.db = db
    def search(self, req):
        email = req.args.get("email", "")
        sql = f"SELECT id,email FROM users WHERE email LIKE '%{email}%'"
        return self.db.execute(sql).fetchall()
