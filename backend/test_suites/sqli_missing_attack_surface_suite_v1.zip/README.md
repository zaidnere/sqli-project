# SQLi Missing Attack Surface Suite V1

Generated: 2026-05-11T13:18:51.448211+00:00

Total cases: 96

Distribution:
- Python: 24
- JavaScript: 24
- Java: 24
- PHP: 24

Per language:
- 6 SAFE / NONE
- 8 VULNERABLE / IN_BAND
- 4 VULNERABLE / BLIND
- 6 VULNERABLE / SECOND_ORDER

Purpose:
A targeted missing-coverage suite after the broad attack-surface run.

Main focus:
1. ORM/query-builder safe vs unsafe.
2. Real safe transformations vs fake sanitizers.
3. Identifier injection beyond ORDER BY: direction, GROUP BY/HAVING, COLLATE, JOIN target.
4. SQL dialect and error/time-based patterns.
5. More realistic SECOND_ORDER: admin saved search, dashboard config, tenant policy cache, stored sort direction, procedure body, serialized report filter.

Notes:
- OUT_OF_BAND-like cases are mapped to BLIND because the current taxonomy has no OUT_OF_BAND class.
- Error-based SQLi cases are mapped to IN_BAND.
