<?php
function listWithFilter($pdo, $filterId) {
    $stmt = $pdo->prepare("SELECT filter_sql FROM filters WHERE id=?");
    $stmt->execute([$filterId]);
    $filter = $stmt->fetchColumn();
    return $pdo->query("SELECT * FROM products WHERE tenant_id=1 AND " . $filter)->fetchAll();
}
?>
