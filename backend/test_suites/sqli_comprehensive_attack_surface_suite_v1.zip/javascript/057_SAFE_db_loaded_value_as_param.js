class Repo{ constructor(db){this.db=db;} async status(t){ const r=await this.db.get("SELECT default_status FROM tenant_settings WHERE tenant_id=?",[t]); return r?r.default_status:"OPEN"; } async list(req){ const s=await this.status(req.user.tenantId); return this.db.all("SELECT id,email FROM orders WHERE tenant_id=? AND status=?",[req.user.tenantId,s]); } }
module.exports=Repo;
