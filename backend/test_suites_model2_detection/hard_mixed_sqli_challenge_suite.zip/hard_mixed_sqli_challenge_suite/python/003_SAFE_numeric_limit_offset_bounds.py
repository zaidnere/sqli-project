def page_events(conn, request):
    limit = max(1, min(int(request.get("limit", 50)), 100))
    offset = max(0, min(int(request.get("offset", 0)), 10000))
    sql = "SELECT id, message FROM events ORDER BY id DESC LIMIT %d OFFSET %d" % (limit, offset)
    return conn.execute(sql).fetchall()
