import java.sql.*; import java.util.*;
public class Repo { private final Connection c; static final Set<String> A=Set.of("created_at","email","status","country_code","ASC","DESC");
  public Repo(Connection c){this.c=c;} public ResultSet list(String a, String b) throws SQLException {
    String col=A.contains(a)?a:"created_at"; String dir=A.contains(b)?b:"ASC";
    return c.prepareStatement("SELECT id,email FROM users ORDER BY "+col+" "+dir).executeQuery();
  }}
