<?php
function runSavedReport($pdo, $id) {
    $stmt = $pdo->prepare("SELECT where_clause FROM reports WHERE id=?");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $sql = "SELECT id,total FROM orders WHERE " . $row['where_clause'];
    return $pdo->query($sql)->fetchAll();
}
?>
