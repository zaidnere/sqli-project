# cursor.execute("SELECT * FROM users WHERE email='" + request.GET["email"] + "'")
def debug(user_input):
    sql_like = "SELECT id FROM users WHERE email='" + user_input + "'"
    return {"debug": sql_like}
