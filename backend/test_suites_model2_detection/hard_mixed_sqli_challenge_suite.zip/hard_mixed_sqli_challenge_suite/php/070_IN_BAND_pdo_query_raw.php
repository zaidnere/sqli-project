<?php
function search($pdo, $q) {
    $sql = "SELECT id,title FROM articles WHERE title LIKE '%" . $q . "%'";
    return $pdo->query($sql)->fetchAll();
}
?>
