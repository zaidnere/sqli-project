
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def search_fn_xengqmz(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_qseeeta = allowed.get(request.GET.get("sort"), "created_at")
    limit_wxymxrm = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_vdnejnl = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + order_qseeeta + " LIMIT ?"
    decoy = "SELECT * FROM users WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_vdnejnl, (request.user.tenant_id, limit_wxymxrm)).fetchall()
