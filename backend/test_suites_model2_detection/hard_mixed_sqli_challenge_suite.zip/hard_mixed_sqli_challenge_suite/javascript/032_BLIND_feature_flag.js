async function isFeatureOn(db, userId, flag) {
  const sql = `SELECT 1 FROM flags WHERE user_id = ${userId} AND name = '${flag}'`;
  const row = await db.get(sql);
  return !!row;
}
