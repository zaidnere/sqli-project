function docs(){ const s="SELECT * FROM users WHERE id="+ "<raw>"; return {example:s}; } module.exports={docs};
