function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class UnsafeSetHasRawUsed {
  constructor(db) { this.db = db; }
  async list(req) {
    const allowed = new Set(["created_at", "email"]);
    const requested = norm(req.query.sort);
    const safe = allowed.has(requested) ? requested : "created_at";
    const sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + requested;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = UnsafeSetHasRawUsed;
