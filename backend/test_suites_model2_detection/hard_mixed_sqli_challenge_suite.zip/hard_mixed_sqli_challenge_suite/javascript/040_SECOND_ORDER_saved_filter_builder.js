async function buildReport(db, id) {
  const cfg = await db.get("SELECT filter FROM report_filters WHERE id=?", [id]);
  const base = "SELECT id,total FROM orders WHERE status='open'";
  const sql = base + " AND " + cfg.filter;
  return db.all(sql);
}
