class Repo{ constructor(db){this.db=db;} async search(req){ const email=String(req.query.email||"");
 return this.db.all(`SELECT id,email FROM users WHERE email LIKE '%${email}%'`); } }
module.exports=Repo;
