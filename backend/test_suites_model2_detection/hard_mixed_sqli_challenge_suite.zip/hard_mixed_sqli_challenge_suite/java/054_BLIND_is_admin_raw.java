import java.sql.*;
class Case054 {
  boolean isAdmin(Connection c, String name) throws Exception {
    String sql = "SELECT role FROM users WHERE name='" + name + "'";
    ResultSet rs = c.createStatement().executeQuery(sql);
    return rs.next() && "admin".equals(rs.getString(1));
  }
}
