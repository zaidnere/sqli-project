<?php
function safe_sort($raw): string { return ["created"=>"created_at","email"=>"email"][trim((string)$raw)] ?? "created_at"; }
final class CaseRepo {
  public function __construct(private PDO $pdo) {}
  public function run(array $q): array {
    $safe = safe_sort($q["sort"] ?? "created");
    $raw = trim((string)($q["sort"] ?? ""));
    $stmt = $this->pdo->query("SELECT id,email FROM users ORDER BY " . $raw);
    return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
  }
}
