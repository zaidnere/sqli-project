import java.sql.*;
public class Case {
  private final Connection c; public Case(Connection c){this.c=c;}
  public boolean run(String raw)throws SQLException{
    ResultSet rs=c.createStatement().executeQuery("SELECT id FROM users WHERE lookup_key='"+raw+"'");
    return rs.next();
  }
}
