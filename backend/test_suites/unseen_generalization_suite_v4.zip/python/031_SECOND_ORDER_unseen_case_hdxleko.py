
def load_xhyqzil(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_zyqcnba(request, conn):
    frag_updtdok = load_xhyqzil(conn, request.user.tenant_id)
    sql_eksplha = "SELECT * FROM audit_log WHERE " + frag_updtdok
    return conn.execute(sql_eksplha).fetchall()
