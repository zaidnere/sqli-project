class Flags:
    def __init__(self, db): self.db = db
    def enabled(self, req):
        f = req.args.get("feature","")
        return self.db.execute("SELECT id FROM feature_flags WHERE feature_key='" + f + "'").fetchone() is not None
