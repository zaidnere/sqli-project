
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def lookup_fn_wbdlrey(request, conn):
    email_ijqwddz = request.GET.get("email", "")
    sql_tmxzhti = "SELECT * FROM users WHERE email = '" + email_ijqwddz + "'"
    return conn.execute(sql_tmxzhti).fetchall()
