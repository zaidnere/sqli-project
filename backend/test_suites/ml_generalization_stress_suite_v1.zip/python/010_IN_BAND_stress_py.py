class Repo:
    def __init__(self, db): self.db = db
    def export(self, req):
        table = req.args.get("table", "")
        return self.db.execute("SELECT * FROM " + table).fetchall()
