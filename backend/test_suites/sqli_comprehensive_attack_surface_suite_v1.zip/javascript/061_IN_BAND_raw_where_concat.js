class Repo{ constructor(db){this.db=db;} async search(req){ const q=String(req.query.q||req.query.email||""); return this.db.all(`SELECT id,email FROM users WHERE email LIKE '%${q}%'`); } }
module.exports=Repo;
