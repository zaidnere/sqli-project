<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class BlindCountAliasBooleanReturnWithIf {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }

    public function featureEnabled(array $q): bool {
        $feature = norm($q["feature"] ?? "");
        $res = $this->db->query("SELECT COUNT(*) AS c FROM feature_flags WHERE feature_key='" . $feature . "'");
        $row = $res ? $res->fetch_assoc() : ["c" => 0];
        if ((int)$row["c"] > 0) {
            return true;
        }
        return false;
    }
}
