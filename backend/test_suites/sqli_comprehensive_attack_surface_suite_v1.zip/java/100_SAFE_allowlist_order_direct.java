import java.sql.*; import java.util.*;
public class Case {
  private final Connection c; static final Set<String> A=Set.of("created_at","email","status");
  public Case(Connection c){this.c=c;}
  public ResultSet run(String sort)throws SQLException{
    String selected=A.contains(sort)?sort:"created_at"; String finalOrder=selected;
    return c.prepareStatement("SELECT id,email FROM users ORDER BY "+finalOrder).executeQuery();
  }
}
