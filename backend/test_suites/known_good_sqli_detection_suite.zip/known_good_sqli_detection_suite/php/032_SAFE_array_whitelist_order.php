<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}

final class SafeOrder {
    private PDO $pdo;
    private array $sorts = ["created" => "created_at", "email" => "email"];

    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function list(array $q): array {
        $sort = $this->sorts[norm($q["sort"] ?? "created")] ?? "created_at";
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? ORDER BY " . $sort);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
