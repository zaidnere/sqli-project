
def active_fn_aegjbia(request, conn):
    token_mrwgvuw = request.GET.get("token", "")
    sql_zzaldmr = "SELECT id FROM sessions WHERE token = '" + token_mrwgvuw + "'"
    row = conn.execute(sql_zzaldmr).fetchone()
    return row is not None
