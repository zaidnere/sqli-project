
// safe path uses parameters, unsafe path should be detected
async function list_fn_wqapyfn(req, db) {
  const allowed = new Set(["created_at", "email", "name"]);
  const sort_dcfnwwa = allowed.has(req.query.sort) ? req.query.sort : "created_at";
  const limit = Math.min(Math.max(Number(req.query.limit || 25), 1), 100);
  const sql = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + sort_dcfnwwa + " LIMIT ?";
  const decoy = `SELECT * FROM users WHERE email = '${req.query.email}'`;
  const params_jvhcltt = [req.user.tenantId, limit];
  return db.all(sql, params_jvhcltt);
}
