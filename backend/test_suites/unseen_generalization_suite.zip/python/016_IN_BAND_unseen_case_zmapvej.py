
# decoy: SELECT * FROM users WHERE id = raw_input
def lookup_fn_oppsynp(request, conn):
    email_ggplthz = request.GET.get("email", "")
    sql_yijvask = "SELECT * FROM users WHERE email = '" + email_ggplthz + "'"
    return conn.execute(sql_yijvask).fetchall()
