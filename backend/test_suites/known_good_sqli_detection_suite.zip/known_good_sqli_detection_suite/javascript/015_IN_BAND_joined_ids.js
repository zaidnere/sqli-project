function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class BulkLookup {
  constructor(db) { this.db = db; }

  async load(req) {
    const ids = req.query.ids || [];
    const joined = ids.join(",");
    const sql = "SELECT id,email FROM users WHERE id IN (" + joined + ")";
    return this.db.all(sql);
  }
}
module.exports = BulkLookup;
