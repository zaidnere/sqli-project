# V18 Provenance Overfit Guard Suite

Generated: 2026-05-09T21:29:37.635806+00:00

Total cases: 20

Purpose:
A small follow-up suite for post-V18 fixes. It focuses on preventing broad/overfit rules.

Focus:
1. Exact variable-level allowlist tracking:
   - SAFE when sanitized/allowlisted variable reaches ORDER BY.
   - VULNERABLE when allowlist exists but raw request variable reaches ORDER BY.

2. Second-order provenance:
   - SECOND_ORDER only for DB/cache/config/stored-loaded SQL fragments.
   - Direct request variables named saved/config/cache should remain IN_BAND when appended into SQL.

3. PHP BLIND count semantics:
   - COUNT/fetch_assoc controls boolean/security decision => BLIND.
   - COUNT returned as data => IN_BAND.
   - Parameterized count boolean => SAFE.
