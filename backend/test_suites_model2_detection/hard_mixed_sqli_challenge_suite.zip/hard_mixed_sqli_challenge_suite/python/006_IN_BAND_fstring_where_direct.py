def find_user(conn, email):
    safe_demo = "SELECT id FROM users WHERE email = ?"  # decoy only
    sql = f"SELECT id, email FROM users WHERE email = '{email}'"
    return conn.execute(sql).fetchall()
