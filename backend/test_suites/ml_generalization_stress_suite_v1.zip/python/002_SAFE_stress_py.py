def pick_order(raw):
    allowed = {"created": "created_at", "email": "email", "status": "status"}
    return allowed.get(str(raw or "created").strip(), "created_at")
class Repo:
    def __init__(self, db): self.db = db
    def list(self, req):
        selected = pick_order(req.args.get("sort"))
        final_order = selected
        sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + final_order
        return self.db.execute(sql, [req.tenant_id]).fetchall()
