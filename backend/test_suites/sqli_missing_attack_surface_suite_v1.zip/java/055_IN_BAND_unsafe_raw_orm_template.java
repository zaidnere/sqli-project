import java.sql.*;
public class Repo { private final Connection c; public Repo(Connection c){this.c=c;}
  public ResultSet run(String raw) throws SQLException {
    String sql = "SELECT id,email FROM users WHERE email LIKE '%" + raw + "%'";
    return c.createStatement().executeQuery(sql);
  }}
