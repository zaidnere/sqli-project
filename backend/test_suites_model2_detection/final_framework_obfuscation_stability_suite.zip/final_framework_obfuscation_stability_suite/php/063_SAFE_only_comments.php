<?php
// SELECT * FROM users WHERE id = " . $_GET["id"]
/*
$mysqli->query("SELECT * FROM x WHERE y=" . $_POST["y"]);
*/
function ok(): bool { return true; }
