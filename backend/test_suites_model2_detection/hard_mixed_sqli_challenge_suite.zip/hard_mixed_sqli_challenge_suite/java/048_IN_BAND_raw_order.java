import java.sql.*;
class Case048 {
  ResultSet list(Connection c, String orderBy) throws Exception {
    String sql = "SELECT id,name FROM products ORDER BY " + orderBy;
    return c.createStatement().executeQuery(sql);
  }
}
