def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*a): pass

class Repo:
    def __init__(self, conn): self.conn = conn
    def search(self, request):
        cached_email = norm(request.get("email"))
        sql = "SELECT id,email FROM customers WHERE email='" + cached_email + "'"
        return self.conn.execute(sql).fetchall()
