def export_table(conn, table_name, tenant_id):
    sql = "SELECT * FROM " + table_name + " WHERE tenant_id = ?"
    return conn.execute(sql, (tenant_id,)).fetchall()
