
def active_fn_ocdyfhp(request, conn):
    token_waqdorr = request.GET.get("token", "")
    sql_zngfgnn = "SELECT id FROM sessions WHERE token = '" + token_waqdorr + "'"
    row = conn.execute(sql_zngfgnn).fetchone()
    return row is not None
