<?php function docs(): array { $s = "SELECT * FROM users WHERE id=" . "<raw>"; return ["example"=>$s]; }
