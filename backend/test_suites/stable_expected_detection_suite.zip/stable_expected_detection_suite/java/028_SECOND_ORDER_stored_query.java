import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class StoredQueryRunner {
    private final Connection c;
    public StoredQueryRunner(Connection c) { this.c = c; }

    private String loadSql(AppCtx ctx, String key) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "SELECT sql_body FROM stored_queries WHERE tenant_id=? AND query_key=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setString(2, key);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("sql_body") : "";
    }

    public ResultSet run(AppCtx ctx, String key) throws Exception {
        String sql = loadSql(ctx, key);
        return c.createStatement().executeQuery(sql);
    }
}
