
# safe path uses parameters, unsafe path should be detected
def search_fn_jlcswyj(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_auopwag = allowed.get(request.GET.get("sort"), "created_at")
    limit_bjevcdv = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_ytpwwdw = "SELECT id, email FROM profiles WHERE tenant_id = ? ORDER BY " + order_auopwag + " LIMIT ?"
    decoy = "SELECT * FROM profiles WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_ytpwwdw, (request.user.tenant_id, limit_bjevcdv)).fetchall()
