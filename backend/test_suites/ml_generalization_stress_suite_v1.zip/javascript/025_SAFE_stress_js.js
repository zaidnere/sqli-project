function clamp(x,a,b,d){ x=Number(x); if(!Number.isFinite(x)) return d; return Math.min(Math.max(Math.floor(x),a),b); }
class Repo{ constructor(db){this.db=db;} async list(req){ const lim=clamp(req.query.limit,1,100,25); const off=clamp(req.query.offset,0,10000,0);
 return this.db.all("SELECT id FROM users WHERE tenant_id=? LIMIT ? OFFSET ?",[req.user.tenantId,lim,off]); } }
module.exports=Repo;
