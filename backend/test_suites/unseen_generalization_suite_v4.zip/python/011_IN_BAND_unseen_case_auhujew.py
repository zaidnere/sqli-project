
# noise comment with SQL_CONCAT looking words but no sink
def lookup_fn_vfsiqdn(request, conn):
    email_ycyfkul = request.GET.get("email", "")
    sql_iqdjznc = "SELECT * FROM users WHERE email = '" + email_ycyfkul + "'"
    return conn.execute(sql_iqdjznc).fetchall()
