class Repo{constructor(db){this.db=db;} list(req){return this.db.all("SELECT id,email FROM users ORDER BY email COLLATE "+req.query.collate);}} module.exports=Repo;
