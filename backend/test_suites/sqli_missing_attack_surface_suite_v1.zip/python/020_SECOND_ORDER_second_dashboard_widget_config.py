class Repo:
    def __init__(self, db): self.db = db
    def run(self, req):
        row = self.db.execute("SELECT widget_where FROM dashboard_widgets WHERE id=?", [req.args.get("id")]).fetchone()
        fragment = row["widget_where"]
        return self.db.execute("SELECT id,email FROM users WHERE " + fragment).fetchall()
