<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class PermissionGateway {
    private mysqli $db; public function __construct(mysqli $db) { $this->db = $db; }
    public function canDelete(array $ctx, string $resource): bool { $sql = "SELECT id FROM permissions WHERE tenant_id = '" . $ctx["tenant"] . "' AND actor_id = '" . $ctx["actor"] . "' AND resource_key = '" . $resource . "' AND can_delete = 1"; $result = $this->db->query($sql); return $result && $result->fetch_assoc() !== null; }
}
