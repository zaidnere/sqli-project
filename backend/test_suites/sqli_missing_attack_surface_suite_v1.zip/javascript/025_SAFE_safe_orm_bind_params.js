class Repo { async find(prisma, req) { const email = String(req.query.email || ""); return prisma.$queryRaw`SELECT id,email FROM users WHERE email = ${email}`; } }
module.exports = Repo;
