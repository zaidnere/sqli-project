<?php
function listProducts($pdo, $orderBy) {
    return $pdo->query("SELECT id,name FROM products ORDER BY " . $orderBy)->fetchAll();
}
?>
