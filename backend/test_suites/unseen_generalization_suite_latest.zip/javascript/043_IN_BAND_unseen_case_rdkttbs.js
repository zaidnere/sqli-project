
async function find_fn_vajxchm(req, db) {
  const email = req.query.email || "";
  const sql = `SELECT * FROM users WHERE email = '${email}'`;
  return db.all(sql);
}
