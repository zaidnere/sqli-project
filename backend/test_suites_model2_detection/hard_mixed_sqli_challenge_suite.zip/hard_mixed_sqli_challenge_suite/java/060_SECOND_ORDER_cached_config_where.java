import java.sql.*; import java.util.*;
class Case060 {
  Map<String,String> cache = new HashMap<>();
  void load(Connection c) throws Exception {
    ResultSet rs = c.createStatement().executeQuery("SELECT name, fragment FROM query_fragments");
    while (rs.next()) cache.put(rs.getString(1), rs.getString(2));
  }
  ResultSet search(Connection c, String key) throws Exception {
    String sql = "SELECT * FROM products WHERE tenant_id=1 AND " + cache.get(key);
    return c.createStatement().executeQuery(sql);
  }
}
