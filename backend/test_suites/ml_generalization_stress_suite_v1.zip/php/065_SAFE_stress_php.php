<?php
final class Repo { public function __construct(private PDO $pdo) {} public function byIds(array $ids): array { $ids=array_map("intval",$ids); $m=implode(",",array_fill(0,count($ids),"?")); $s=$this->pdo->prepare("SELECT id FROM inv WHERE id IN ($m)"); $s->execute($ids); return $s->fetchAll(PDO::FETCH_ASSOC); } }
