import java.sql.*;
import java.util.*;

class Ctx {
    String tenantId;
    String actorId;
    Ctx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class StoredFilter {
    private final Connection c;
    public StoredFilter(Connection c) { this.c = c; }

    private String loadWhere(Ctx ctx, long id) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "SELECT where_clause FROM saved_filters WHERE tenant_id=? AND id=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setLong(2, id);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("where_clause") : "1=1";
    }

    public ResultSet run(Ctx ctx, long id) throws Exception {
        String where = loadWhere(ctx, id);
        String sql = "SELECT id,email FROM users WHERE tenant_id='" + ctx.tenantId + "' AND " + where;
        return c.createStatement().executeQuery(sql);
    }
}
