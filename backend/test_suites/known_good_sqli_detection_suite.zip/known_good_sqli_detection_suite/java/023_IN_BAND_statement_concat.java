import java.sql.*;
import java.util.*;

class Ctx {
    String tenantId;
    String actorId;
    Ctx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class UnsafeStatement {
    private final Connection c;
    public UnsafeStatement(Connection c) { this.c = c; }

    public ResultSet search(String email) throws Exception {
        String sql = "SELECT id,email FROM users WHERE email='" + email + "'";
        return c.createStatement().executeQuery(sql);
    }
}
