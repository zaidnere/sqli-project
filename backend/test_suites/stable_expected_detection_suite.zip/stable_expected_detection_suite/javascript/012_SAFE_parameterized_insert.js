function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class AuditRepository {
  constructor(db) { this.db = db; }

  async write(req) {
    const sql = "INSERT INTO audit_events (tenant_id, actor_id, action) VALUES (?, ?, ?)";
    return this.db.run(sql, [req.tenantId, req.user.id, norm(req.body.action)]);
  }
}
module.exports = AuditRepository;
