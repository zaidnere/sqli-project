
import java.sql.*;
class Authhftiqpa {
  boolean allowed(HttpServletRequest req, Statement st) throws Exception {
    String token = req.getParameter("token");
    String sql = "SELECT id FROM sessions WHERE token='" + token + "'";
    return st.executeQuery(sql).next();
  }
}
