class SecondOrderStoredQueryRunner:
    def __init__(self, db): self.db = db
    def run(self, job_id):
        row = self.db.execute("SELECT sql_body FROM scheduled_jobs WHERE id=?", [job_id]).fetchone()
        sql_body = row["sql_body"]
        return self.db.execute(sql_body).fetchall()
