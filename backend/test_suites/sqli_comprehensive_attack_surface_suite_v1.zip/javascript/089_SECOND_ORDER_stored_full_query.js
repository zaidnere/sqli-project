class SecondOrder{ constructor(db){this.db=db;} async run(id){ const row=await this.db.get("SELECT sql_body FROM jobs WHERE id=?",[id]); return this.db.all(row.sql_body); } }
module.exports=SecondOrder;
