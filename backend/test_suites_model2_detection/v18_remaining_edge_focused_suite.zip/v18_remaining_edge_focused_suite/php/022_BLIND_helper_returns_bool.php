<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class BoolHelperPermission {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }
    private function exists(string $sql): bool {
        $r = $this->db->query($sql);
        return $r && $r->num_rows > 0;
    }
    public function canAccess(array $q): bool {
        $resource = norm($q["resource"] ?? "");
        $sql = "SELECT id FROM acl WHERE resource_key='" . $resource . "'";
        return $this->exists($sql);
    }
}
