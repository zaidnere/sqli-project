
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def search_fn_ibwawnq(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_ukemnua = allowed.get(request.GET.get("sort"), "created_at")
    limit_erobgzg = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_lzdseza = "SELECT id, email FROM sessions WHERE tenant_id = ? ORDER BY " + order_ukemnua + " LIMIT ?"
    decoy = "SELECT * FROM sessions WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_lzdseza, (request.user.tenant_id, limit_erobgzg)).fetchall()
