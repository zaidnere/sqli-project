
# safe path uses parameters, unsafe path should be detected
def search_fn_zpgrsgz(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_hhwhtpm = allowed.get(request.GET.get("sort"), "created_at")
    limit_dgroide = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_smobxrw = "SELECT id, email FROM audit_log WHERE tenant_id = ? ORDER BY " + order_hhwhtpm + " LIMIT ?"
    decoy = "SELECT * FROM audit_log WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_smobxrw, (request.user.tenant_id, limit_dgroide)).fetchall()
