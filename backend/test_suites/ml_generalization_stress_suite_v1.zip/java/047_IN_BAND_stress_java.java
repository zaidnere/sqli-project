import java.sql.*; import java.util.*;
public class UnsafeAllowlistRaw {
  private final Connection c; static final Set<String> A=Set.of("created_at","email");
  public UnsafeAllowlistRaw(Connection c){this.c=c;}
  public ResultSet list(String sort)throws SQLException{ String safe=A.contains(sort)?sort:"created_at"; return c.createStatement().executeQuery("SELECT id FROM users ORDER BY "+sort); }
}
