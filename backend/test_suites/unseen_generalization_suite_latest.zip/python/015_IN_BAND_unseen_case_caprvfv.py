
# decoy: SELECT * FROM users WHERE id = raw_input
def lookup_fn_idrfeem(request, conn):
    email_imoxohe = request.GET.get("email", "")
    sql_htfpdle = "SELECT * FROM users WHERE email = '" + email_imoxohe + "'"
    return conn.execute(sql_htfpdle).fetchall()
