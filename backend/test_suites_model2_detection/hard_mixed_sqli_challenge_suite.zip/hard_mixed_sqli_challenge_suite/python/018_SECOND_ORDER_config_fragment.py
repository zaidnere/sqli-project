def nightly_job(conn):
    cfg = conn.execute("SELECT value FROM app_config WHERE name='archival_predicate'").fetchone()[0]
    sql = "SELECT id FROM audit_log WHERE " + cfg
    return conn.execute(sql).fetchall()
