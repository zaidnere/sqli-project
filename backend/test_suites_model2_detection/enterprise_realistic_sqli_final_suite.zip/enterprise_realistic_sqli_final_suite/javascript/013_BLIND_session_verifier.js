const crypto = require("crypto");

function normalizeText(value) {
  if (value === undefined || value === null) return "";
  return String(value).trim();
}
function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function clamp(value, low, high) {
  const n = toNumber(value, low);
  return Math.max(low, Math.min(high, n));
}
function audit(logger, ctx, action, details) {
  if (logger && logger.info) logger.info({ tenantId: ctx.tenantId, actorId: ctx.actorId, requestId: ctx.requestId, action, details });
}
function stableKey(prefix, value) {
  return `${prefix}_${crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 12)}`;
}
class RequestContext {
  constructor(tenantId, actorId, requestId) { this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId; }
}

class SessionVerifier {
  constructor(db) { this.db = db; }
  async isActive(ctx, sessionId) {
    const sid = normalizeText(sessionId);
    const sql = `SELECT id FROM sessions WHERE tenant_id = '${ctx.tenantId}' AND session_id = '${sid}' AND expires_at > CURRENT_TIMESTAMP`;
    const rows = await this.db.all(sql);
    return rows.length > 0;
  }
}
module.exports = { SessionVerifier };
