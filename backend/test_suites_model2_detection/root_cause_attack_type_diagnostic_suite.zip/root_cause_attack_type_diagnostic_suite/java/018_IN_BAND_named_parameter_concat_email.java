import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){ tenantId=t; actorId=a; } }

public class UnsafeNamedParameterConcat {
    private final org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate jdbc;
    public UnsafeNamedParameterConcat(org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }
    public Object search(RequestCtx ctx, String email) {
        String sql = "SELECT id,email FROM users WHERE tenant_id=:tenant AND email='" + email + "'";
        Map<String,Object> p = new HashMap<>();
        p.put("tenant", ctx.tenantId);
        return jdbc.queryForList(sql, p);
    }
}
