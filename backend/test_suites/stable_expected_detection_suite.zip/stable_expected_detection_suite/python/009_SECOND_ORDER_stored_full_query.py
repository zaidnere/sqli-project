def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class StoredQueryRunner:
    def __init__(self, conn):
        self.conn = conn

    def load_query(self, request):
        row = self.conn.execute(
            "SELECT sql_body FROM stored_queries WHERE tenant_id=? AND query_key=?",
            [request["tenant"], norm(request.get("key"))]
        ).fetchone()
        return row["sql_body"] if row else ""

    def execute_query(self, request):
        sql = self.load_query(request)
        return self.conn.execute(sql).fetchall()
