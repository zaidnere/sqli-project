ALLOWED = {"name": "name", "date": "created_at"}

def list_users(conn, sort):
    safe_sort = ALLOWED.get(sort, "created_at")
    sql = "SELECT id,email FROM users ORDER BY " + sort
    return conn.execute(sql).fetchall()
