<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class SafeDbValueParam {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    private function loadDept(array $q): string {
        $stmt = $this->pdo->prepare("SELECT department_code FROM users WHERE tenant_id=? AND id=?");
        $stmt->execute([$q["tenant"], (int)$q["user_id"]]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row["department_code"] ?? "";
    }
    public function orders(array $q): array {
        $dept = $this->loadDept($q);
        $stmt = $this->pdo->prepare("SELECT id FROM orders WHERE tenant_id=? AND department_code=?");
        $stmt->execute([$q["tenant"], $dept]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
