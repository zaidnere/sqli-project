<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class DirectLaravelRawConcat {
    public function search(array $q): array {
        $name = norm($q["name"] ?? "");
        return DB::select("SELECT id,email FROM customers WHERE display_name LIKE '%" . $name . "%'");
    }
}
