
def active_fn_hfuyexe(request, conn):
    token_jpnjsfn = request.GET.get("token", "")
    sql_izjdftn = "SELECT id FROM sessions WHERE token = '" + token_jpnjsfn + "'"
    row = conn.execute(sql_izjdftn).fetchone()
    return row is not None
