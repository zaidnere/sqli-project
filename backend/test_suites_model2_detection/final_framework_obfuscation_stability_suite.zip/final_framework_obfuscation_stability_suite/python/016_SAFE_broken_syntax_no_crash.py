# Broken syntax sample; scanner should not crash.
def broken(
    x = "SELECT * FROM users WHERE id = ?"
