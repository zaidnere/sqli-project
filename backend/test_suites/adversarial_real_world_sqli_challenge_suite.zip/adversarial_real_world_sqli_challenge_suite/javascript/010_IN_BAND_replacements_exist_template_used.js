function norm(v){ return v === undefined || v === null ? "" : String(v).trim(); }
function clamp(v, lo, hi){ const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(){ }

class Repo {
  async run(sequelize, req) {
    const email = norm(req.query.email);
    const replacements = { email };
    const sql = `SELECT id,email FROM users WHERE email='${email}'`;
    return sequelize.query(sql, { replacements });
  }
}
module.exports = Repo;
