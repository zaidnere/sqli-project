
def active_fn_lpsdint(request, conn):
    token_icxtkaf = request.GET.get("token", "")
    sql_ayfsabj = "SELECT id FROM sessions WHERE token = '" + token_icxtkaf + "'"
    row = conn.execute(sql_ayfsabj).fetchone()
    return row is not None
