
def load_okoyowa(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_gjdabvl(request, conn):
    frag_bkbsmmp = load_okoyowa(conn, request.user.tenant_id)
    sql_iffpexb = "SELECT * FROM audit_log WHERE " + frag_bkbsmmp
    return conn.execute(sql_iffpexb).fetchall()
