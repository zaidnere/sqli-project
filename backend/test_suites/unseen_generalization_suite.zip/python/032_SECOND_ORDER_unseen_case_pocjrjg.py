
def load_zciqhew(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_eqbslxj(request, conn):
    frag_agzqyhi = load_zciqhew(conn, request.user.tenant_id)
    sql_yxejefa = "SELECT * FROM audit_log WHERE " + frag_agzqyhi
    return conn.execute(sql_yxejefa).fetchall()
