package com.enterprise.security.sqli.finalsuite;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

class RequestContext {
    final String tenantId;
    final String actorId;
    final String requestId;
    RequestContext(String tenantId, String actorId, String requestId) {
        this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId;
    }
}
class AuditLogger {
    void info(RequestContext ctx, String action, Map<String, Object> details) {
        System.out.println(Instant.now() + " tenant=" + ctx.tenantId + " action=" + action + " details=" + details);
    }
}
class InputUtil {
    static String clean(String value) { return value == null ? "" : value.trim(); }
    static int clampInt(String value, int low, int high, int fallback) {
        try { return Math.max(low, Math.min(high, Integer.parseInt(value))); }
        catch (Exception ex) { return fallback; }
    }
}

public class StoredQueryRunner {
    private final Connection connection;
    public StoredQueryRunner(Connection connection) { this.connection = connection; }
    String loadSql(RequestContext ctx, String key) throws Exception { PreparedStatement ps = connection.prepareStatement("SELECT sql_body FROM stored_queries WHERE tenant_id = ? AND query_key = ?"); ps.setString(1, ctx.tenantId); ps.setString(2, key); ResultSet rs = ps.executeQuery(); return rs.next() ? rs.getString("sql_body") : ""; }
    public ResultSet run(RequestContext ctx, String key) throws Exception { String sql = loadSql(ctx, key); return connection.createStatement().executeQuery(sql); }
}
