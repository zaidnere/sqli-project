# Final Framework / Obfuscation / Stability SQLi Suite

Total runner-compatible cases: 64

This suite is designed for the normal SQLi runner and includes only supported file extensions in `manifest.csv`:
- Python
- JavaScript
- Java
- PHP

It also includes `manual_unsupported_files/` with TXT, TS, CS, JSON, XML, MD, empty, Hebrew comments, and binary-like content.
Those files are intentionally NOT listed in `manifest.csv`, because the normal runner may reject unsupported extensions.
Use them manually to test upload validation / no-crash behavior.

Focus areas:
- Framework APIs: Django raw, SQLAlchemy text, Sequelize, Knex, Spring JdbcTemplate, JPA nativeQuery, Laravel DB::select
- Direct API vs detector parity
- Obfuscation: aliases, helper functions, generic variable names
- Huge files around 1000 helper functions/lines
- Multi-query files with one unsafe query
- Safe false-positive pressure: comments, Hebrew comments, decoy variables, allowlists
- Broken syntax no-crash cases
- Interprocedural second-order flows
- Blind auth/permission/token/session/feature checks
