class SecondOrderFragmentRunner:
    def __init__(self, db, cache=None): self.db = db; self.cache = cache
    def run(self, req):
        row = self.db.execute("SELECT where_clause FROM saved_filters WHERE id=?", [req.args.get("filter")]).fetchone()
        a = row["where_clause"] if row else "1=1"
        b = a
        return self.db.execute("SELECT id,email FROM users WHERE " + b).fetchall()
