class Repo:
    def __init__(self, qb): self.qb = qb
    def find(self, req):
        return self.qb.table("users").where("tenant_id", "=", req.tenant_id).where("email", "=", req.args.get("email","")).select(["id","email"])
