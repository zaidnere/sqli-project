class UnsafeSearchRepository:
    def __init__(self, db): self.db = db
    def search(self, req):
        value = req.args.get("q", req.args.get("email", ""))
        sql = f"SELECT id,email FROM users WHERE email LIKE '%{value}%'"
        return self.db.execute(sql).fetchall()
