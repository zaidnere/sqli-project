
def active_fn_tarlvlu(request, conn):
    token_ucgduwi = request.GET.get("token", "")
    sql_ewipgjz = "SELECT id FROM sessions WHERE token = '" + token_ucgduwi + "'"
    row = conn.execute(sql_ewipgjz).fetchone()
    return row is not None
