function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class UnsafeTemplate {
  constructor(db) { this.db = db; }

  async search(req) {
    const email = norm(req.query.email);
    const sql = `SELECT id,email FROM users WHERE email='${email}'`;
    return this.db.all(sql);
  }
}
module.exports = UnsafeTemplate;
