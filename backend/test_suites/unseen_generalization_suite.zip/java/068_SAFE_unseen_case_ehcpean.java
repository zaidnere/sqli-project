
import java.sql.*; import java.util.*;
class Repoxyfxvuz {
  List<String> list(HttpServletRequest req, Connection c) throws Exception {
    Set<String> allowed = Set.of("created_at", "email", "name");
    String sort = allowed.contains(req.getParameter("sort")) ? req.getParameter("sort") : "created_at";
    int limit = Math.min(Math.max(Integer.parseInt(req.getParameter("limit")), 1), 100);
    String sql = "SELECT id,email FROM users WHERE tenant_id = ? ORDER BY " + sort + " LIMIT ?";
    PreparedStatement ps = c.prepareStatement(sql);
    ps.setString(1, req.getUserPrincipal().getName());
    ps.setInt(2, limit);
    ps.executeQuery();
    return List.of();
  }
}
