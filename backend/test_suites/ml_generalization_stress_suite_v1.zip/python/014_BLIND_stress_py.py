class Ping:
    def __init__(self, db): self.db = db
    def ping(self, req):
        marker = req.args.get("marker","")
        self.db.execute("SELECT CASE WHEN ('" + marker + "'='slow') THEN pg_sleep(3) ELSE 1 END")
        return True
