import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class PermissionService {
    private final Connection c;
    public PermissionService(Connection c) { this.c = c; }

    public boolean canExport(String report) throws Exception {
        String sql = "SELECT COUNT(*) FROM permissions WHERE report_key='" + report + "'";
        ResultSet rs = c.createStatement().executeQuery(sql);
        return rs.next() && rs.getInt(1) > 0;
    }
}
