import java.sql.*;
public class SOCachedOrder {
  private final Connection c; private final Cache cache; public SOCachedOrder(Connection c,Cache cache){this.c=c;this.cache=cache;}
  public ResultSet list(String tenant)throws SQLException{ TenantConfig cfg=cache.getTenantConfig(tenant); return c.createStatement().executeQuery("SELECT id FROM users ORDER BY "+cfg.orderClause); }
  interface Cache{ TenantConfig getTenantConfig(String t); } static class TenantConfig{ String orderClause; }
}
