public class HealthService {
    public String status() {
        return "OK";
    }
}
