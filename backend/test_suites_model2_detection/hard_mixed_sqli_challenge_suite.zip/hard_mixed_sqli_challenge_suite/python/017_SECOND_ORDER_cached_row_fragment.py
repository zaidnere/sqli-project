_CACHE = {}

def load_filter(conn, key):
    row = conn.execute("SELECT fragment FROM saved_filters WHERE name=?", (key,)).fetchone()
    _CACHE[key] = row[0]

def search(conn, key):
    sql = "SELECT * FROM products WHERE tenant_id=1 AND " + _CACHE[key]
    return conn.execute(sql).fetchall()
