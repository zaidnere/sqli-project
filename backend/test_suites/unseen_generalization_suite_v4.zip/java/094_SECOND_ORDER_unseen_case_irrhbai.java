
import java.sql.*;
class Auditdfhctvz {
  String load(Connection c, String id) throws Exception {
    PreparedStatement ps = c.prepareStatement("SELECT where_clause FROM reports WHERE id=?");
    ps.setString(1, id);
    ResultSet rs = ps.executeQuery(); rs.next(); return rs.getString("where_clause");
  }
  ResultSet run(Connection c, Statement st, String id) throws Exception {
    String where = load(c, id);
    String sql = "SELECT * FROM audit_log WHERE " + where;
    return st.executeQuery(sql);
  }
}
