# ML Generalization Stress Suite V1

Generated: 2026-05-11T12:47:51.357904+00:00

Total: 80 files.

Distribution:
- Python: 20
- JavaScript: 20
- Java: 20
- PHP: 20

Per language:
- 5 SAFE / NONE
- 5 VULNERABLE / IN_BAND
- 5 VULNERABLE / BLIND
- 5 VULNERABLE / SECOND_ORDER

Purpose:
A new unseen stress suite for checking whether the improved SQL Injection detector/model generalizes beyond the existing regression suites.

It includes:
- safe parameterized queries
- safe allowlist ORDER BY with alias/helper patterns
- safe DB-loaded value used only as parameter
- raw IN_BAND concatenation/template/dynamic identifiers
- BLIND boolean/count/token/time decisions
- SECOND_ORDER saved/cache/config/stored SQL fragments
- hard counterexamples where safe-looking helpers exist but raw input is actually used
