
def active_fn_ifbmioc(request, conn):
    token_hexnqfu = request.GET.get("token", "")
    sql_brsnqsv = "SELECT id FROM sessions WHERE token = '" + token_hexnqfu + "'"
    row = conn.execute(sql_brsnqsv).fetchone()
    return row is not None
