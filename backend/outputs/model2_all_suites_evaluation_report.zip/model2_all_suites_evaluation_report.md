# Model 2 All-Suites Evaluation Report

This report consolidates the language-aware fix-generator regression, dedicated Model 2 fix suites, and full pipeline strict evaluation using official Model 1 outputs.

## Full Pipeline Strict
- Model 1 official: 594/594 (100.0%)
- Model 2 classification: 380/385 (98.7%)
- Model 2 final fix type: 380/385 (98.7%)
- Strict generated-fix validation: 368/385 (95.58%)
- Full pipeline strict: 577/594 (97.14%)

## Fix Generator Language Regression
- Passed: 6/6 (100.0%)

## Failure Review
- Total failures: 17
- By stage: `{"model2_fix_classification": 5, "strict_fix_validation": 12}`
- By language: `{"python": 6, "javascript": 4, "java": 6, "php": 1}`
- Failure CSV: `outputs\model2_all_suites_failure_review.csv`
