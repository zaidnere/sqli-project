import sqlite3
ALLOWED_COLUMNS = {"id", "username", "created_at"}

def pick_allowed(value, allowed, default):
    return value if value in allowed else default

def list_users(conn, sort_by):
    safe_col = pick_allowed(sort_by, ALLOWED_COLUMNS, "created_at")
    sql = f"SELECT id, username FROM users ORDER BY {sort_by}"
    cur = conn.cursor()
    cur.execute(sql)
    return cur.fetchall()
