// db.all(`SELECT * FROM users WHERE email='${req.query.email}'`)
function debug(req) {
  const sqlLike = "SELECT id FROM users WHERE email='" + req.query.email + "'";
  return { text: sqlLike };
}
module.exports = { debug };
