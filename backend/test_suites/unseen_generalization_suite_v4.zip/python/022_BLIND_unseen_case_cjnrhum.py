
def active_fn_hwoirzs(request, conn):
    token_spmmmty = request.GET.get("token", "")
    sql_uqfyphi = "SELECT id FROM sessions WHERE token = '" + token_spmmmty + "'"
    row = conn.execute(sql_uqfyphi).fetchone()
    return row is not None
