<?php
interface ConfigService { public function load(string $tenant): object; }
final class Repo { public function __construct(private PDO $pdo, private ConfigService $config) {} public function list(string $tenant): array { $cfg=$this->config->load($tenant); $order=$cfg->orderClause??"created_at DESC"; $s=$this->pdo->prepare("SELECT id FROM users WHERE tenant_id=? ORDER BY ".$order); $s->execute([$tenant]); return $s->fetchAll(PDO::FETCH_ASSOC); } }
