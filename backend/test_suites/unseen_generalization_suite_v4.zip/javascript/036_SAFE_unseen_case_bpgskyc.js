
// noise comment with SQL_CONCAT looking words but no sink
async function list_fn_rqeglhk(req, db) {
  const allowed = new Set(["created_at", "email", "name"]);
  const sort_tywodit = allowed.has(req.query.sort) ? req.query.sort : "created_at";
  const limit = Math.min(Math.max(Number(req.query.limit || 25), 1), 100);
  const sql = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + sort_tywodit + " LIMIT ?";
  const decoy = `SELECT * FROM users WHERE email = '${req.query.email}'`;
  const params_nqkwdaw = [req.user.tenantId, limit];
  return db.all(sql, params_nqkwdaw);
}
