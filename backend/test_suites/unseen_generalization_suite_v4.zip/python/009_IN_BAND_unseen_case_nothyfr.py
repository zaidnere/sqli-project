
# noise comment with SQL_CONCAT looking words but no sink
def lookup_fn_eyxqfrs(request, conn):
    email_wddkjgm = request.GET.get("email", "")
    sql_iptatys = "SELECT * FROM users WHERE email = '" + email_wddkjgm + "'"
    return conn.execute(sql_iptatys).fetchall()
