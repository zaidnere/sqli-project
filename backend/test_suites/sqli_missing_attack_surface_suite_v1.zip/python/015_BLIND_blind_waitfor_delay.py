class Check:
    def __init__(self, db): self.db = db
    def run(self, req):
        token = req.args.get("token","")
        self.db.execute("IF EXISTS(SELECT 1 FROM api_tokens WHERE token='" + token + "') WAITFOR DELAY '00:00:03'")
        return True
