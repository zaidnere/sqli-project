const crypto = require("crypto");

function normalizeText(value) {
  if (value === undefined || value === null) return "";
  return String(value).trim();
}
function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function clamp(value, low, high) {
  const n = toNumber(value, low);
  return Math.max(low, Math.min(high, n));
}
function audit(logger, ctx, action, details) {
  if (logger && logger.info) logger.info({ tenantId: ctx.tenantId, actorId: ctx.actorId, requestId: ctx.requestId, action, details });
}
function stableKey(prefix, value) {
  return `${prefix}_${crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 12)}`;
}
class RequestContext {
  constructor(tenantId, actorId, requestId) { this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId; }
}

class BillingRepository {
  constructor(db, logger) { this.db = db; this.logger = logger; this.sorts = new Map([["created","b.created_at"],["amount","b.amount_cents"],["status","b.status"]]); }
  async list(ctx, query) {
    const requested = normalizeText(query.sort) || "created";
    const sortCol = this.sorts.get(requested) || "b.created_at";
    const direction = normalizeText(query.dir).toLowerCase() === "asc" ? "ASC" : "DESC";
    const limit = clamp(query.limit ?? 50, 1, 200);
    const offset = clamp(query.offset ?? 0, 0, 10000);
    let sql = `SELECT b.id, b.invoice_no, b.status, b.amount_cents FROM bills b WHERE b.tenant_id = ?`;
    const params = [ctx.tenantId];
    if (query.status) { sql += " AND b.status = ?"; params.push(normalizeText(query.status)); }
    sql += ` ORDER BY ${sortCol} ${direction} LIMIT ${limit} OFFSET ${offset}`;
    audit(this.logger, ctx, "billing.list", { sortCol, limit, offset });
    return this.db.all(sql, params);
  }
}
module.exports = { BillingRepository };
