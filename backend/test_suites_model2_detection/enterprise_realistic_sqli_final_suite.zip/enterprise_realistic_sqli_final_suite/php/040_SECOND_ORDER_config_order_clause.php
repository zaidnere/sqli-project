<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class ConfiguredLeaderboardRepository {
    private PDO $pdo; public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function orderClause(array $ctx): string { $stmt = $this->pdo->prepare("SELECT value FROM tenant_config WHERE tenant_id = ? AND name = ?"); $stmt->execute([$ctx["tenant"], "leaderboard_order"]); $row = $stmt->fetch(PDO::FETCH_ASSOC); return $row["value"] ?? "score DESC"; }
    public function list(array $ctx): array { $order = $this->orderClause($ctx); $sql = "SELECT user_id, score FROM leaderboard WHERE tenant_id = ? ORDER BY " . $order . " LIMIT 100"; $stmt = $this->pdo->prepare($sql); $stmt->execute([$ctx["tenant"]]); return $stmt->fetchAll(PDO::FETCH_ASSOC); }
}
