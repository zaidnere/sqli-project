
def load_cunnoho(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_xsmlymu(request, conn):
    frag_zxbjipo = load_cunnoho(conn, request.user.tenant_id)
    sql_iebnnyk = "SELECT * FROM audit_log WHERE " + frag_zxbjipo
    return conn.execute(sql_iebnnyk).fetchall()
