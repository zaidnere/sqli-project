
def load_szarwzm(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_uhdkgmu(request, conn):
    frag_wqivvov = load_szarwzm(conn, request.user.tenant_id)
    sql_rcewkqk = "SELECT * FROM audit_log WHERE " + frag_wqivvov
    return conn.execute(sql_rcewkqk).fetchall()
