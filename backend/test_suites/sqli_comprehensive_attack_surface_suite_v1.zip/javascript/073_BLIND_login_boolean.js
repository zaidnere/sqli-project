class Check{ constructor(db){this.db=db;} async allowed(req){ const key=String(req.query.key||req.body?.email||""); const rows=await this.db.all("SELECT id FROM security_checks WHERE lookup_key='"+key+"'"); return rows.length>0; } }
module.exports=Check;
