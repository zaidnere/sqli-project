<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class SafePdoParameterizedCountBoolGuard {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function canExport(array $q): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) AS c FROM permissions WHERE tenant_id=? AND report_key=?");
        $stmt->execute([$q["tenant"], norm($q["report"] ?? "")]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row && (int)$row["c"] > 0;
    }
}
