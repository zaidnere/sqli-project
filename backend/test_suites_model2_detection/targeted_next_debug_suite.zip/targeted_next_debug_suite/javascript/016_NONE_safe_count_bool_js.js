async function isEmailRegisteredSafe(db, email) {
  const sql = "SELECT COUNT(*) AS c FROM users WHERE email = ?";
  const row = await db.get(sql, [email]);
  return row.c > 0;
}
module.exports = { isEmailRegisteredSafe };
