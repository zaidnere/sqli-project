class Repo{ constructor(db){this.db=db;} async byIds(ids){ const clean=ids.map(Number).filter(Number.isFinite); const marks=clean.map(()=>"?").join(","); return this.db.all(`SELECT id,sku FROM inventory WHERE id IN (${marks})`, clean); } }
module.exports=Repo;
