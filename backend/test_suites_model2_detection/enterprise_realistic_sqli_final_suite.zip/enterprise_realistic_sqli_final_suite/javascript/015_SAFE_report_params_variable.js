const crypto = require("crypto");

function normalizeText(value) {
  if (value === undefined || value === null) return "";
  return String(value).trim();
}
function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function clamp(value, low, high) {
  const n = toNumber(value, low);
  return Math.max(low, Math.min(high, n));
}
function audit(logger, ctx, action, details) {
  if (logger && logger.info) logger.info({ tenantId: ctx.tenantId, actorId: ctx.actorId, requestId: ctx.requestId, action, details });
}
function stableKey(prefix, value) {
  return `${prefix}_${crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 12)}`;
}
class RequestContext {
  constructor(tenantId, actorId, requestId) { this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId; }
}

class ReportRepository {
  constructor(db) { this.db = db; }
  async ledger(ctx, args) {
    const from = normalizeText(args.from);
    const to = normalizeText(args.to);
    const params = [ctx.tenantId, from, to];
    const sql = `SELECT account_id, SUM(amount_cents) AS total FROM ledger_entries WHERE tenant_id = ? AND posted_at >= ? AND posted_at < ? GROUP BY account_id ORDER BY total DESC`;
    return this.db.all(sql, params);
  }
}
module.exports = { ReportRepository };
