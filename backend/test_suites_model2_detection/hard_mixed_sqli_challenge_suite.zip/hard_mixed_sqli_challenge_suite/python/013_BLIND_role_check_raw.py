def can_delete(conn, username):
    sql = "SELECT role FROM users WHERE username='" + username + "'"
    row = conn.execute(sql).fetchone()
    return row is not None and row[0] == "admin"
