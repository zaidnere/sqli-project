
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def search_fn_fwaudyy(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_nfydlsq = allowed.get(request.GET.get("sort"), "created_at")
    limit_sdyytfy = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_xitkxey = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + order_nfydlsq + " LIMIT ?"
    decoy = "SELECT * FROM users WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_xitkxey, (request.user.tenant_id, limit_sdyytfy)).fetchall()
