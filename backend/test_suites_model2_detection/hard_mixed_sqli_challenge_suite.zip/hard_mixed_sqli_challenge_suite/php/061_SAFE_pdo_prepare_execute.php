<?php
function findUser($pdo, $email) {
    $stmt = $pdo->prepare("SELECT id,email FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetchAll();
}
?>
