class Repo{ constructor(db){this.db=db;} async lookup(req){ const ids=String(req.query.ids||"").split(",").join(",");
 return this.db.all("SELECT id FROM inv WHERE id IN ("+ids+")"); } }
module.exports=Repo;
