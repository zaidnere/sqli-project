def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class Migration:
    def __init__(self, conn):
        self.conn = conn

    def migrate(self):
        script = '''
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY,
            action TEXT NOT NULL
        );
        '''
        self.conn.executescript(script)
        return True
