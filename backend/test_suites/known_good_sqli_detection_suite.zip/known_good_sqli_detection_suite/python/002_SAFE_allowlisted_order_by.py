def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class UserList:
    SORTS = {"created": "created_at", "email": "email", "name": "display_name"}

    def __init__(self, conn):
        self.conn = conn

    def list_users(self, request):
        sort = self.SORTS.get(norm(request.get("sort")), "created_at")
        sql = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + sort
        return self.conn.execute(sql, [request["tenant"]]).fetchall()
