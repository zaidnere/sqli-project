import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class LoginService {
    private final Connection c;
    public LoginService(Connection c) { this.c = c; }

    public boolean login(String username, String passwordHash) throws Exception {
        String sql = "SELECT id FROM users WHERE username='" + username + "' AND password_hash='" + passwordHash + "'";
        ResultSet rs = c.createStatement().executeQuery(sql);
        return rs.next();
    }
}
