function norm(v) { return v === undefined || v === null ? '' : String(v).trim(); }
function clamp(v, lo, hi) { const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(logger, ctx, action, details) { if (logger) logger.info({ctx, action, details}); }

function helper0(value) { return { idx: 0, value, at: new Date().toISOString() }; }
function helper1(value) { return { idx: 1, value, at: new Date().toISOString() }; }
function helper2(value) { return { idx: 2, value, at: new Date().toISOString() }; }
function helper3(value) { return { idx: 3, value, at: new Date().toISOString() }; }
function helper4(value) { return { idx: 4, value, at: new Date().toISOString() }; }
function helper5(value) { return { idx: 5, value, at: new Date().toISOString() }; }
function helper6(value) { return { idx: 6, value, at: new Date().toISOString() }; }
function helper7(value) { return { idx: 7, value, at: new Date().toISOString() }; }
function helper8(value) { return { idx: 8, value, at: new Date().toISOString() }; }
function helper9(value) { return { idx: 9, value, at: new Date().toISOString() }; }
function helper10(value) { return { idx: 10, value, at: new Date().toISOString() }; }
function helper11(value) { return { idx: 11, value, at: new Date().toISOString() }; }
function helper12(value) { return { idx: 12, value, at: new Date().toISOString() }; }
function helper13(value) { return { idx: 13, value, at: new Date().toISOString() }; }
function helper14(value) { return { idx: 14, value, at: new Date().toISOString() }; }
function helper15(value) { return { idx: 15, value, at: new Date().toISOString() }; }
function helper16(value) { return { idx: 16, value, at: new Date().toISOString() }; }
function helper17(value) { return { idx: 17, value, at: new Date().toISOString() }; }
function helper18(value) { return { idx: 18, value, at: new Date().toISOString() }; }
function helper19(value) { return { idx: 19, value, at: new Date().toISOString() }; }
function helper20(value) { return { idx: 20, value, at: new Date().toISOString() }; }
function helper21(value) { return { idx: 21, value, at: new Date().toISOString() }; }
function helper22(value) { return { idx: 22, value, at: new Date().toISOString() }; }
function helper23(value) { return { idx: 23, value, at: new Date().toISOString() }; }
function helper24(value) { return { idx: 24, value, at: new Date().toISOString() }; }
function helper25(value) { return { idx: 25, value, at: new Date().toISOString() }; }
function helper26(value) { return { idx: 26, value, at: new Date().toISOString() }; }
function helper27(value) { return { idx: 27, value, at: new Date().toISOString() }; }
function helper28(value) { return { idx: 28, value, at: new Date().toISOString() }; }
function helper29(value) { return { idx: 29, value, at: new Date().toISOString() }; }
function helper30(value) { return { idx: 30, value, at: new Date().toISOString() }; }
function helper31(value) { return { idx: 31, value, at: new Date().toISOString() }; }
function helper32(value) { return { idx: 32, value, at: new Date().toISOString() }; }
function helper33(value) { return { idx: 33, value, at: new Date().toISOString() }; }
function helper34(value) { return { idx: 34, value, at: new Date().toISOString() }; }
function helper35(value) { return { idx: 35, value, at: new Date().toISOString() }; }
function helper36(value) { return { idx: 36, value, at: new Date().toISOString() }; }
function helper37(value) { return { idx: 37, value, at: new Date().toISOString() }; }
function helper38(value) { return { idx: 38, value, at: new Date().toISOString() }; }
function helper39(value) { return { idx: 39, value, at: new Date().toISOString() }; }
function helper40(value) { return { idx: 40, value, at: new Date().toISOString() }; }
function helper41(value) { return { idx: 41, value, at: new Date().toISOString() }; }
function helper42(value) { return { idx: 42, value, at: new Date().toISOString() }; }
function helper43(value) { return { idx: 43, value, at: new Date().toISOString() }; }
function helper44(value) { return { idx: 44, value, at: new Date().toISOString() }; }
function helper45(value) { return { idx: 45, value, at: new Date().toISOString() }; }
function helper46(value) { return { idx: 46, value, at: new Date().toISOString() }; }
function helper47(value) { return { idx: 47, value, at: new Date().toISOString() }; }
function helper48(value) { return { idx: 48, value, at: new Date().toISOString() }; }
function helper49(value) { return { idx: 49, value, at: new Date().toISOString() }; }
function helper50(value) { return { idx: 50, value, at: new Date().toISOString() }; }
function helper51(value) { return { idx: 51, value, at: new Date().toISOString() }; }
function helper52(value) { return { idx: 52, value, at: new Date().toISOString() }; }
function helper53(value) { return { idx: 53, value, at: new Date().toISOString() }; }
function helper54(value) { return { idx: 54, value, at: new Date().toISOString() }; }
function helper55(value) { return { idx: 55, value, at: new Date().toISOString() }; }
function helper56(value) { return { idx: 56, value, at: new Date().toISOString() }; }
function helper57(value) { return { idx: 57, value, at: new Date().toISOString() }; }
function helper58(value) { return { idx: 58, value, at: new Date().toISOString() }; }
function helper59(value) { return { idx: 59, value, at: new Date().toISOString() }; }
function helper60(value) { return { idx: 60, value, at: new Date().toISOString() }; }
function helper61(value) { return { idx: 61, value, at: new Date().toISOString() }; }
function helper62(value) { return { idx: 62, value, at: new Date().toISOString() }; }
function helper63(value) { return { idx: 63, value, at: new Date().toISOString() }; }
function helper64(value) { return { idx: 64, value, at: new Date().toISOString() }; }
function helper65(value) { return { idx: 65, value, at: new Date().toISOString() }; }
function helper66(value) { return { idx: 66, value, at: new Date().toISOString() }; }
function helper67(value) { return { idx: 67, value, at: new Date().toISOString() }; }
function helper68(value) { return { idx: 68, value, at: new Date().toISOString() }; }
function helper69(value) { return { idx: 69, value, at: new Date().toISOString() }; }
function helper70(value) { return { idx: 70, value, at: new Date().toISOString() }; }
function helper71(value) { return { idx: 71, value, at: new Date().toISOString() }; }
function helper72(value) { return { idx: 72, value, at: new Date().toISOString() }; }
function helper73(value) { return { idx: 73, value, at: new Date().toISOString() }; }
function helper74(value) { return { idx: 74, value, at: new Date().toISOString() }; }
function helper75(value) { return { idx: 75, value, at: new Date().toISOString() }; }
function helper76(value) { return { idx: 76, value, at: new Date().toISOString() }; }
function helper77(value) { return { idx: 77, value, at: new Date().toISOString() }; }
function helper78(value) { return { idx: 78, value, at: new Date().toISOString() }; }
function helper79(value) { return { idx: 79, value, at: new Date().toISOString() }; }
function helper80(value) { return { idx: 80, value, at: new Date().toISOString() }; }
function helper81(value) { return { idx: 81, value, at: new Date().toISOString() }; }
function helper82(value) { return { idx: 82, value, at: new Date().toISOString() }; }
function helper83(value) { return { idx: 83, value, at: new Date().toISOString() }; }
function helper84(value) { return { idx: 84, value, at: new Date().toISOString() }; }
function helper85(value) { return { idx: 85, value, at: new Date().toISOString() }; }
function helper86(value) { return { idx: 86, value, at: new Date().toISOString() }; }
function helper87(value) { return { idx: 87, value, at: new Date().toISOString() }; }
function helper88(value) { return { idx: 88, value, at: new Date().toISOString() }; }
function helper89(value) { return { idx: 89, value, at: new Date().toISOString() }; }
class CachedFilterRunner {
  constructor(db, cache) { this.db = db; this.cache = cache; }
  async getFilter(ctx, key) {
    let f = await this.cache.get(`${ctx.tenantId}:${key}:filter`);
    if (!f) {
      const row = await this.db.get("SELECT where_clause FROM saved_filters WHERE tenant_id=? AND filter_key=?", [ctx.tenantId, key]);
      f = row ? row.where_clause : "1=1";
    }
    return f;
  }
  async run(ctx, key) {
    const filter = await this.getFilter(ctx, key);
    const sql = "SELECT id,email FROM users WHERE tenant_id=? AND " + filter;
    return this.db.all(sql, [ctx.tenantId]);
  }
}
module.exports = CachedFilterRunner;
