<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class UnsafeMatchExistsButRawUsed {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function list(array $q): array {
        $safe = match (norm($q["sort"] ?? "created")) {
            "email" => "email",
            "status" => "status",
            default => "created_at",
        };
        $raw = norm($q["sort"] ?? "");
        $stmt = $this->pdo->query("SELECT id,email FROM users ORDER BY " . $raw);
        return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}
