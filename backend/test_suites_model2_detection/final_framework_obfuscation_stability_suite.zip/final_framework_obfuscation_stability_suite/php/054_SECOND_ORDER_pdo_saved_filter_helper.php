<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? '' : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int { $n = filter_var($v, FILTER_VALIDATE_INT); if ($n === false) $n = $lo; return max($lo, min($hi, $n)); }

function helper_0($value): array { return ['idx' => 0, 'value' => $value]; }
function helper_1($value): array { return ['idx' => 1, 'value' => $value]; }
function helper_2($value): array { return ['idx' => 2, 'value' => $value]; }
function helper_3($value): array { return ['idx' => 3, 'value' => $value]; }
function helper_4($value): array { return ['idx' => 4, 'value' => $value]; }
function helper_5($value): array { return ['idx' => 5, 'value' => $value]; }
function helper_6($value): array { return ['idx' => 6, 'value' => $value]; }
function helper_7($value): array { return ['idx' => 7, 'value' => $value]; }
function helper_8($value): array { return ['idx' => 8, 'value' => $value]; }
function helper_9($value): array { return ['idx' => 9, 'value' => $value]; }
function helper_10($value): array { return ['idx' => 10, 'value' => $value]; }
function helper_11($value): array { return ['idx' => 11, 'value' => $value]; }
function helper_12($value): array { return ['idx' => 12, 'value' => $value]; }
function helper_13($value): array { return ['idx' => 13, 'value' => $value]; }
function helper_14($value): array { return ['idx' => 14, 'value' => $value]; }
function helper_15($value): array { return ['idx' => 15, 'value' => $value]; }
function helper_16($value): array { return ['idx' => 16, 'value' => $value]; }
function helper_17($value): array { return ['idx' => 17, 'value' => $value]; }
function helper_18($value): array { return ['idx' => 18, 'value' => $value]; }
function helper_19($value): array { return ['idx' => 19, 'value' => $value]; }
function helper_20($value): array { return ['idx' => 20, 'value' => $value]; }
function helper_21($value): array { return ['idx' => 21, 'value' => $value]; }
function helper_22($value): array { return ['idx' => 22, 'value' => $value]; }
function helper_23($value): array { return ['idx' => 23, 'value' => $value]; }
function helper_24($value): array { return ['idx' => 24, 'value' => $value]; }
function helper_25($value): array { return ['idx' => 25, 'value' => $value]; }
function helper_26($value): array { return ['idx' => 26, 'value' => $value]; }
function helper_27($value): array { return ['idx' => 27, 'value' => $value]; }
function helper_28($value): array { return ['idx' => 28, 'value' => $value]; }
function helper_29($value): array { return ['idx' => 29, 'value' => $value]; }
function helper_30($value): array { return ['idx' => 30, 'value' => $value]; }
function helper_31($value): array { return ['idx' => 31, 'value' => $value]; }
function helper_32($value): array { return ['idx' => 32, 'value' => $value]; }
function helper_33($value): array { return ['idx' => 33, 'value' => $value]; }
function helper_34($value): array { return ['idx' => 34, 'value' => $value]; }
function helper_35($value): array { return ['idx' => 35, 'value' => $value]; }
function helper_36($value): array { return ['idx' => 36, 'value' => $value]; }
function helper_37($value): array { return ['idx' => 37, 'value' => $value]; }
function helper_38($value): array { return ['idx' => 38, 'value' => $value]; }
function helper_39($value): array { return ['idx' => 39, 'value' => $value]; }
function helper_40($value): array { return ['idx' => 40, 'value' => $value]; }
function helper_41($value): array { return ['idx' => 41, 'value' => $value]; }
function helper_42($value): array { return ['idx' => 42, 'value' => $value]; }
function helper_43($value): array { return ['idx' => 43, 'value' => $value]; }
function helper_44($value): array { return ['idx' => 44, 'value' => $value]; }
function helper_45($value): array { return ['idx' => 45, 'value' => $value]; }
function helper_46($value): array { return ['idx' => 46, 'value' => $value]; }
function helper_47($value): array { return ['idx' => 47, 'value' => $value]; }
function helper_48($value): array { return ['idx' => 48, 'value' => $value]; }
function helper_49($value): array { return ['idx' => 49, 'value' => $value]; }
function helper_50($value): array { return ['idx' => 50, 'value' => $value]; }
function helper_51($value): array { return ['idx' => 51, 'value' => $value]; }
function helper_52($value): array { return ['idx' => 52, 'value' => $value]; }
function helper_53($value): array { return ['idx' => 53, 'value' => $value]; }
function helper_54($value): array { return ['idx' => 54, 'value' => $value]; }
function helper_55($value): array { return ['idx' => 55, 'value' => $value]; }
function helper_56($value): array { return ['idx' => 56, 'value' => $value]; }
function helper_57($value): array { return ['idx' => 57, 'value' => $value]; }
function helper_58($value): array { return ['idx' => 58, 'value' => $value]; }
function helper_59($value): array { return ['idx' => 59, 'value' => $value]; }
function helper_60($value): array { return ['idx' => 60, 'value' => $value]; }
function helper_61($value): array { return ['idx' => 61, 'value' => $value]; }
function helper_62($value): array { return ['idx' => 62, 'value' => $value]; }
function helper_63($value): array { return ['idx' => 63, 'value' => $value]; }
function helper_64($value): array { return ['idx' => 64, 'value' => $value]; }
function helper_65($value): array { return ['idx' => 65, 'value' => $value]; }
function helper_66($value): array { return ['idx' => 66, 'value' => $value]; }
function helper_67($value): array { return ['idx' => 67, 'value' => $value]; }
function helper_68($value): array { return ['idx' => 68, 'value' => $value]; }
function helper_69($value): array { return ['idx' => 69, 'value' => $value]; }
final class PdoSavedFilter {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    private function loadFilter(string $tenant, int $id): string {
        $stmt = $this->pdo->prepare("SELECT where_clause FROM saved_filters WHERE tenant_id=? AND id=?");
        $stmt->execute([$tenant, $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row["where_clause"] ?? "1=1";
    }
    public function run(array $q): array {
        $where = $this->loadFilter($q["tenant"], (int)$q["id"]);
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? AND " . $where);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
