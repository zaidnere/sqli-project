import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class UnsafeTicketUpdater {
    private final Connection c;
    public UnsafeTicketUpdater(Connection c) { this.c = c; }

    public int update(long id, String status) throws Exception {
        String sql = "UPDATE tickets SET status='" + status + "' WHERE id=" + id;
        return c.createStatement().executeUpdate(sql);
    }
}
