
# decoy: SELECT * FROM users WHERE id = raw_input
def search_fn_mugbifk(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_iazfudb = allowed.get(request.GET.get("sort"), "created_at")
    limit_lckzxdo = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_nbdkiue = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + order_iazfudb + " LIMIT ?"
    decoy = "SELECT * FROM users WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_nbdkiue, (request.user.tenant_id, limit_lckzxdo)).fetchall()
