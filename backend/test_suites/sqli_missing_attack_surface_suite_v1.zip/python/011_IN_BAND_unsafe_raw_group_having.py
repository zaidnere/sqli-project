class Repo:
    def __init__(self, db): self.db = db
    def summary(self, req):
        g = req.args.get("group","")
        h = req.args.get("having","")
        return self.db.execute("SELECT " + g + ", COUNT(*) FROM orders GROUP BY " + g + " HAVING " + h).fetchall()
