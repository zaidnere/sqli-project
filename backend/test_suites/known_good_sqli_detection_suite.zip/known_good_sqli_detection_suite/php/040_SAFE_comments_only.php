<?php
// $pdo->query("SELECT * FROM users WHERE id=" . $_GET["id"]);
function debug($email): string {
    return "SELECT id FROM users WHERE email='" . $email . "'";
}
