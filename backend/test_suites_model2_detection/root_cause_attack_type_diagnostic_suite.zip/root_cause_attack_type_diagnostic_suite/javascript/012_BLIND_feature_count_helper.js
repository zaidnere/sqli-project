function norm(v){ return v===undefined || v===null ? "" : String(v).trim(); }
function clamp(v,lo,hi){ const n=Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi,n)) : lo; }
function audit(){}

class FeatureGate {
  constructor(db) { this.db = db; }
  async count(sql) {
    const row = await this.db.get(sql);
    return row ? row.c : 0;
  }
  async enabled(req) {
    const feature = norm(req.query.feature);
    const sql = "SELECT COUNT(*) AS c FROM feature_flags WHERE feature_key='" + feature + "'";
    return (await this.count(sql)) > 0;
  }
}
module.exports = FeatureGate;
