import java.sql.*;
public class SOAlias {
  private final Connection c; public SOAlias(Connection c){this.c=c;}
  public ResultSet run(String id)throws SQLException{ PreparedStatement ps=c.prepareStatement("SELECT sql_fragment FROM segments WHERE id=?"); ps.setString(1,id); ResultSet rs=ps.executeQuery(); rs.next(); String a=rs.getString("sql_fragment"); String b=a; return c.createStatement().executeQuery("SELECT * FROM audit_log WHERE "+b); }
}
