import java.sql.*;
class Case050 {
  ResultSet page(Connection c, String limit, String offset) throws Exception {
    String sql = "SELECT id FROM logs LIMIT " + limit + " OFFSET " + offset;
    return c.createStatement().executeQuery(sql);
  }
}
