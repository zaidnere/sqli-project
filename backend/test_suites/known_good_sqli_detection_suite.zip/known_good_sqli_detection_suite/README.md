# Known Good SQLi Detection Suite

Generated: 2026-05-08T13:30:33.518756Z

Total cases: 40

Purpose:
This suite contains patterns the detector is expected to handle well based on the green suites:
- SAFE parameterized queries
- SAFE allowlisted ORDER BY
- SAFE DB-loaded value as bound parameter
- IN_BAND direct raw WHERE / ORDER BY / IN list
- BLIND login/count/permission decisions
- SECOND_ORDER DB-loaded SQL fragments
- comments/strings without execution sinks

It is useful as a sanity check after changing the model, normalizer, fusion logic, or training data.
