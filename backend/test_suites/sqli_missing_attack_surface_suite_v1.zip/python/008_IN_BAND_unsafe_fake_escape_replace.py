class Repo:
    def __init__(self, db): self.db = db
    def search(self, req):
        email = req.args.get("email","").replace("'", "''")
        return self.db.execute("SELECT id,email FROM users WHERE email='" + email + "'").fetchall()
