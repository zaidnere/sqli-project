# SQLi Comprehensive Attack Surface Suite V1

Generated: 2026-05-11T13:05:13.921491+00:00

Total cases: 192

Distribution:
- Python: 48
- JavaScript: 48
- Java: 48
- PHP: 48

Per language:
- 12 SAFE / NONE
- 12 VULNERABLE / IN_BAND
- 12 VULNERABLE / BLIND
- 12 VULNERABLE / SECOND_ORDER

Purpose:
A wide pre-agent diagnostic suite covering SQL Injection attack surface and related safe counterexamples.

Coverage:
SAFE:
- prepared/parameterized queries
- named params / ORM bind / replacements
- allowlisted ORDER BY direct and via alias/helper/object
- numeric LIMIT/OFFSET bounds
- placeholder IN lists
- DB-loaded value used only as parameter
- static SQL / SQL-like strings without sink
- multi-query safe flows

IN_BAND:
- raw WHERE concatenation
- template/f-string LIKE search
- raw ORDER BY, LIMIT/OFFSET, table name, column name
- joined ID lists
- UNION-style raw search
- stacked query / script execution
- ORM raw template
- query alias execution
- allowlist exists but raw variable is used

BLIND:
- login boolean
- COUNT > 0
- row exists / permission
- token/session/API key exists
- feature flag
- time-based sleep
- CASE/boolean probes
- role/admin/password reset checks
- helper returning bool

SECOND_ORDER:
- saved filters
- cached SQL fragments
- config where/order clauses
- stored full queries
- DB fragment alias chains
- saved segment properties
- DB-loaded order expression
- profile audit fragments
- scheduled job SQL
- nested cached config
- stored procedure SQL text

Runner-compatible manifest columns:
- expected_verdict
- expected_type
- expected_label
- expected_attack_type
