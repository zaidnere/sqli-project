<?php
final class AliasChain { public function __construct(private PDO $pdo) {} public function run(int $id): array { $s=$this->pdo->prepare("SELECT where_clause FROM report_segments WHERE id=?"); $s->execute([$id]); $r=$s->fetch(PDO::FETCH_ASSOC); $a=$r["where_clause"]??"1=1"; $b=$a; return $this->pdo->query("SELECT * FROM audit_log WHERE ".$b)->fetchAll(PDO::FETCH_ASSOC); } }
