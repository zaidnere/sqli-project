
def load_fnemkbt(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_eoquwsy(request, conn):
    frag_gwmdmrw = load_fnemkbt(conn, request.user.tenant_id)
    sql_hwtjnnp = "SELECT * FROM audit_log WHERE " + frag_gwmdmrw
    return conn.execute(sql_hwtjnnp).fetchall()
