# This file intentionally has no SQL execution.
def health():
    return {'ok': True}
