const crypto = require("crypto");

function normalizeText(value) {
  if (value === undefined || value === null) return "";
  return String(value).trim();
}
function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function clamp(value, low, high) {
  const n = toNumber(value, low);
  return Math.max(low, Math.min(high, n));
}
function audit(logger, ctx, action, details) {
  if (logger && logger.info) logger.info({ tenantId: ctx.tenantId, actorId: ctx.actorId, requestId: ctx.requestId, action, details });
}
function stableKey(prefix, value) {
  return `${prefix}_${crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 12)}`;
}
class RequestContext {
  constructor(tenantId, actorId, requestId) { this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId; }
}

class SegmentRunner {
  constructor(db, logger) { this.db = db; this.logger = logger; }
  async load(ctx, id) { return this.db.get("SELECT where_clause FROM saved_segments WHERE tenant_id = ? AND id = ?", [ctx.tenantId, Number(id)]); }
  async members(ctx, id) {
    const segment = await this.load(ctx, id);
    const whereClause = segment?.where_clause || "1=1";
    const sql = `SELECT id, email, full_name FROM customers WHERE tenant_id = ? AND ${whereClause} ORDER BY created_at DESC LIMIT 500`;
    audit(this.logger, ctx, "segment.members", { id });
    return this.db.all(sql, [ctx.tenantId]);
  }
}
module.exports = { SegmentRunner };
