import java.sql.*;
class Case051 {
  boolean emailExists(Connection c, String email) throws Exception {
    String sql = "SELECT 1 FROM users WHERE email='" + email + "'";
    ResultSet rs = c.createStatement().executeQuery(sql);
    return rs.next();
  }
}
