import java.sql.*;
public class SOStoredQuery {
  private final Connection c; public SOStoredQuery(Connection c){this.c=c;}
  public ResultSet run(String job)throws SQLException{ PreparedStatement ps=c.prepareStatement("SELECT sql_body FROM jobs WHERE id=?"); ps.setString(1,job); ResultSet rs=ps.executeQuery(); rs.next(); return c.createStatement().executeQuery(rs.getString("sql_body")); }
}
