import java.sql.*; import java.util.*;
class Case049 {
  ResultSet load(Connection c, List<String> ids) throws Exception {
    String raw = String.join(",", ids);
    String sql = "SELECT * FROM invoices WHERE id IN (" + raw + ")";
    return c.createStatement().executeQuery(sql);
  }
}
