<?php
final class Repo { public function __construct(private mysqli $db) {} public function lookup(array $q): array { $ids=implode(",", $q["ids"]??[]); $r=$this->db->query("SELECT id FROM inv WHERE id IN (".$ids.")"); return $r?$r->fetch_all(MYSQLI_ASSOC):[]; } }
