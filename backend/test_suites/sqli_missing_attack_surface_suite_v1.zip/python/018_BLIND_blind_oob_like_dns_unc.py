class Check:
    def __init__(self, db): self.db = db
    def probe(self, req):
        host = req.args.get("host","")
        self.db.execute("SELECT LOAD_FILE('\\\\" + host + "\\share')")
        return True
