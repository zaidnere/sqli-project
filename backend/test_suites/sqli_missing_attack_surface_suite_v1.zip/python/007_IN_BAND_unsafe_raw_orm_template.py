class Repo:
    def __init__(self, orm): self.orm = orm
    def find(self, req):
        email = req.args.get("email","")
        return self.orm.raw(f"SELECT id,email FROM users WHERE email='{email}'")
