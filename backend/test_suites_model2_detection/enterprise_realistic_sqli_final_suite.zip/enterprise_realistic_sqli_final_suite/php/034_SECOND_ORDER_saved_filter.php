<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class SavedFilterRunner {
    private PDO $pdo; public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function loadFilter(array $ctx, int $id): array { $stmt = $this->pdo->prepare("SELECT where_clause FROM saved_filters WHERE tenant_id = ? AND id = ?"); $stmt->execute([$ctx["tenant"], $id]); $row = $stmt->fetch(PDO::FETCH_ASSOC); return $row ?: []; }
    public function run(array $ctx, int $id): array { $filter = $this->loadFilter($ctx, $id); $where = $filter["where_clause"] ?? "1=1"; $sql = "SELECT id, email FROM customers WHERE tenant_id = ? AND " . $where . " ORDER BY created_at DESC"; $stmt = $this->pdo->prepare($sql); $stmt->execute([$ctx["tenant"]]); return $stmt->fetchAll(PDO::FETCH_ASSOC); }
}
