<?php
final class Repo { public function __construct(private PDO $pdo) {}
  public function find(array $q): array { $s=$this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? AND email=?"); $s->execute([$q["tenant"], trim((string)($q["email"]??""))]); return $s->fetchAll(PDO::FETCH_ASSOC); } }
