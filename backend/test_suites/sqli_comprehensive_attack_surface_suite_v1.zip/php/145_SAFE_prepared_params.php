<?php
final class CaseRepo {
  public function __construct(private PDO $pdo) {}
  public function run(array $q): array {
    $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? AND email=?");
    $stmt->execute([$q["tenant"], trim((string)($q["email"] ?? ""))]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
}
