const cache = new Map();
async function loadFragment(db, name) {
  const row = await db.get("SELECT fragment FROM fragments WHERE name=?", [name]);
  cache.set(name, row.fragment);
}
async function queryWithFragment(db, name) {
  const sql = "SELECT * FROM products WHERE tenant_id=1 AND " + cache.get(name);
  return db.all(sql);
}
