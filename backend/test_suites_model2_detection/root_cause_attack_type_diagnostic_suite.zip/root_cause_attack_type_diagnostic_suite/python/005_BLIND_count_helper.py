def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*a): pass

class FeatureGate:
    def __init__(self, conn): self.conn = conn
    def count(self, sql):
        row = self.conn.execute(sql).fetchone()
        return row[0] if row else 0
    def enabled(self, request):
        feature = norm(request.get("feature"))
        sql = "SELECT COUNT(*) FROM feature_flags WHERE feature_key='" + feature + "'"
        return self.count(sql) > 0
