# Targeted Next Debug Suite

This suite is meant for the next round after the mega suite.

It focuses on:
- exact variable-level WHITELIST_VAR binding
- helper whitelist propagation
- placeholder-list safety
- numeric LIMIT/OFFSET safety
- cross-language BLIND detection
- cross-language SECOND_ORDER detection
- cross-language whitelist ORDER BY

Run:

```bat
py scripts/run_sqli_test_suite.py --suite test_suites/targeted_next_debug_suite.zip --email test3@test.com --password 123456
```
