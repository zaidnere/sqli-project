import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){tenantId=t;actorId=a;} }

public class JoinedIds {
    private final Connection c;
    public JoinedIds(Connection c){ this.c = c; }
    public ResultSet load(RequestCtx ctx, List<String> ids) throws Exception {
        String joined = ids.stream().collect(Collectors.joining(","));
        String sql = "SELECT id FROM users WHERE tenant_id='" + ctx.tenantId + "' AND id IN (" + joined + ")";
        return c.createStatement().executeQuery(sql);
    }
}
