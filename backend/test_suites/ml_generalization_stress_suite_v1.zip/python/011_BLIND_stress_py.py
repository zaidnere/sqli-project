class Login:
    def __init__(self, db): self.db = db
    def login(self, req):
        e = req.form.get("email",""); p = req.form.get("password","")
        row = self.db.execute(f"SELECT id FROM users WHERE email='{e}' AND password_hash='{p}'").fetchone()
        return row is not None
