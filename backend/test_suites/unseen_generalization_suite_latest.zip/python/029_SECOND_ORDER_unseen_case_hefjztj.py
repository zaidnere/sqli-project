
def load_afuihha(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_hvemwgl(request, conn):
    frag_yfyjkev = load_afuihha(conn, request.user.tenant_id)
    sql_hquuysr = "SELECT * FROM audit_log WHERE " + frag_yfyjkev
    return conn.execute(sql_hquuysr).fetchall()
