
def load_dhsgphe(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_khfppmt(request, conn):
    frag_ocgyrfb = load_dhsgphe(conn, request.user.tenant_id)
    sql_jstriwk = "SELECT * FROM audit_log WHERE " + frag_ocgyrfb
    return conn.execute(sql_jstriwk).fetchall()
