async function listOrdersSafeMap(req, db) {
  const columns = {
    created: "created_at",
    email: "email",
    name: "name"
  };

  const key = String(req.query.sort || "created").trim();
  const orderColumn = columns[key] || "created_at";
  const limit = Math.min(Math.max(Number(req.query.limit || 25), 1), 100);

  const sql = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + orderColumn + " LIMIT ?";
  return db.all(sql, [req.user.tenantId, limit]);
}

module.exports = { listOrdersSafeMap };
