import java.sql.*;
public class BlindCount {
  private final Connection c; public BlindCount(Connection c){this.c=c;}
  public boolean canExport(String report)throws SQLException{ ResultSet rs=c.createStatement().executeQuery("SELECT COUNT(*) AS c FROM permissions WHERE report_key='"+report+"'"); return rs.next() && rs.getInt("c")>0; }
}
