async function purgeTable(db, table) {
  const script = `DELETE FROM ${table}; VACUUM;`;
  return db.exec(script);
}
