function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class SafeSequelizeReplacements {
  async run(sequelize, req) {
    const sql = "SELECT id,email FROM users WHERE tenant_id=:tenant AND email=:email";
    return sequelize.query(sql, { replacements: { tenant: req.tenantId, email: norm(req.query.email) } });
  }
}
module.exports = SafeSequelizeReplacements;
