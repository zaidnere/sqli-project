function pickSort(raw){ const m={created:"created_at",email:"email",status:"status"}; return {order:m[String(raw||"created").trim()]||"created_at"}; }
class Repo{ constructor(db){this.db=db;} async list(req){ const info=pickSort(req.query.sort); const col=info.order;
  return this.db.all("SELECT id,email FROM users WHERE tenant_id=? ORDER BY "+col,[req.user.tenantId]); } }
module.exports=Repo;
