
def active_fn_ectexbt(request, conn):
    token_xcpxfkh = request.GET.get("token", "")
    sql_ulleeeq = "SELECT id FROM sessions WHERE token = '" + token_xcpxfkh + "'"
    row = conn.execute(sql_ulleeeq).fetchone()
    return row is not None
