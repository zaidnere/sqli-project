class Runner{ constructor(db,savedSegments){this.db=db;this.savedSegments=savedSegments;} async run(req){ const seg=await this.savedSegments.loadForUser(req.user.id,req.query.segmentId);
 const a=seg.sqlSegment; const b=a; return this.db.all("SELECT * FROM audit_log WHERE "+b); } }
module.exports=Runner;
