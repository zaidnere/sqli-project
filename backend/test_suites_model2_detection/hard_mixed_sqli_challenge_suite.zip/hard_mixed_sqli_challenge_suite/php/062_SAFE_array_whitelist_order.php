<?php
function listOrders($pdo, $rawSort) {
    $allowed = ["name" => "name", "created" => "created_at", "total" => "total"];
    $sort = $allowed[$rawSort] ?? "created_at";
    $stmt = $pdo->prepare("SELECT id,total FROM orders ORDER BY " . $sort);
    $stmt->execute();
    return $stmt->fetchAll();
}
?>
