class Repo{ async find(sequelize,req){ return sequelize.query("SELECT id,email FROM users WHERE tenant_id=$tenant AND email=$email",{bind:{tenant:req.user.tenantId,email:String(req.query.email||"")}}); } }
module.exports=Repo;
