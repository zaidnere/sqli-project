async function canView(db, account, project) {
  const sql = "SELECT 1 FROM permissions WHERE account='" + account + "' AND project='" + project + "'";
  return (await db.get(sql)) != null;
}
