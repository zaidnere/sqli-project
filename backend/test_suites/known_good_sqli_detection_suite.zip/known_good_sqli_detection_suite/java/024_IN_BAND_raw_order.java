import java.sql.*;
import java.util.*;

class Ctx {
    String tenantId;
    String actorId;
    Ctx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class UnsafeOrder {
    private final Connection c;
    public UnsafeOrder(Connection c) { this.c = c; }

    public ResultSet list(Ctx ctx, String rawOrder) throws Exception {
        String sql = "SELECT id,email FROM users WHERE tenant_id='" + ctx.tenantId + "' ORDER BY " + rawOrder;
        return c.createStatement().executeQuery(sql);
    }
}
