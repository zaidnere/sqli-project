function pickOrderColumn(raw) {
  const allowed = {
    created: "created_at",
    email: "email",
    status: "status"
  };
  const key = String(raw || "created").trim();
  return allowed[key] || "created_at";
}

async function listOrdersSafeHelper(req, db) {
  const orderColumn = pickOrderColumn(req.query.sort);
  const sql = `SELECT id, email FROM users WHERE tenant_id = ? ORDER BY ${orderColumn}`;
  return db.all(sql, [req.user.tenantId]);
}

module.exports = { listOrdersSafeHelper };
