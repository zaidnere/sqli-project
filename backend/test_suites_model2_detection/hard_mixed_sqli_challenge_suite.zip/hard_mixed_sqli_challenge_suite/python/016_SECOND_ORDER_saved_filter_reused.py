def run_saved_report(conn, report_id):
    row = conn.execute("SELECT filter_sql FROM reports WHERE id=?", (report_id,)).fetchone()
    filter_sql = row[0]
    sql = "SELECT id,total FROM orders WHERE " + filter_sql
    return conn.execute(sql).fetchall()
