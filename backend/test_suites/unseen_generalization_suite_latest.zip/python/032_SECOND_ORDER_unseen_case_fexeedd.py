
def load_egsnisr(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_uxhxrsv(request, conn):
    frag_ovqsswh = load_egsnisr(conn, request.user.tenant_id)
    sql_vvthwve = "SELECT * FROM audit_log WHERE " + frag_ovqsswh
    return conn.execute(sql_vvthwve).fetchall()
