function norm(v) { return v === undefined || v === null ? '' : String(v).trim(); }
function clamp(v, lo, hi) { const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(logger, ctx, action, details) { if (logger) logger.info({ctx, action, details}); }

function helper0(value) { return { idx: 0, value, at: new Date().toISOString() }; }
function helper1(value) { return { idx: 1, value, at: new Date().toISOString() }; }
function helper2(value) { return { idx: 2, value, at: new Date().toISOString() }; }
function helper3(value) { return { idx: 3, value, at: new Date().toISOString() }; }
function helper4(value) { return { idx: 4, value, at: new Date().toISOString() }; }
function helper5(value) { return { idx: 5, value, at: new Date().toISOString() }; }
function helper6(value) { return { idx: 6, value, at: new Date().toISOString() }; }
function helper7(value) { return { idx: 7, value, at: new Date().toISOString() }; }
function helper8(value) { return { idx: 8, value, at: new Date().toISOString() }; }
function helper9(value) { return { idx: 9, value, at: new Date().toISOString() }; }
function helper10(value) { return { idx: 10, value, at: new Date().toISOString() }; }
function helper11(value) { return { idx: 11, value, at: new Date().toISOString() }; }
function helper12(value) { return { idx: 12, value, at: new Date().toISOString() }; }
function helper13(value) { return { idx: 13, value, at: new Date().toISOString() }; }
function helper14(value) { return { idx: 14, value, at: new Date().toISOString() }; }
function helper15(value) { return { idx: 15, value, at: new Date().toISOString() }; }
function helper16(value) { return { idx: 16, value, at: new Date().toISOString() }; }
function helper17(value) { return { idx: 17, value, at: new Date().toISOString() }; }
function helper18(value) { return { idx: 18, value, at: new Date().toISOString() }; }
function helper19(value) { return { idx: 19, value, at: new Date().toISOString() }; }
export async function unsafe(db:any, email:string){ return db.all(`SELECT * FROM users WHERE email='${email}'`); }
