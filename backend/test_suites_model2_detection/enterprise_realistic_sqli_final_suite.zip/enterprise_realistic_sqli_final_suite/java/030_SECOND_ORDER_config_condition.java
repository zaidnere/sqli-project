package com.enterprise.security.sqli.finalsuite;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

class RequestContext {
    final String tenantId;
    final String actorId;
    final String requestId;
    RequestContext(String tenantId, String actorId, String requestId) {
        this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId;
    }
}
class AuditLogger {
    void info(RequestContext ctx, String action, Map<String, Object> details) {
        System.out.println(Instant.now() + " tenant=" + ctx.tenantId + " action=" + action + " details=" + details);
    }
}
class InputUtil {
    static String clean(String value) { return value == null ? "" : value.trim(); }
    static int clampInt(String value, int low, int high, int fallback) {
        try { return Math.max(low, Math.min(high, Integer.parseInt(value))); }
        catch (Exception ex) { return fallback; }
    }
}

public class ConfigFragmentSearch {
    private final Connection connection;
    public ConfigFragmentSearch(Connection connection) { this.connection = connection; }
    String condition(RequestContext ctx) throws Exception { PreparedStatement ps = connection.prepareStatement("SELECT value FROM tenant_config WHERE tenant_id = ? AND key_name = ?"); ps.setString(1, ctx.tenantId); ps.setString(2, "customer_search_condition"); ResultSet rs = ps.executeQuery(); return rs.next() ? rs.getString("value") : "1=1"; }
    public ResultSet search(RequestContext ctx) throws Exception { String c = condition(ctx); String sql = "SELECT id, email FROM customers WHERE tenant_id = '" + ctx.tenantId + "' AND " + c; return connection.createStatement().executeQuery(sql); }
}
