async function writeAudit(db, userId) {
  const row = await db.get("SELECT bio FROM profiles WHERE user_id = ?", [userId]);
  if (!row) return;
  const msg = `bio: ${row.bio}`;
  return db.run("INSERT INTO audit_log(message) VALUES (?)", [msg]);
}
module.exports = { writeAudit };
