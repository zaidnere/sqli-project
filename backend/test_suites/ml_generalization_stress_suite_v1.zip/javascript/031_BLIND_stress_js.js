class Perm{ constructor(db){this.db=db;} async canExport(req){ const r=String(req.query.report||"");
 const rows=await this.db.all(`SELECT id FROM permissions WHERE report_key='${r}'`); return rows.length>0; } }
module.exports=Perm;
