def load_customer_notes(conn, customer_id):
    row = conn.execute("SELECT default_status FROM customer_defaults WHERE customer_id=?", (customer_id,)).fetchone()
    status = row[0] if row else "active"
    sql = "SELECT id, note FROM notes WHERE status = ? AND customer_id = ?"
    return conn.execute(sql, (status, customer_id)).fetchall()
