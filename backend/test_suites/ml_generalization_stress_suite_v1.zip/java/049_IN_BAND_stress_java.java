import java.sql.*; import java.util.*;
public class UnsafeIds {
  private final Connection c; public UnsafeIds(Connection c){this.c=c;}
  public ResultSet lookup(List<String> ids)throws SQLException{ String joined=String.join(",",ids); return c.createStatement().executeQuery("SELECT id FROM inv WHERE id IN ("+joined+")"); }
}
