<?php
function loadDefaultStatusOrders($pdo, $customerId) {
    $stmt = $pdo->prepare("SELECT default_status FROM customer_defaults WHERE customer_id=?");
    $stmt->execute([$customerId]);
    $status = $stmt->fetchColumn() ?: "active";
    $q = $pdo->prepare("SELECT id,total FROM orders WHERE status=? AND customer_id=?");
    $q->execute([$status, $customerId]);
    return $q->fetchAll();
}
?>
