<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

function allowed_sort_column_two($raw): string {
    $map = ["created" => "created_at", "email" => "email", "status" => "status"];
    return $map[norm($raw)] ?? "created_at";
}

final class UnsafeHelperCalledButRequestUsed {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function list(array $q): array {
        $safe = allowed_sort_column_two($q["sort"] ?? "created");
        $stmt = $this->pdo->query("SELECT id,email FROM users ORDER BY " . $q["sort"]);
        return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}
