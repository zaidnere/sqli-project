<?php
function pageLogs($pdo, $limitRaw, $offsetRaw) {
    $limit = max(1, min((int)$limitRaw, 100));
    $offset = max(0, min((int)$offsetRaw, 10000));
    return $pdo->query("SELECT id,message FROM logs ORDER BY id DESC LIMIT $limit OFFSET $offset")->fetchAll();
}
?>
