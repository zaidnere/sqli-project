<?php
final class Repo { public function __construct(private PDO $pdo) {}
 private function status(string $t): string { $s=$this->pdo->prepare("SELECT default_status FROM tenant_settings WHERE tenant_id=?"); $s->execute([$t]); $r=$s->fetch(PDO::FETCH_ASSOC); return $r["default_status"]??"OPEN"; }
 public function list(array $q): array { $status=$this->status($q["tenant"]); $s=$this->pdo->prepare("SELECT id FROM orders WHERE tenant_id=? AND status=?"); $s->execute([$q["tenant"],$status]); return $s->fetchAll(PDO::FETCH_ASSOC); } }
