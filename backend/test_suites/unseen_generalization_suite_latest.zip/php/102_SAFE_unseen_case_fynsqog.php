<?php
// הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
function list_fn_ixyzgap($pdo, $q) {
    $allowed = ["created" => "created_at", "email" => "email", "name" => "name"];
    $sort = $allowed[$q["sort"] ?? "created"] ?? "created_at";
    $limit = min(max((int)($q["limit"] ?? 25), 1), 100);
    $sql = "SELECT id,email FROM users WHERE tenant_id = ? ORDER BY $sort LIMIT $limit";
    $decoy = "SELECT * FROM users WHERE email = " . ($q["email"] ?? "");
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$q["tenant"]]);
    return $stmt->fetchAll();
}
?>