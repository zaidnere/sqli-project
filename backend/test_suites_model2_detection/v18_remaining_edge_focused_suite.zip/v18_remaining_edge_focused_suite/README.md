# V18 Remaining Edge Focused Suite

Generated: 2026-05-09T21:20:40.500245Z

Total cases: 28

Purpose:
Focused suite for the remaining post-V18 issues:
1. JS allowlisted ORDER BY safe evidence and counterexamples.
2. PHP allowlisted ORDER BY safe evidence and counterexamples.
3. PHP BLIND count/boolean classification and IN_BAND counterexamples.
4. V18 second-order and Sequelize regression guards.
