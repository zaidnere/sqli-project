<?php
// $pdo->query("SELECT * FROM users WHERE id=" . $_GET["id"]);
function ok(): string {
    return "SELECT id FROM users WHERE id=" . "not executed";
}
