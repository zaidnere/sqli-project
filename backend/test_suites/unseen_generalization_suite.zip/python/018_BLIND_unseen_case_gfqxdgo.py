
def active_fn_tlktmvn(request, conn):
    token_ettsvdd = request.GET.get("token", "")
    sql_tzaqmdo = "SELECT id FROM sessions WHERE token = '" + token_ettsvdd + "'"
    row = conn.execute(sql_tzaqmdo).fetchone()
    return row is not None
