<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}

final class LoginRaw {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }

    public function login(array $q): bool {
        $email = norm($q["email"] ?? "");
        $password = norm($q["password"] ?? "");
        $r = $this->db->query("SELECT id FROM users WHERE email='" . $email . "' AND password_hash='" . $password . "'");
        return $r && $r->num_rows > 0;
    }
}
