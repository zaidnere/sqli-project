<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class AliasQuery {
    private PDO $pdo;
    public function __construct(PDO $pdo){ $this->pdo = $pdo; }
    public function search(array $q): array {
        $email = norm($q["email"] ?? "");
        $runner = [$this->pdo, "query"];
        $stmt = $runner("SELECT id,email FROM users WHERE email='" . $email . "'");
        return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}
