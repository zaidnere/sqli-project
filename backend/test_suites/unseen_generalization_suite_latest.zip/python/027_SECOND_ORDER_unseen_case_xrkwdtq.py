
def load_zfnoobv(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_xkhrzbs(request, conn):
    frag_aaazmhv = load_zfnoobv(conn, request.user.tenant_id)
    sql_vzwegss = "SELECT * FROM audit_log WHERE " + frag_aaazmhv
    return conn.execute(sql_vzwegss).fetchall()
