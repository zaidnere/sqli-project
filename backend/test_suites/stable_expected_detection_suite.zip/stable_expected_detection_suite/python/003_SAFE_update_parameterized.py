def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class ProfileUpdater:
    def __init__(self, conn):
        self.conn = conn

    def update_display_name(self, request):
        sql = "UPDATE users SET display_name = ? WHERE tenant_id = ? AND id = ?"
        return self.conn.execute(sql, [norm(request.get("name")), request["tenant"], to_int(request.get("id"))])
