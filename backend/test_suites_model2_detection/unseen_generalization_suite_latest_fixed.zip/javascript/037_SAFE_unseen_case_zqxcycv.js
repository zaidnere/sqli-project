async function listOrdersSafeSetHas(req, db) {
  const allowed = new Set(["created_at", "email", "name"]);
  const requested = String(req.query.sort || "created_at").trim();
  const orderColumn = allowed.has(requested) ? requested : "created_at";

  const sql = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + orderColumn;
  return db.all(sql, [req.user.tenantId]);
}

module.exports = { listOrdersSafeSetHas };
