<?php
function validToken($pdo, $token) {
    $sql = "SELECT id FROM reset_tokens WHERE used=0 AND token='" . $token . "'";
    return $pdo->query($sql)->fetch() !== false;
}
?>
