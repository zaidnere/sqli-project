
# decoy: SELECT * FROM users WHERE id = raw_input
def lookup_fn_oruerwh(request, conn):
    email_zeesfmc = request.GET.get("email", "")
    sql_bcibjel = "SELECT * FROM users WHERE email = '" + email_zeesfmc + "'"
    return conn.execute(sql_bcibjel).fetchall()
