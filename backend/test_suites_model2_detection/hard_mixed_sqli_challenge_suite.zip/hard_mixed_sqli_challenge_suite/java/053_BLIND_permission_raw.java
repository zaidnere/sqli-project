import java.sql.*;
class Case053 {
  boolean canEdit(Connection c, String account, String project) throws Exception {
    String sql = "SELECT 1 FROM perms WHERE account='" + account + "' AND project='" + project + "'";
    return c.createStatement().executeQuery(sql).next();
  }
}
