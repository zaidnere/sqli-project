<?php
// $pdo->query("SELECT * FROM users WHERE email='" . $_GET["email"] . "'");
function debug($email): string {
    $sqlLike = "SELECT id FROM users WHERE email='" . $email . "'";
    return $sqlLike;
}
