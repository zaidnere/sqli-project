class BlindCountRepository:
    def __init__(self, db): self.db = db
    def can_export(self, req):
        report = req.args.get("report", "")
        row = self.db.execute("SELECT COUNT(*) AS c FROM permissions WHERE report_key='" + report + "'").fetchone()
        return bool(row and row["c"] > 0)
