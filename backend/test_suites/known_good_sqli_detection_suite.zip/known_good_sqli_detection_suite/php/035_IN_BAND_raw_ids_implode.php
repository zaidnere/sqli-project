<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}

final class RawIds {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function load(array $q): array {
        $ids = $q["ids"] ?? [];
        $joined = implode(",", $ids);
        $stmt = $this->pdo->query("SELECT id,email FROM users WHERE id IN (" . $joined . ")");
        return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}
