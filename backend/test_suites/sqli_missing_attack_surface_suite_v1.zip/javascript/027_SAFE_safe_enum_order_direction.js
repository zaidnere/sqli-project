function pick(s,d){ const cols={created:"created_at",email:"email"}; const dirs={asc:"ASC",desc:"DESC"}; return {col:cols[String(s||"created")]||"created_at",dir:dirs[String(d||"asc").toLowerCase()]||"ASC"}; }
class Repo { constructor(db){this.db=db;} list(req){ const p=pick(req.query.sort,req.query.dir); return this.db.all("SELECT id,email FROM users ORDER BY "+p.col+" "+p.dir); } }
module.exports = Repo;
