<?php
final class CaseRepo {
  public function __construct(private mysqli $db) {}
  public function run(array $q): array {
    $email = trim((string)($q["email"] ?? $q["q"] ?? ""));
    $res = $this->db->query("SELECT id,email FROM users WHERE email LIKE '%" . $email . "%'");
    return $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
  }
}
