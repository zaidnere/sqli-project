async function listOrdersSafeDbValueParam(req, db) {
  const row = await db.get(
    "SELECT default_status FROM tenant_settings WHERE tenant_id = ?",
    [req.user.tenantId]
  );

  const status = row ? row.default_status : "OPEN";
  return db.all(
    "SELECT id, email FROM users WHERE tenant_id = ? AND status = ?",
    [req.user.tenantId, status]
  );
}

module.exports = { listOrdersSafeDbValueParam };
