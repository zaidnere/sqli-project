public class SafeDocsOnly {
  public String docs(){ String s="SELECT * FROM users WHERE id="+ "<raw>"; return "Example only: "+s; }
}
