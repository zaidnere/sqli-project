
def load_uhzdtch(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_xxjkakc(request, conn):
    frag_sckveok = load_uhzdtch(conn, request.user.tenant_id)
    sql_spmcnvz = "SELECT * FROM audit_log WHERE " + frag_sckveok
    return conn.execute(sql_spmcnvz).fetchall()
