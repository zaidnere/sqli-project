def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class SavedFilterRunner:
    def __init__(self, conn):
        self.conn = conn

    def load_filter(self, request):
        row = self.conn.execute(
            "SELECT where_clause FROM saved_filters WHERE tenant_id=? AND id=?",
            [request["tenant"], to_int(request.get("filter_id"))]
        ).fetchone()
        return row["where_clause"] if row else "1=1"

    def run(self, request):
        where = self.load_filter(request)
        sql = "SELECT id, email FROM users WHERE tenant_id=? AND " + where
        return self.conn.execute(sql, [request["tenant"]]).fetchall()
