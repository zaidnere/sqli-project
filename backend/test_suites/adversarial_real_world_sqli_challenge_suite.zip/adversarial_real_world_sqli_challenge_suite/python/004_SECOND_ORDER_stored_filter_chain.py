def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*args): pass

class Runner:
    def __init__(self, conn): self.conn = conn
    def load(self, args):
        row = self.conn.execute("SELECT where_clause FROM saved_filters WHERE id=?", [int(args["id"])]).fetchone()
        return row["where_clause"] if row else "1=1"
    def run(self, args):
        where = self.load(args)
        sql = "SELECT id,email FROM users WHERE tenant_id=? AND " + where
        return self.conn.execute(sql, [args["tenant"]]).fetchall()
