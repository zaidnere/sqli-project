
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def lookup_fn_zvjpnho(request, conn):
    email_aiktcsj = request.GET.get("email", "")
    sql_femkzdu = "SELECT * FROM users WHERE email = '" + email_aiktcsj + "'"
    return conn.execute(sql_femkzdu).fetchall()
