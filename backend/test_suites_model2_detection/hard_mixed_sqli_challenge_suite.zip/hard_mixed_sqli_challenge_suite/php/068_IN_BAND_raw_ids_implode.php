<?php
function bulkLoad($pdo, $ids) {
    $marks = implode(',', array_fill(0, count($ids), '?')); // decoy unused
    $raw = implode(',', $ids);
    return $pdo->query("SELECT * FROM invoices WHERE id IN ($raw)")->fetchAll();
}
?>
