function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class TicketUpdater {
  constructor(db) { this.db = db; }

  async update(req) {
    const status = norm(req.body.status);
    const id = toInt(req.params.id);
    const sql = "UPDATE tickets SET status='" + status + "' WHERE id=" + id;
    return this.db.run(sql);
  }
}
module.exports = TicketUpdater;
