
def load_hqzsxdh(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_hmkzmnw(request, conn):
    frag_fzsojfd = load_hqzsxdh(conn, request.user.tenant_id)
    sql_akhhuoh = "SELECT * FROM audit_log WHERE " + frag_fzsojfd
    return conn.execute(sql_akhhuoh).fetchall()
