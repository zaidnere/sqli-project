function norm(v){ return v === undefined || v === null ? "" : String(v).trim(); }
function clamp(v, lo, hi){ const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(){ }

class Gate {
  constructor(db){ this.db = db; }
  async canView(req){
    const resource = norm(req.query.resource);
    const sql = "SELECT id FROM permissions WHERE actor_id=? AND resource='" + resource + "'";
    const rows = await this.db.all(sql, [req.user.id]);
    return rows.length > 0;
  }
}
module.exports = Gate;
