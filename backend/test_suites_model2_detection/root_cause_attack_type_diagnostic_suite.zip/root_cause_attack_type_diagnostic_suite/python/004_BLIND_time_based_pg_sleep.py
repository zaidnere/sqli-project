def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*a): pass

class TimeProbe:
    def __init__(self, conn): self.conn = conn
    def probe(self, request):
        token = norm(request.get("token"))
        sql = "SELECT CASE WHEN token='" + token + "' THEN pg_sleep(5) ELSE 0 END FROM api_tokens"
        self.conn.execute(sql)
        return True
