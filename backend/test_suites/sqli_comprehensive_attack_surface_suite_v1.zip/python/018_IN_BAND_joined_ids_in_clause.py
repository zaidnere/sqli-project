class UnsafeInListRepository:
    def __init__(self, db): self.db = db
    def by_ids(self, req):
        ids = ",".join(req.args.getlist("id"))
        return self.db.execute("SELECT id,sku FROM inventory WHERE id IN (" + ids + ")").fetchall()
