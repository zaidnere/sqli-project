import java.sql.*;
public class UnsafeLimit {
  private final Connection c; public UnsafeLimit(Connection c){this.c=c;}
  public ResultSet page(String limit,String offset)throws SQLException{ return c.createStatement().executeQuery("SELECT id FROM users LIMIT "+limit+" OFFSET "+offset); }
}
