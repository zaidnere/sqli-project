<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class UnsafePropertyArraySafeThenRawAliasUsed {
    private PDO $pdo;
    private array $sorts = ["created" => "created_at", "email" => "email", "status" => "status"];

    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function list(array $q): array {
        $safe = $this->sorts[norm($q["sort"] ?? "created")] ?? "created_at";
        $rawAlias = norm($q["sort"] ?? "");
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? ORDER BY " . $rawAlias);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
