def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class AccountRepository:
    def __init__(self, conn):
        self.conn = conn

    def find_account(self, request):
        sql = "SELECT id, account_no, status FROM accounts WHERE tenant_id = ? AND id = ?"
        return self.conn.execute(sql, [request["tenant"], to_int(request.get("id"))]).fetchone()
