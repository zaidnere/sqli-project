# Adversarial Real-World SQLi Challenge Suite

Generated: 2026-05-07T21:40:21.312652Z

Total cases: 32

Languages:
- Python: 8
- JavaScript: 8
- Java: 8
- PHP: 8

Focus:
- helper-method flows
- aliases to execution sinks
- framework-like APIs
- allowlist used vs computed-but-unused
- DB-loaded value as parameter vs stored SQL syntax
- blind boolean/time-based behavior
- safe decoys
- comments/strings with no execution sink
