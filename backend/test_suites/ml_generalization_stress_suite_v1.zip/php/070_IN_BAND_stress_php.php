<?php
final class Repo { public function __construct(private mysqli $db) {} public function export(array $q): array { $table=trim((string)($q["table"]??"")); $r=$this->db->query("SELECT * FROM ".$table); return $r?$r->fetch_all(MYSQLI_ASSOC):[]; } }
