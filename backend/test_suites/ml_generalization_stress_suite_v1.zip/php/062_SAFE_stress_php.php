<?php
final class Repo { private array $cols=["created"=>"created_at","email"=>"email","status"=>"status"]; public function __construct(private PDO $pdo) {}
  public function list(array $q): array { $selected=$this->cols[trim((string)($q["sort"]??"created"))]??"created_at"; $final=$selected; $s=$this->pdo->prepare("SELECT id,email FROM users ORDER BY ".$final); $s->execute(); return $s->fetchAll(PDO::FETCH_ASSOC); } }
