function norm(v){ return v===undefined || v===null ? "" : String(v).trim(); }
function clamp(v,lo,hi){ const n=Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi,n)) : lo; }
function audit(){}

class BulkLookup {
  constructor(db) { this.db = db; }
  async load(req) {
    const cachedIds = req.query.ids || [];
    const joined = cachedIds.join(",");
    const sql = "SELECT id,email FROM users WHERE id IN (" + joined + ")";
    return this.db.all(sql);
  }
}
module.exports = BulkLookup;
