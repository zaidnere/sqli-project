function norm(v){ return v===undefined || v===null ? "" : String(v).trim(); }
function clamp(v,lo,hi){ const n=Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi,n)) : lo; }
function audit(){}

class SafeSequelize {
  async run(sequelize, req) {
    const savedWhere = norm(req.query.where);
    const sql = "SELECT id,email FROM users WHERE tenant_id=:tenant AND email=:email";
    audit(savedWhere);
    return sequelize.query(sql, { replacements: { tenant: req.tenantId, email: norm(req.query.email) } });
  }
}
module.exports = SafeSequelize;
