
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def search_fn_zzdbnel(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_raymwfn = allowed.get(request.GET.get("sort"), "created_at")
    limit_bohkcgt = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_fykhyth = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + order_raymwfn + " LIMIT ?"
    decoy = "SELECT * FROM users WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_fykhyth, (request.user.tenant_id, limit_bohkcgt)).fetchall()
