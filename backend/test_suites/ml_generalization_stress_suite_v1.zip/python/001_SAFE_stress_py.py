from sqlalchemy import text
class Repo:
    def __init__(self, session): self.session = session
    def find(self, tenant, email):
        return self.session.execute(
            text("SELECT id,email FROM users WHERE tenant_id=:tenant AND email=:email"),
            {"tenant": tenant, "email": email}
        ).fetchone()
