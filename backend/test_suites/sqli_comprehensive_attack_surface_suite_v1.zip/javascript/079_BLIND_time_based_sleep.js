class Probe{ constructor(db){this.db=db;} async ping(req){ const m=String(req.query.marker||""); await this.db.get(`SELECT CASE WHEN ('${m}'='slow') THEN pg_sleep(3) ELSE 1 END`); return true; } }
module.exports=Probe;
