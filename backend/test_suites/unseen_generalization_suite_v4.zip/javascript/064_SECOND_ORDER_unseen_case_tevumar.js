
async function load_seg_ptlboxs(db, id) {
  const row = await db.get("SELECT query_sql FROM saved_segments WHERE id = ?", [id]);
  return row.query_sql;
}
async function run_fn_unkpgaz(req, db) {
  const sql = await load_seg_vpqjfgz(db, req.params.id);
  return db.all(sql);
}
