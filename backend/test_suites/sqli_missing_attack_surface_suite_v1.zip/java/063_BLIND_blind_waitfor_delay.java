import java.sql.*;
public class Check { private final Connection c; public Check(Connection c){this.c=c;}
  public boolean run(String raw) throws SQLException {
    ResultSet rs = c.createStatement().executeQuery("SELECT CASE WHEN EXISTS(SELECT 1 FROM permissions WHERE resource_key='" + raw + "') THEN 1 ELSE 0 END AS ok");
    rs.next(); return rs.getInt("ok") == 1;
  }}
