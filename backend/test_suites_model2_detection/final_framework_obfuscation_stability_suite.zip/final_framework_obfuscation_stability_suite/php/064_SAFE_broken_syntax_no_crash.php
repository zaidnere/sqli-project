<?php
// Broken PHP syntax sample; scanner should not crash.
function broken( {
    $sql = "SELECT id FROM users WHERE id = ?";
