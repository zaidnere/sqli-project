
async function can_fn_ksiiceo(req, db) {
  const role = req.query.role || "";
  const sql = `SELECT id FROM permissions WHERE role = '${role}'`;
  const rows = await db.all(sql);
  return rows.length > 0;
}
