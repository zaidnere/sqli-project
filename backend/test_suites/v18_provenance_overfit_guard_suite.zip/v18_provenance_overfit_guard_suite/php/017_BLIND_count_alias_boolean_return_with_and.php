<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class BlindCountAliasBooleanReturnWithAnd {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }

    public function canExport(array $q): bool {
        $report = norm($q["report"] ?? "");
        $res = $this->db->query("SELECT COUNT(*) AS c FROM permissions WHERE report_key='" . $report . "'");
        $row = $res ? $res->fetch_assoc() : null;
        return $row && (int)$row["c"] > 0;
    }
}
