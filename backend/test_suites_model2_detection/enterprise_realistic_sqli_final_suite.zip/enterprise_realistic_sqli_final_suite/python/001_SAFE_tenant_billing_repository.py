import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Iterable

logger = logging.getLogger(__name__)

class RequestContext:
    def __init__(self, tenant_id: str, actor_id: str, request_id: str):
        self.tenant_id = tenant_id
        self.actor_id = actor_id
        self.request_id = request_id
        self.now = datetime.utcnow()

def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()

def parse_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default

def clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))

def audit(ctx: RequestContext, action: str, details: Dict[str, Any]) -> None:
    logger.info("tenant=%s actor=%s request=%s action=%s details=%s", ctx.tenant_id, ctx.actor_id, ctx.request_id, action, details)

class DomainCache:
    def __init__(self):
        self._values = {}
    def get(self, key: str) -> Optional[str]:
        return self._values.get(key)
    def set(self, key: str, value: str) -> None:
        self._values[key] = value

class BaseRepository:
    def __init__(self, conn):
        self.conn = conn
    def heartbeat(self) -> bool:
        return True
    def tenant_clause(self) -> str:
        return "tenant_id = ?"

class TenantBillingRepository(BaseRepository):
    SORTS = {"created": "b.created_at", "amount": "b.amount_cents", "status": "b.status"}
    def list_bills(self, ctx: RequestContext, args: Dict[str, Any]) -> List[Dict[str, Any]]:
        requested_sort = normalize_text(args.get("sort")) or "created"
        sort_col = self.SORTS.get(requested_sort, "b.created_at")
        direction = "ASC" if normalize_text(args.get("dir")).lower() == "asc" else "DESC"
        limit = clamp(parse_int(args.get("limit"), 50), 1, 200)
        offset = clamp(parse_int(args.get("offset"), 0), 0, 20000)
        sql = """
            SELECT b.id, b.invoice_no, b.status, b.amount_cents, b.created_at
            FROM bills b
            WHERE b.tenant_id = ?
        """
        params = [ctx.tenant_id]
        if args.get("status"):
            sql += " AND b.status = ?"
            params.append(normalize_text(args.get("status")))
        if args.get("account_id"):
            sql += " AND b.account_id = ?"
            params.append(parse_int(args.get("account_id")))
        sql += f" ORDER BY {sort_col} {direction} LIMIT {limit} OFFSET {offset}"
        audit(ctx, "billing.list", {"sort": sort_col, "limit": limit, "offset": offset})
        return [dict(row) for row in self.conn.execute(sql, params).fetchall()]
