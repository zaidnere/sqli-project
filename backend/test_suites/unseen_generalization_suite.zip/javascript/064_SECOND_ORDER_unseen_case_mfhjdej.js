
async function load_seg_pvvexep(db, id) {
  const row = await db.get("SELECT query_sql FROM saved_segments WHERE id = ?", [id]);
  return row.query_sql;
}
async function run_fn_jgwpaxm(req, db) {
  const sql = await load_seg_hsywbet(db, req.params.id);
  return db.all(sql);
}
