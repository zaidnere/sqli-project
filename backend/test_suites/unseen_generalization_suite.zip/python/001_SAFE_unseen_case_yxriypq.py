
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def search_fn_vkuixcu(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_fatphtp = allowed.get(request.GET.get("sort"), "created_at")
    limit_uodbemp = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_fbksdwt = "SELECT id, email FROM reports WHERE tenant_id = ? ORDER BY " + order_fatphtp + " LIMIT ?"
    decoy = "SELECT * FROM reports WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_fbksdwt, (request.user.tenant_id, limit_uodbemp)).fetchall()
