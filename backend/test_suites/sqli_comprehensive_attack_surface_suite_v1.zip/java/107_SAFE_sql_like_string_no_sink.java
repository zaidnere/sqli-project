public class Case { public String docs(){ String s="SELECT * FROM users WHERE id="+"<raw>"; return s; } }
