const crypto = require("crypto");

function normalizeText(value) {
  if (value === undefined || value === null) return "";
  return String(value).trim();
}
function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function clamp(value, low, high) {
  const n = toNumber(value, low);
  return Math.max(low, Math.min(high, n));
}
function audit(logger, ctx, action, details) {
  if (logger && logger.info) logger.info({ tenantId: ctx.tenantId, actorId: ctx.actorId, requestId: ctx.requestId, action, details });
}
function stableKey(prefix, value) {
  return `${prefix}_${crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 12)}`;
}
class RequestContext {
  constructor(tenantId, actorId, requestId) { this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId; }
}

class TenantQueryExecutor {
  constructor(db, logger) { this.db = db; this.logger = logger; }
  async loadDefinition(ctx, key) { return this.db.get("SELECT query_sql FROM tenant_queries WHERE tenant_id = ? AND query_key = ?", [ctx.tenantId, normalizeText(key)]); }
  async execute(ctx, key) {
    const def = await this.loadDefinition(ctx, key);
    if (!def) return [];
    const sql = def.query_sql;
    audit(this.logger, ctx, "tenant_query.execute", { key });
    return this.db.all(sql);
  }
}
module.exports = { TenantQueryExecutor };
