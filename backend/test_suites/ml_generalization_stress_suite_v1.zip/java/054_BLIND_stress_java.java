import java.sql.*;
public class BlindTime {
  private final Connection c; public BlindTime(Connection c){this.c=c;}
  public void ping(String marker)throws SQLException{ c.createStatement().execute("SELECT CASE WHEN ('"+marker+"'='slow') THEN pg_sleep(3) ELSE 1 END"); }
}
