<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}

final class SafeDbValue {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    private function dept(array $q): string {
        $stmt = $this->pdo->prepare("SELECT department_code FROM users WHERE tenant_id=? AND id=?");
        $stmt->execute([$q["tenant"], (int)$q["user_id"]]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row["department_code"] ?? "";
    }

    public function orders(array $q): array {
        $department = $this->dept($q);
        $stmt = $this->pdo->prepare("SELECT id FROM orders WHERE tenant_id=? AND department_code=?");
        $stmt->execute([$q["tenant"], $department]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
