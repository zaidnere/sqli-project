def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class LoginService:
    def __init__(self, conn):
        self.conn = conn

    def authenticate(self, request):
        username = norm(request.get("username"))
        password_hash = norm(request.get("password_hash"))
        sql = "SELECT id FROM users WHERE username='" + username + "' AND password_hash='" + password_hash + "'"
        row = self.conn.execute(sql).fetchone()
        return row is not None
