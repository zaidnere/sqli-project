function norm(v){ return v===undefined || v===null ? "" : String(v).trim(); }
function clamp(v,lo,hi){ const n=Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi,n)) : lo; }
function audit(){}

class SafeDbValueParam {
  constructor(db) { this.db = db; }
  async loadDept(ctx, userId) {
    const row = await this.db.get("SELECT department_code FROM users WHERE tenant_id=? AND id=?", [ctx.tenant, Number(userId)]);
    return row ? row.department_code : "";
  }
  async list(ctx, userId) {
    const dept = await this.loadDept(ctx, userId);
    return this.db.all("SELECT id FROM orders WHERE tenant_id=? AND department_code=?", [ctx.tenant, dept]);
  }
}
module.exports = SafeDbValueParam;
