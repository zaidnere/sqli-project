// Broken syntax sample; scanner should not crash.
function broken( {
const sql = "SELECT id FROM users WHERE id = ?"
