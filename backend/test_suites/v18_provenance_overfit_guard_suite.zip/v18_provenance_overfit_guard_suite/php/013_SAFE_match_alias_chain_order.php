<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class SafeMatchAliasChainOrder {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function list(array $q): array {
        $selected = match (norm($q["sort"] ?? "created")) {
            "email" => "email",
            "status" => "status",
            default => "created_at",
        };
        $finalOrder = $selected;
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? ORDER BY " . $finalOrder);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
