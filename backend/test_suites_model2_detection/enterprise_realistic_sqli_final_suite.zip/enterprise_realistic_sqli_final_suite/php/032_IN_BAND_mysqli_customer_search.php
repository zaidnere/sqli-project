<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class MysqliCustomerSearch {
    private mysqli $db; public function __construct(mysqli $db) { $this->db = $db; }
    public function search(array $ctx, array $query): array {
        $email = normalize_text($query["email"] ?? "");
        $sql = "SELECT id, email, full_name FROM customers WHERE tenant_id = '" . $ctx["tenant"] . "' AND email = '" . $email . "'";
        $result = $this->db->query($sql); return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }
}
