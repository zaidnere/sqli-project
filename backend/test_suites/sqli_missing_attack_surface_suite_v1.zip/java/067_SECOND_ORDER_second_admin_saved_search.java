import java.sql.*;
public class Repo { private final Connection c; public Repo(Connection c){this.c=c;}
  public ResultSet run(String id) throws SQLException {
    PreparedStatement ps = c.prepareStatement("SELECT condition_sql FROM stored_items WHERE id=?");
    ps.setString(1, id); ResultSet rs = ps.executeQuery(); rs.next();
    return c.createStatement().executeQuery("SELECT id,email FROM users WHERE " + rs.getString("condition_sql"));
  }}
