import java.sql.*;
class Case058 {
  ResultSet list(Connection c, int profileId) throws Exception {
    PreparedStatement p = c.prepareStatement("SELECT sort_expr FROM profiles WHERE id=?");
    p.setInt(1, profileId);
    ResultSet rs = p.executeQuery(); rs.next();
    String sort = rs.getString(1);
    return c.createStatement().executeQuery("SELECT id,name FROM customers ORDER BY " + sort);
  }
}
