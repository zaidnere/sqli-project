function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class SavedSegmentRunner {
  constructor(db, savedSegments) { this.db = db; this.savedSegments = savedSegments; }
  async run(req) {
    const savedSegment = await this.savedSegments.loadForUser(req.user.id, req.query.segmentId);
    const whereClause = savedSegment ? savedSegment.whereClause : "1=1";
    const sql = "SELECT id,email FROM users WHERE tenant_id=? AND " + whereClause;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = SavedSegmentRunner;
