def is_session_active(conn, sid):
    sql = "SELECT 1 FROM sessions WHERE sid='" + sid + "' AND expires_at > CURRENT_TIMESTAMP"
    return conn.execute(sql).fetchone() is not None
