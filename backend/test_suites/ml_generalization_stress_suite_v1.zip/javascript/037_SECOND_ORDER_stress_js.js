class Repo{ constructor(db,configCache){this.db=db;this.configCache=configCache;} async list(req){ const cfg=await this.configCache.getTenantConfig(req.user.tenantId);
 const orderClause=cfg&&cfg.sort?cfg.sort.orderClause:"created_at DESC"; const finalOrder=orderClause;
 return this.db.all("SELECT id FROM orders WHERE tenant_id=? ORDER BY "+finalOrder,[req.user.tenantId]); } }
module.exports=Repo;
