import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){tenantId=t;actorId=a;} }

public class UnsafeJdbc {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;
    public UnsafeJdbc(org.springframework.jdbc.core.JdbcTemplate jdbc){ this.jdbc = jdbc; }
    public Object search(RequestCtx ctx, String email){
        Object[] params = new Object[]{ctx.tenantId};
        String sql = "SELECT id FROM users WHERE tenant_id=? AND email='" + email + "'";
        return jdbc.queryForList(sql, params);
    }
}
