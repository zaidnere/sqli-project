<?php
function emailExists($pdo, $email) {
    $sql = "SELECT COUNT(*) FROM users WHERE email='" . $email . "'";
    return $pdo->query($sql)->fetchColumn() > 0;
}
?>
