function clampLimit(rawLimit) {
  const parsed = Number(rawLimit || 25);
  if (!Number.isFinite(parsed)) return 25;
  return Math.min(Math.max(parsed, 1), 100);
}

async function listOrdersSafeLimit(req, db) {
  const limit = clampLimit(req.query.limit);
  const offset = Math.max(Number(req.query.offset || 0), 0);

  return db.all(
    "SELECT id, email FROM users WHERE tenant_id = ? LIMIT ? OFFSET ?",
    [req.user.tenantId, limit, offset]
  );
}

module.exports = { listOrdersSafeLimit };
