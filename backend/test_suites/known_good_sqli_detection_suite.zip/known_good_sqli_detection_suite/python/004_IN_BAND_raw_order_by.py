def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class UnsafeOrder:
    def __init__(self, conn):
        self.conn = conn

    def list_users(self, request):
        order = norm(request.get("order"))
        sql = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + order
        return self.conn.execute(sql, [request["tenant"]]).fetchall()
