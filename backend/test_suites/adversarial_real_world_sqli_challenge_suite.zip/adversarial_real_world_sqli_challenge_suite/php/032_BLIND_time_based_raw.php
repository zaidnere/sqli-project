<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class Probe {
    private PDO $pdo;
    public function __construct(PDO $pdo){ $this->pdo = $pdo; }
    public function run(array $q): bool {
        $email = norm($q["email"] ?? "");
        $this->pdo->query("SELECT CASE WHEN email='" . $email . "' THEN SLEEP(5) ELSE 0 END FROM users");
        return true;
    }
}
