package com.enterprise.security.sqli.finalsuite;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

class RequestContext {
    final String tenantId;
    final String actorId;
    final String requestId;
    RequestContext(String tenantId, String actorId, String requestId) {
        this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId;
    }
}
class AuditLogger {
    void info(RequestContext ctx, String action, Map<String, Object> details) {
        System.out.println(Instant.now() + " tenant=" + ctx.tenantId + " action=" + action + " details=" + details);
    }
}
class InputUtil {
    static String clean(String value) { return value == null ? "" : value.trim(); }
    static int clampInt(String value, int low, int high, int fallback) {
        try { return Math.max(low, Math.min(high, Integer.parseInt(value))); }
        catch (Exception ex) { return fallback; }
    }
}

public class AuditExportService {
    private final Connection connection;
    public AuditExportService(Connection connection) { this.connection = connection; }
    String loadCondition(RequestContext ctx, long id) throws Exception {
        PreparedStatement ps = connection.prepareStatement("SELECT where_fragment FROM audit_exports WHERE tenant_id = ? AND id = ?");
        ps.setString(1, ctx.tenantId); ps.setLong(2, id); ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("where_fragment") : "1=1";
    }
    public ResultSet run(RequestContext ctx, long id) throws Exception {
        String fragment = loadCondition(ctx, id);
        String sql = "SELECT id, actor_id, action FROM audit_events WHERE tenant_id = '" + ctx.tenantId + "' AND " + fragment;
        return connection.createStatement().executeQuery(sql);
    }
}
