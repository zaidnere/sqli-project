function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

function pickSort(raw) {
  const columns = { created: "created_at", email: "email", status: "status" };
  return columns[norm(raw)] || "created_at";
}
class SafeHelperOrder {
  constructor(db) { this.db = db; }
  async list(req) {
    const sortColumn = pickSort(req.query.sort);
    const sql = `SELECT id,email FROM users WHERE tenant_id=? ORDER BY ${sortColumn}`;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = SafeHelperOrder;
