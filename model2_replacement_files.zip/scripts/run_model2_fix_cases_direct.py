# MODEL2_FIX_CASES_DIRECT_V2_MARKER
"""
Direct runner for Model 2 Fix Recommendation cases.

Place this file at:
  backend/scripts/run_model2_fix_cases_direct.py

Run from backend:
  set PYTHONPATH=.
  python scripts/run_model2_fix_cases_direct.py --cases test_suites/model2_fix_cases.json

The script overwrites:
  outputs/model2_fix_cases_results.csv
  outputs/model2_fix_cases_summary.json
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


FIX_NAMES = {
    "A": "Parameterized Query",
    "B": "Whitelist Validation",
    "C": "ORM / Query Builder Migration",
    "D": "Second-Order Mitigation",
}


def _safe_get(obj: Any, *names: str, default: Any = None) -> Any:
    """Read a value from either dict-like objects or normal objects."""
    if obj is None:
        return default
    for name in names:
        if isinstance(obj, dict) and name in obj:
            return obj[name]
        if hasattr(obj, name):
            return getattr(obj, name)
    return default


def _infer_final_fix_type(fixed_code: str, description: str = "") -> Optional[str]:
    """Infer final rendered fix type when the FixResult object does not expose it."""
    text = f"{description}\n{fixed_code}".lower()

    # Important: check whitelist before parameterization because whitelist examples
    # may also include safe SQL strings.
    if "allowed_columns" in text or "allowed_tables" in text or "whitelist" in text:
        return "B"
    if "second-order" in text or "second order" in text or "stored" in text or "persisted" in text:
        return "D"
    if "orm" in text or "query builder" in text or "sqlalchemy" in text or ".filter(" in text:
        return "C"
    if "parameterized" in text or "cursor.execute(query, (" in text or "?" in fixed_code or "%s" in fixed_code:
        return "A"
    return None


def _contains_all(text: str, needles: List[str]) -> Tuple[bool, List[str]]:
    missing = [needle for needle in needles if needle not in text]
    return len(missing) == 0, missing


def _load_cases(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict) and "cases" in data:
        data = data["cases"]
    if not isinstance(data, list):
        raise ValueError("Cases file must be a JSON list or an object with a 'cases' list.")
    return data


def _run_one_case(case: Dict[str, Any], vocabulary: Any) -> Dict[str, Any]:
    from app.preprocessing.code_cleaner import clean_code
    from app.preprocessing.tokenizer import tokenize_code
    from app.preprocessing.normalizer import normalize_tokens
    from app.vectorization.vectorizer import vectorize_tokens
    from app.model.fix_model_inference import run_fix_inference
    from app.fix_engine.fix_generator import generate_fix

    case_id = case.get("id", "unnamed_case")
    language = case.get("language", "python")
    attack_type = case.get("attack_type", case.get("attackType", "IN_BAND"))
    code = case.get("code", "")

    expected_model = case.get("expected_model_fix_type", case.get("expectedModelFixType"))
    expected_final = case.get("expected_final_fix_type", case.get("expectedFinalFixType"))
    must_contain = case.get("must_contain", case.get("final_must_contain", [])) or []
    info_only = bool(case.get("info_only", False))

    result: Dict[str, Any] = {
        "id": case_id,
        "language": language,
        "attackType": attack_type,
        "expectedModelFixType": expected_model or "",
        "expectedFinalFixType": expected_final or "",
        "infoOnly": info_only,
        "crashed": False,
        "error": "",
        "modelFixType": "",
        "modelFixStrategy": "",
        "modelConfidence": "",
        "finalFixType": "",
        "finalFixStrategy": "",
        "modelCheckPassed": "",
        "finalCheckPassed": "",
        "contentCheckPassed": "",
        "missingContent": "",
        "overallPassed": "",
        "fixedCode": "",
    }

    try:
        cleaned = clean_code(code)
        tokens = tokenize_code(cleaned)
        normalized = normalize_tokens(tokens)
        vec = vectorize_tokens(normalized, vocabulary)

        prediction = run_fix_inference(
            vec["tokenIds"],
            language=language,
            attack_type=attack_type,
            normalized_tokens=normalized,
            raw_code=code,
        )

        model_fix_type = _safe_get(prediction, "fixType", "fix_type", default="")
        model_fix_strategy = _safe_get(prediction, "fixStrategy", "fix_strategy", default="")
        confidence = _safe_get(prediction, "confidence", default="")

        fix = generate_fix(
            code,
            language,
            normalized,
            preferred_fix_type=model_fix_type,
            model_prediction=prediction,
        )

        fixed_code = _safe_get(fix, "fixed_code", "fixedCode", default="") or ""
        final_strategy = _safe_get(fix, "fix_strategy", "fixStrategy", "strategy", default="") or ""
        final_fix_type = _safe_get(fix, "fix_type", "fixType", default="")
        if not final_fix_type:
            final_fix_type = _infer_final_fix_type(fixed_code, final_strategy) or ""

        model_check_passed = True if not expected_model else (model_fix_type == expected_model)
        final_check_passed = True if not expected_final else (final_fix_type == expected_final)
        content_check_passed, missing = _contains_all(fixed_code, must_contain)
        overall = (model_check_passed and final_check_passed and content_check_passed) if not info_only else True

        result.update(
            {
                "modelFixType": model_fix_type,
                "modelFixStrategy": model_fix_strategy,
                "modelConfidence": confidence,
                "finalFixType": final_fix_type,
                "finalFixStrategy": final_strategy,
                "modelCheckPassed": model_check_passed if expected_model else "",
                "finalCheckPassed": final_check_passed if expected_final else "",
                "contentCheckPassed": content_check_passed if must_contain else "",
                "missingContent": " | ".join(missing),
                "overallPassed": overall,
                "fixedCode": fixed_code,
            }
        )
        return result

    except Exception as exc:  # keep runner alive and report case-level failures
        result.update(
            {
                "crashed": True,
                "error": f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}",
                "overallPassed": False,
            }
        )
        return result


def _summarize(rows: List[Dict[str, Any]], csv_path: Path, json_path: Path) -> Dict[str, Any]:
    total = len(rows)
    info_only = sum(1 for r in rows if r.get("infoOnly"))
    checked = total - info_only
    crashed = sum(1 for r in rows if r.get("crashed"))

    model_checked = sum(1 for r in rows if r.get("expectedModelFixType"))
    model_passed = sum(1 for r in rows if r.get("expectedModelFixType") and r.get("modelCheckPassed") is True)
    final_checked = sum(1 for r in rows if r.get("expectedFinalFixType"))
    final_passed = sum(1 for r in rows if r.get("expectedFinalFixType") and r.get("finalCheckPassed") is True)
    content_checked = sum(1 for r in rows if r.get("contentCheckPassed") != "")
    content_passed = sum(1 for r in rows if r.get("contentCheckPassed") is True)

    passed_checked = sum(1 for r in rows if not r.get("infoOnly") and r.get("overallPassed") is True)
    failed_checked = checked - passed_checked

    def counts(field: str) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for row in rows:
            key = row.get(field) or "UNKNOWN"
            out[key] = out.get(key, 0) + 1
        return out

    return {
        "suite": "model2_fix_cases_direct_v2",
        "totalCases": total,
        "checkedCases": checked,
        "uncheckedInfoOnlyCases": info_only,
        "passedChecked": passed_checked,
        "failedChecked": failed_checked,
        "crashedCases": crashed,
        "modelExpectedChecked": model_checked,
        "modelExpectedPassed": model_passed,
        "modelExpectedFailed": model_checked - model_passed,
        "finalExpectedChecked": final_checked,
        "finalExpectedPassed": final_passed,
        "finalExpectedFailed": final_checked - final_passed,
        "contentChecked": content_checked,
        "contentPassed": content_passed,
        "contentFailed": content_checked - content_passed,
        "modelFixTypeCounts": counts("modelFixType"),
        "finalFixTypeCounts": counts("finalFixType"),
        "csv": str(csv_path),
        "json": str(json_path),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Run direct Model 2 fix recommendation cases.")
    parser.add_argument("--cases", required=True, help="Path to JSON cases file.")
    parser.add_argument("--csv", default="outputs/model2_fix_cases_results.csv", help="Output CSV path.")
    parser.add_argument("--json", default="outputs/model2_fix_cases_summary.json", help="Output summary JSON path.")
    args = parser.parse_args()

    from app.vectorization.vocabulary import build_fixed_vocabulary

    cases_path = Path(args.cases)
    csv_path = Path(args.csv)
    json_path = Path(args.json)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.parent.mkdir(parents=True, exist_ok=True)

    cases = _load_cases(cases_path)
    vocabulary = build_fixed_vocabulary()
    rows = [_run_one_case(case, vocabulary) for case in cases]

    fieldnames = [
        "id",
        "language",
        "attackType",
        "expectedModelFixType",
        "expectedFinalFixType",
        "infoOnly",
        "crashed",
        "error",
        "modelFixType",
        "modelFixStrategy",
        "modelConfidence",
        "finalFixType",
        "finalFixStrategy",
        "modelCheckPassed",
        "finalCheckPassed",
        "contentCheckPassed",
        "missingContent",
        "overallPassed",
        "fixedCode",
    ]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    summary = _summarize(rows, csv_path, json_path)
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("Model 2 Fix Cases Direct V2")
    print("---------------------------")
    print(f"Total cases:              {summary['totalCases']}")
    print(f"Checked cases:            {summary['checkedCases']}")
    print(f"Passed checked:           {summary['passedChecked']}")
    print(f"Failed checked:           {summary['failedChecked']}")
    print(f"Crashed cases:            {summary['crashedCases']}")
    print(f"Model expected checked:   {summary['modelExpectedChecked']}")
    print(f"Model expected passed:    {summary['modelExpectedPassed']}")
    print(f"Model expected failed:    {summary['modelExpectedFailed']}")
    print(f"Final expected checked:   {summary['finalExpectedChecked']}")
    print(f"Final expected passed:    {summary['finalExpectedPassed']}")
    print(f"Final expected failed:    {summary['finalExpectedFailed']}")
    print(f"Content checked:          {summary['contentChecked']}")
    print(f"Content passed:           {summary['contentPassed']}")
    print(f"Content failed:           {summary['contentFailed']}")
    print(f"CSV:                      {summary['csv']}")
    print(f"JSON:                     {summary['json']}")
    print(f"Model fix counts:         {summary['modelFixTypeCounts']}")
    print(f"Final fix counts:         {summary['finalFixTypeCounts']}")

    return 0 if summary["failedChecked"] == 0 and summary["crashedCases"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
