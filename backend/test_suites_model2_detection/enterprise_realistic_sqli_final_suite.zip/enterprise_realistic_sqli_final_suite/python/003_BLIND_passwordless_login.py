import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Iterable

logger = logging.getLogger(__name__)

class RequestContext:
    def __init__(self, tenant_id: str, actor_id: str, request_id: str):
        self.tenant_id = tenant_id
        self.actor_id = actor_id
        self.request_id = request_id
        self.now = datetime.utcnow()

def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()

def parse_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default

def clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))

def audit(ctx: RequestContext, action: str, details: Dict[str, Any]) -> None:
    logger.info("tenant=%s actor=%s request=%s action=%s details=%s", ctx.tenant_id, ctx.actor_id, ctx.request_id, action, details)

class DomainCache:
    def __init__(self):
        self._values = {}
    def get(self, key: str) -> Optional[str]:
        return self._values.get(key)
    def set(self, key: str, value: str) -> None:
        self._values[key] = value

class BaseRepository:
    def __init__(self, conn):
        self.conn = conn
    def heartbeat(self) -> bool:
        return True
    def tenant_clause(self) -> str:
        return "tenant_id = ?"

class PasswordlessLoginGateway(BaseRepository):
    def consume(self, ctx: RequestContext, token: str) -> bool:
        t = normalize_text(token)
        sql = "SELECT user_id FROM login_links WHERE tenant_id = '" + ctx.tenant_id + "' AND token = '" + t + "' AND used_at IS NULL"
        row = self.conn.execute(sql).fetchone()
        if row:
            self.conn.execute("UPDATE login_links SET used_at = CURRENT_TIMESTAMP WHERE user_id = ?", [row["user_id"]])
            audit(ctx, "login.magic.success", {"user": row["user_id"]})
            return True
        audit(ctx, "login.magic.fail", {})
        return False
