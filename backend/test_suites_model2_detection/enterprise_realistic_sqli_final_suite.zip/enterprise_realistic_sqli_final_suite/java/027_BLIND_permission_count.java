package com.enterprise.security.sqli.finalsuite;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

class RequestContext {
    final String tenantId;
    final String actorId;
    final String requestId;
    RequestContext(String tenantId, String actorId, String requestId) {
        this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId;
    }
}
class AuditLogger {
    void info(RequestContext ctx, String action, Map<String, Object> details) {
        System.out.println(Instant.now() + " tenant=" + ctx.tenantId + " action=" + action + " details=" + details);
    }
}
class InputUtil {
    static String clean(String value) { return value == null ? "" : value.trim(); }
    static int clampInt(String value, int low, int high, int fallback) {
        try { return Math.max(low, Math.min(high, Integer.parseInt(value))); }
        catch (Exception ex) { return fallback; }
    }
}

public class PermissionServiceRaw {
    private final Connection connection;
    public PermissionServiceRaw(Connection connection) { this.connection = connection; }
    public boolean canApprove(RequestContext ctx, String workflowKey) throws Exception {
        String sql = "SELECT COUNT(*) AS c FROM workflow_permissions WHERE tenant_id = '" + ctx.tenantId + "' AND actor_id = '" + ctx.actorId + "' AND workflow_key = '" + workflowKey + "' AND can_approve = 1";
        ResultSet rs = connection.createStatement().executeQuery(sql); if (!rs.next()) return false; return rs.getInt("c") > 0;
    }
}
