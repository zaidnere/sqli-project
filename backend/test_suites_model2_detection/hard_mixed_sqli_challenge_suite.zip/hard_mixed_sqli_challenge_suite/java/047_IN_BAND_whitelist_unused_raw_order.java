import java.sql.*; import java.util.*;
class Case047 {
  static final Set<String> ALLOWED = Set.of("name", "created_at");
  ResultSet list(Connection c, String rawSort) throws Exception {
    String safeSort = ALLOWED.contains(rawSort) ? rawSort : "created_at";
    String sql = "SELECT id,email FROM users ORDER BY " + rawSort;
    return c.createStatement().executeQuery(sql);
  }
}
