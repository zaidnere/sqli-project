class Jobs{ constructor(db){this.db=db;} async run(jobId){ const row=await this.db.get("SELECT sql_body FROM scheduled_queries WHERE id=?",[jobId]);
 return this.db.all(row.sql_body); } }
module.exports=Jobs;
