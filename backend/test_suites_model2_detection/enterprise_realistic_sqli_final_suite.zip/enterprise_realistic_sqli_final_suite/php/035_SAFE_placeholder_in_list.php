<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class SafeBulkLoader {
    private PDO $pdo; public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function load(array $ctx, array $ids): array {
        $cleanIds = array_values(array_filter(array_map("intval", $ids), fn($id) => $id > 0)); if (!$cleanIds) return [];
        $placeholders = implode(",", array_fill(0, count($cleanIds), "?"));
        $sql = "SELECT id, sku, name FROM products WHERE tenant_id = ? AND id IN ($placeholders)"; $params = array_merge([$ctx["tenant"]], $cleanIds);
        $stmt = $this->pdo->prepare($sql); $stmt->execute($params); return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
