
def load_dqswkpa(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_hhromzb(request, conn):
    frag_cpvmdkm = load_dqswkpa(conn, request.user.tenant_id)
    sql_zrfqhhv = "SELECT * FROM audit_log WHERE " + frag_cpvmdkm
    return conn.execute(sql_zrfqhhv).fetchall()
