function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class DirectSavedSegmentNameRaw {
  constructor(db) { this.db = db; }
  async search(req) {
    const savedSegment = norm(req.query.savedSegment);
    const sql = "SELECT id,email FROM users WHERE tenant_id=? AND " + savedSegment;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = DirectSavedSegmentNameRaw;
