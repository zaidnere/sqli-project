class Login{ constructor(db){this.db=db;} async login(req){ const e=String(req.body.email||""), p=String(req.body.password||"");
 const row=await this.db.get(`SELECT id FROM users WHERE email='${e}' AND password_hash='${p}'`); return !!row; } }
module.exports=Login;
