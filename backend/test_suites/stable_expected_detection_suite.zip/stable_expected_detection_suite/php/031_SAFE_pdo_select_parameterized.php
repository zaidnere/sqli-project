<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class AccountRepository {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function find(array $q): array {
        $stmt = $this->pdo->prepare("SELECT id, account_no FROM accounts WHERE tenant_id=? AND id=?");
        $stmt->execute([$q["tenant"], to_int($q["id"] ?? 0)]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
