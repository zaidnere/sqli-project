import java.sql.*; import java.util.*;
public class Case {
  private final Connection c; static final Set<String> A=Set.of("created_at","email");
  public Case(Connection c){this.c=c;}
  public ResultSet run(String sort)throws SQLException{
    String safe=A.contains(sort)?sort:"created_at";
    return c.createStatement().executeQuery("SELECT id,email FROM users ORDER BY "+sort);
  }
}
