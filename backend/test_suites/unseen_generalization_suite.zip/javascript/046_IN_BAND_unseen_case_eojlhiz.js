
async function find_fn_ewmioqd(req, db) {
  const email = req.query.email || "";
  const sql = `SELECT * FROM users WHERE email = '${email}'`;
  return db.all(sql);
}
