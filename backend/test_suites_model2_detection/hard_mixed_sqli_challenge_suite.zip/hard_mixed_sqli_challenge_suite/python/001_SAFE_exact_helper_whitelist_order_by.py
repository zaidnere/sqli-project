ALLOWED_SORTS = {"name": "name", "created": "created_at", "price": "price"}

def pick_sort(raw):
    # Decoy string: "ORDER BY " + raw should not be treated as executed SQL.
    return ALLOWED_SORTS.get(raw, "created_at")

def list_products(conn, raw_sort, tenant_id):
    safe_sort = pick_sort(raw_sort)
    sql = "SELECT id, name, price FROM products WHERE tenant_id = ? ORDER BY " + safe_sort
    return conn.execute(sql, (tenant_id,)).fetchall()
