import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){ tenantId=t; actorId=a; } }

public class SafeNamedParameterJdbcTemplate {
    private final org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate jdbc;
    public SafeNamedParameterJdbcTemplate(org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }
    public Object search(RequestCtx ctx, String email, String rawWhere) {
        String sql = "SELECT id,email FROM users WHERE tenant_id=:tenant AND email=:email ORDER BY created_at DESC";
        Map<String,Object> params = new HashMap<>();
        params.put("tenant", ctx.tenantId);
        params.put("email", email);
        return jdbc.queryForList(sql, params);
    }
}
