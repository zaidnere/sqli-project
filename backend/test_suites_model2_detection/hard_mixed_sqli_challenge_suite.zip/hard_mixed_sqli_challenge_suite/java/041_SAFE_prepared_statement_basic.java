import java.sql.*;
class Case041 {
  ResultSet find(Connection c, String email) throws Exception {
    String sql = "SELECT id,email FROM users WHERE email = ?";
    PreparedStatement ps = c.prepareStatement(sql);
    ps.setString(1, email);
    return ps.executeQuery();
  }
}
