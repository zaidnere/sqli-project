
# decoy: SELECT * FROM users WHERE id = raw_input
def search_fn_ibyrlmm(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_ewoktae = allowed.get(request.GET.get("sort"), "created_at")
    limit_velucdf = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_dhrbnch = "SELECT id, email FROM profiles WHERE tenant_id = ? ORDER BY " + order_ewoktae + " LIMIT ?"
    decoy = "SELECT * FROM profiles WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_dhrbnch, (request.user.tenant_id, limit_velucdf)).fetchall()
