
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def lookup_fn_qncluuh(request, conn):
    email_fjkgzjk = request.GET.get("email", "")
    sql_mbdlxsj = "SELECT * FROM users WHERE email = '" + email_fjkgzjk + "'"
    return conn.execute(sql_mbdlxsj).fetchall()
