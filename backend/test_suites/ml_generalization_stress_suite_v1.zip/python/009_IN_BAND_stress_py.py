class Repo:
    def __init__(self, db): self.db = db
    def lookup(self, req):
        ids = ",".join(req.args.getlist("id"))
        return self.db.execute("SELECT id FROM inv WHERE id IN (" + ids + ")").fetchall()
