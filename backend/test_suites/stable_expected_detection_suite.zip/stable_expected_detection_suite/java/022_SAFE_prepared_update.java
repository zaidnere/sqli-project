import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class TicketRepository {
    private final Connection c;
    public TicketRepository(Connection c) { this.c = c; }

    public int updateStatus(AppCtx ctx, long id, String status) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "UPDATE tickets SET status=? WHERE tenant_id=? AND id=?"
        );
        ps.setString(1, status);
        ps.setString(2, ctx.tenantId);
        ps.setLong(3, id);
        return ps.executeUpdate();
    }
}
