import java.util.*;
public class SafeNamedParams {
  private final NamedJdbc jdbc; public SafeNamedParams(NamedJdbc jdbc){this.jdbc=jdbc;}
  public Object find(String tenant,String email){ Map<String,Object> p=new HashMap<>(); p.put("tenant",tenant); p.put("email",email); return jdbc.query("SELECT id FROM users WHERE tenant_id=:tenant AND email=:email",p); }
  interface NamedJdbc{ Object query(String sql, Map<String,Object> params); }
}
