<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class LoginNumRows {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }
    public function login(array $q): bool {
        $email = norm($q["email"] ?? "");
        $password = norm($q["password"] ?? "");
        $r = $this->db->query("SELECT id FROM users WHERE email='" . $email . "' AND password_hash='" . $password . "'");
        return $r && $r->num_rows > 0;
    }
}
