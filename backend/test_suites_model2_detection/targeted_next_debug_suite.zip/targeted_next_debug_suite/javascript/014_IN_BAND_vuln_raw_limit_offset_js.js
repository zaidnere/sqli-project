async function listArticles(db, size, offset) {
  const sql = `SELECT id, title FROM articles ORDER BY created_at DESC LIMIT ${size} OFFSET ${offset}`;
  return db.all(sql);
}
module.exports = { listArticles };
