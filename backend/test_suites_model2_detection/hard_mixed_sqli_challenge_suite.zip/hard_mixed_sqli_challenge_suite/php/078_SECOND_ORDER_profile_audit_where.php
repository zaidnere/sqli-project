<?php
function auditProfile($pdo, $profileId) {
    $stmt = $pdo->prepare("SELECT audit_predicate FROM profiles WHERE id=?");
    $stmt->execute([$profileId]);
    $predicate = $stmt->fetchColumn();
    $sql = "SELECT * FROM audit_log WHERE " . $predicate;
    return $pdo->query($sql)->fetchAll();
}
?>
