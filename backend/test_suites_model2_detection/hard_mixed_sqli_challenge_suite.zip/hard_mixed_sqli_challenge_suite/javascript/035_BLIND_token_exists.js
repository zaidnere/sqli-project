async function tokenValid(db, token) {
  const sql = "SELECT id FROM reset_tokens WHERE used=0 AND token='" + token + "'";
  return !!(await db.get(sql));
}
