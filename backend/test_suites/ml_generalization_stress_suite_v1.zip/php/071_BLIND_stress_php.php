<?php
final class Perm { public function __construct(private mysqli $db) {} public function canExport(array $q): bool { $report=trim((string)($q["report"]??"")); $r=$this->db->query("SELECT COUNT(*) AS c FROM permissions WHERE report_key='".$report."'"); $row=$r?$r->fetch_assoc():null; return $row && (int)$row["c"]>0; } }
