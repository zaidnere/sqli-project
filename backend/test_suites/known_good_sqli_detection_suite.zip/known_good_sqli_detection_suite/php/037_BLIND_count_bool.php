<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}

final class PermissionRaw {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }

    public function canExport(array $q): bool {
        $report = norm($q["report"] ?? "");
        $r = $this->db->query("SELECT COUNT(*) AS c FROM permissions WHERE report_key='" . $report . "'");
        $row = $r ? $r->fetch_assoc() : null;
        return $row && (int)$row["c"] > 0;
    }
}
