class BlindBooleanRepository:
    def __init__(self, db): self.db = db
    def check(self, req):
        key = req.args.get("key", req.form.get("email", ""))
        row = self.db.execute("SELECT id FROM security_checks WHERE lookup_key='" + key + "'").fetchone()
        return row is not None
