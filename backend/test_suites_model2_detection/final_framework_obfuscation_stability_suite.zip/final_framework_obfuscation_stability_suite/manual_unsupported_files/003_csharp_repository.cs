using System.Data.SqlClient;
public class Repo {
  public object Find(SqlConnection c, string email) {
    var cmd = new SqlCommand("SELECT * FROM Users WHERE Email='" + email + "'", c);
    return cmd.ExecuteReader();
  }
}
