import java.sql.*;
import java.util.*;

class Ctx {
    String tenantId;
    String actorId;
    Ctx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class SafeOrder {
    private final Connection c;
    private static final Set<String> SORTS = new HashSet<>(Arrays.asList("created_at", "email"));

    public SafeOrder(Connection c) { this.c = c; }

    public ResultSet list(Ctx ctx, String rawSort) throws Exception {
        String sort = SORTS.contains(rawSort) ? rawSort : "created_at";
        PreparedStatement ps = c.prepareStatement(
            "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + sort
        );
        ps.setString(1, ctx.tenantId);
        return ps.executeQuery();
    }
}
