function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class LoginService {
  constructor(db) { this.db = db; }

  async login(req) {
    const username = norm(req.body.username);
    const passwordHash = norm(req.body.passwordHash);
    const sql = "SELECT id FROM users WHERE username='" + username + "' AND password_hash='" + passwordHash + "'";
    const row = await this.db.get(sql);
    return !!row;
  }
}
module.exports = LoginService;
