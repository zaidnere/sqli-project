
# noise comment with SQL_CONCAT looking words but no sink
def lookup_fn_drsbibj(request, conn):
    email_tagpint = request.GET.get("email", "")
    sql_fstehry = "SELECT * FROM users WHERE email = '" + email_tagpint + "'"
    return conn.execute(sql_fstehry).fetchall()
