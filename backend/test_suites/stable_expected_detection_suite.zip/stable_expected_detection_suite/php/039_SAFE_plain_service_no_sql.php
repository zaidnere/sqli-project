<?php
declare(strict_types=1);

final class HealthService {
    public function status(): array {
        return ["ok" => true, "service" => "api"];
    }
}
