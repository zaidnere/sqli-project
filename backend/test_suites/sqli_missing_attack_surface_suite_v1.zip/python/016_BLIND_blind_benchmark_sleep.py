class Check:
    def __init__(self, db): self.db = db
    def run(self, req):
        marker = req.args.get("marker","")
        self.db.execute("SELECT IF('" + marker + "'='x', BENCHMARK(2000000,MD5('a')), 1)")
        return True
