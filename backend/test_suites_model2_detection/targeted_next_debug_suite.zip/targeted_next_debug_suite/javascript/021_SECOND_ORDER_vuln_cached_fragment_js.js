async function runSavedReport(db, id) {
  const row = await db.get("SELECT where_fragment FROM saved_reports WHERE id = ?", [id]);
  if (!row) return [];
  const sql = "SELECT id, total FROM invoices WHERE " + row.where_fragment;
  return db.all(sql);
}
module.exports = { runSavedReport };
