
def active_fn_blibhjm(request, conn):
    token_kmoiuus = request.GET.get("token", "")
    sql_kvrmuyh = "SELECT id FROM sessions WHERE token = '" + token_kmoiuus + "'"
    row = conn.execute(sql_kvrmuyh).fetchone()
    return row is not None
