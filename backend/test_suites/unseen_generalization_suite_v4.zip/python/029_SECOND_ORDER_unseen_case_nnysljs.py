
def load_fxvbliw(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_leynjof(request, conn):
    frag_ktntvap = load_fxvbliw(conn, request.user.tenant_id)
    sql_ecbxpvf = "SELECT * FROM audit_log WHERE " + frag_ktntvap
    return conn.execute(sql_ecbxpvf).fetchall()
