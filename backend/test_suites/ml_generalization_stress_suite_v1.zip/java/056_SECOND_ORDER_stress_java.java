import java.sql.*;
public class SOResultSet {
  private final Connection c; public SOResultSet(Connection c){this.c=c;}
  public String load(String id)throws SQLException{ PreparedStatement ps=c.prepareStatement("SELECT where_clause FROM saved_filters WHERE id=?"); ps.setString(1,id); ResultSet rs=ps.executeQuery(); return rs.next()?rs.getString("where_clause"):"1=1"; }
  public ResultSet run(String id)throws SQLException{ return c.createStatement().executeQuery("SELECT id FROM users WHERE "+load(id)); }
}
