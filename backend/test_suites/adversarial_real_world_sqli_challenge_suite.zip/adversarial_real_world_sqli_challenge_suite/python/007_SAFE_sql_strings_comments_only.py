# db.execute("SELECT * FROM users WHERE id=" + request.GET["id"])
def ok():
    sql = "SELECT id FROM users WHERE id=" + "not executed"
    return sql
