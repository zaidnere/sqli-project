function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class PermissionService {
  constructor(db) { this.db = db; }

  async canExport(req) {
    const report = norm(req.query.report);
    const sql = "SELECT COUNT(*) AS c FROM permissions WHERE actor_id='" + req.user.id + "' AND report_key='" + report + "'";
    const row = await this.db.get(sql);
    return row.c > 0;
  }
}
module.exports = PermissionService;
