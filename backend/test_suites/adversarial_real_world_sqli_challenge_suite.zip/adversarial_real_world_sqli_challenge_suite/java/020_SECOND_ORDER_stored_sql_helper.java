import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){tenantId=t;actorId=a;} }

public class StoredSql {
    private final Connection c;
    public StoredSql(Connection c){ this.c = c; }
    private String load(RequestCtx ctx, String key) throws Exception {
        PreparedStatement ps = c.prepareStatement("SELECT sql_body FROM stored_queries WHERE tenant_id=? AND k=?");
        ps.setString(1, ctx.tenantId); ps.setString(2, key);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("sql_body") : "";
    }
    public ResultSet run(RequestCtx ctx, String key) throws Exception {
        String sql = load(ctx, key);
        return c.createStatement().executeQuery(sql);
    }
}
