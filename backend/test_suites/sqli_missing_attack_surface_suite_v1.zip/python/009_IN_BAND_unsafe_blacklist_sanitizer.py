def sanitize(v): return v.replace("UNION", "").replace("SELECT", "")
class Repo:
    def __init__(self, db): self.db = db
    def search(self, req):
        q = sanitize(req.args.get("q",""))
        return self.db.execute("SELECT id,email FROM users WHERE email LIKE '%" + q + "%'").fetchall()
