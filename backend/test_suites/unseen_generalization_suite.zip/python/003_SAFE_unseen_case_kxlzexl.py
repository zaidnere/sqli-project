
# decoy: SELECT * FROM users WHERE id = raw_input
def search_fn_egeybpf(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_mmwolmn = allowed.get(request.GET.get("sort"), "created_at")
    limit_qrznour = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_mapyoeg = "SELECT id, email FROM profiles WHERE tenant_id = ? ORDER BY " + order_mmwolmn + " LIMIT ?"
    decoy = "SELECT * FROM profiles WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_mapyoeg, (request.user.tenant_id, limit_qrznour)).fetchall()
