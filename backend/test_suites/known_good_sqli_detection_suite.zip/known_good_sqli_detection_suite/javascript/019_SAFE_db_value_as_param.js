function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class SafeDbValue {
  constructor(db) { this.db = db; }

  async loadDepartment(ctx, userId) {
    const row = await this.db.get(
      "SELECT department_code FROM users WHERE tenant_id=? AND id=?",
      [ctx.tenantId, Number(userId)]
    );
    return row ? row.department_code : "";
  }

  async orders(ctx, userId) {
    const dept = await this.loadDepartment(ctx, userId);
    return this.db.all(
      "SELECT id FROM orders WHERE tenant_id=? AND department_code=?",
      [ctx.tenantId, dept]
    );
  }
}
module.exports = SafeDbValue;
