import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Iterable

logger = logging.getLogger(__name__)

class RequestContext:
    def __init__(self, tenant_id: str, actor_id: str, request_id: str):
        self.tenant_id = tenant_id
        self.actor_id = actor_id
        self.request_id = request_id
        self.now = datetime.utcnow()

def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()

def parse_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default

def clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))

def audit(ctx: RequestContext, action: str, details: Dict[str, Any]) -> None:
    logger.info("tenant=%s actor=%s request=%s action=%s details=%s", ctx.tenant_id, ctx.actor_id, ctx.request_id, action, details)

class DomainCache:
    def __init__(self):
        self._values = {}
    def get(self, key: str) -> Optional[str]:
        return self._values.get(key)
    def set(self, key: str, value: str) -> None:
        self._values[key] = value

class BaseRepository:
    def __init__(self, conn):
        self.conn = conn
    def heartbeat(self) -> bool:
        return True
    def tenant_clause(self) -> str:
        return "tenant_id = ?"

class DashboardWidgetData(BaseRepository):
    def load_widget(self, ctx: RequestContext, widget_id: int) -> Dict[str, Any]:
        row = self.conn.execute("SELECT id, where_fragment, default_limit FROM dashboard_widgets WHERE tenant_id = ? AND id = ?", [ctx.tenant_id, int(widget_id)]).fetchone()
        return dict(row) if row else {}
    def rows(self, ctx: RequestContext, widget_id: int) -> List[Dict[str, Any]]:
        widget = self.load_widget(ctx, widget_id)
        where_fragment = widget.get("where_fragment") or "1=1"
        limit = clamp(parse_int(widget.get("default_limit"), 100), 1, 500)
        sql = "SELECT id, label, value FROM widget_rows WHERE tenant_id = ? AND " + where_fragment + f" ORDER BY created_at DESC LIMIT {limit}"
        return [dict(row) for row in self.conn.execute(sql, [ctx.tenant_id]).fetchall()]
