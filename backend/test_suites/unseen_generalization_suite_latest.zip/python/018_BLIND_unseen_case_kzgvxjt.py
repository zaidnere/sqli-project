
def active_fn_adarckr(request, conn):
    token_wljmylm = request.GET.get("token", "")
    sql_duwlzqs = "SELECT id FROM sessions WHERE token = '" + token_wljmylm + "'"
    row = conn.execute(sql_duwlzqs).fetchone()
    return row is not None
