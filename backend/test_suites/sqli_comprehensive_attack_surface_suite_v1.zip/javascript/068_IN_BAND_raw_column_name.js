class Repo{constructor(db){this.db=db;} async values(req){return this.db.all("SELECT "+req.query.column+" FROM users");}} module.exports=Repo;
