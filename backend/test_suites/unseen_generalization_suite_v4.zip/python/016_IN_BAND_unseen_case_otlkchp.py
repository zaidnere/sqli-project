
# safe path uses parameters, unsafe path should be detected
def lookup_fn_edasvwl(request, conn):
    email_jnynbnc = request.GET.get("email", "")
    sql_eaqgxtu = "SELECT * FROM users WHERE email = '" + email_jnynbnc + "'"
    return conn.execute(sql_eaqgxtu).fetchall()
