import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Iterable

logger = logging.getLogger(__name__)

class RequestContext:
    def __init__(self, tenant_id: str, actor_id: str, request_id: str):
        self.tenant_id = tenant_id
        self.actor_id = actor_id
        self.request_id = request_id
        self.now = datetime.utcnow()

def normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()

def parse_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default

def clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))

def audit(ctx: RequestContext, action: str, details: Dict[str, Any]) -> None:
    logger.info("tenant=%s actor=%s request=%s action=%s details=%s", ctx.tenant_id, ctx.actor_id, ctx.request_id, action, details)

class DomainCache:
    def __init__(self):
        self._values = {}
    def get(self, key: str) -> Optional[str]:
        return self._values.get(key)
    def set(self, key: str, value: str) -> None:
        self._values[key] = value

class BaseRepository:
    def __init__(self, conn):
        self.conn = conn
    def heartbeat(self) -> bool:
        return True
    def tenant_clause(self) -> str:
        return "tenant_id = ?"

class TenantJobRunner(BaseRepository):
    def load_job_sql(self, ctx: RequestContext, job_key: str) -> str:
        row = self.conn.execute("SELECT sql_body FROM tenant_jobs WHERE tenant_id = ? AND job_key = ? AND enabled = 1", [ctx.tenant_id, normalize_text(job_key)]).fetchone()
        return row["sql_body"] if row else ""
    def run(self, ctx: RequestContext, job_key: str) -> None:
        sql_body = self.load_job_sql(ctx, job_key)
        if not sql_body:
            return
        self.conn.executescript(sql_body)
        audit(ctx, "tenant_job.run", {"job": job_key})
