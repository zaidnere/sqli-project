function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class UnsafeSequelizeTemplate {
  async run(sequelize, req) {
    const email = norm(req.query.email);
    const sql = `SELECT id,email FROM users WHERE email='${email}'`;
    return sequelize.query(sql);
  }
}
module.exports = UnsafeSequelizeTemplate;
