# SQL notes
```sql
SELECT * FROM users WHERE id = ' + input
```
