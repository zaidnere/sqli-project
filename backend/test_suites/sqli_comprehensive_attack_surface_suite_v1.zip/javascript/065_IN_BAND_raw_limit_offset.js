class Repo{constructor(db){this.db=db;} async page(req){return this.db.all("SELECT id FROM users LIMIT "+req.query.limit+" OFFSET "+req.query.offset);}} module.exports=Repo;
