
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def lookup_fn_ifwlepy(request, conn):
    email_vbrmkuj = request.GET.get("email", "")
    sql_hbxiiid = "SELECT * FROM users WHERE email = '" + email_vbrmkuj + "'"
    return conn.execute(sql_hbxiiid).fetchall()
