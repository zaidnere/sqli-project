
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def search_fn_zkreofh(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_eblhuzl = allowed.get(request.GET.get("sort"), "created_at")
    limit_akekikj = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_guhdhgp = "SELECT id, email FROM profiles WHERE tenant_id = ? ORDER BY " + order_eblhuzl + " LIMIT ?"
    decoy = "SELECT * FROM profiles WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_guhdhgp, (request.user.tenant_id, limit_akekikj)).fetchall()
