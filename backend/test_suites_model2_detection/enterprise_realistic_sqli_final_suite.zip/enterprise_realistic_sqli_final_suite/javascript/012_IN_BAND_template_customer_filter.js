const crypto = require("crypto");

function normalizeText(value) {
  if (value === undefined || value === null) return "";
  return String(value).trim();
}
function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function clamp(value, low, high) {
  const n = toNumber(value, low);
  return Math.max(low, Math.min(high, n));
}
function audit(logger, ctx, action, details) {
  if (logger && logger.info) logger.info({ tenantId: ctx.tenantId, actorId: ctx.actorId, requestId: ctx.requestId, action, details });
}
function stableKey(prefix, value) {
  return `${prefix}_${crypto.createHash("sha1").update(String(value)).digest("hex").slice(0, 12)}`;
}
class RequestContext {
  constructor(tenantId, actorId, requestId) { this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId; }
}

class CustomerFilterController {
  constructor(db, logger) { this.db = db; this.logger = logger; }
  async search(ctx, req) {
    const email = normalizeText(req.query.email);
    let sql = `SELECT id, email, full_name FROM customers WHERE tenant_id = ?`;
    const params = [ctx.tenantId];
    if (email) { sql += ` AND email = '${email}'`; }
    audit(this.logger, ctx, "customer.search", { hasEmail: !!email });
    return this.db.all(sql, params);
  }
}
module.exports = { CustomerFilterController };
