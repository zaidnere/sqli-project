import java.sql.*;

public class AuditServiceSafe {
    private final Connection conn;
    public AuditServiceSafe(Connection conn) { this.conn = conn; }

    public void archiveNote(int id) throws Exception {
        PreparedStatement ps = conn.prepareStatement("SELECT note_text FROM notes WHERE id = ?");
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (!rs.next()) return;
        String note = rs.getString(1);

        PreparedStatement out = conn.prepareStatement("INSERT INTO archived_notes(note_text) VALUES (?)");
        out.setString(1, note);
        out.executeUpdate();
    }
}
