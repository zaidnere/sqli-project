
def load_vtyhsyo(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_vpyxiav(request, conn):
    frag_hbeiqel = load_vtyhsyo(conn, request.user.tenant_id)
    sql_aainfxq = "SELECT * FROM audit_log WHERE " + frag_hbeiqel
    return conn.execute(sql_aainfxq).fetchall()
