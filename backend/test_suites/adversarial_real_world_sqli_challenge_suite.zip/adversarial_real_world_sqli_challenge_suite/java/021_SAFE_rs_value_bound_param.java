import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){tenantId=t;actorId=a;} }

public class SafeRsValueParam {
    private final Connection c;
    public SafeRsValueParam(Connection c){ this.c = c; }
    private String dept(RequestCtx ctx, long userId) throws Exception {
        PreparedStatement ps = c.prepareStatement("SELECT department_code FROM users WHERE tenant_id=? AND id=?");
        ps.setString(1, ctx.tenantId); ps.setLong(2, userId);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("department_code") : "";
    }
    public ResultSet orders(RequestCtx ctx, long userId) throws Exception {
        String d = dept(ctx, userId);
        PreparedStatement ps = c.prepareStatement("SELECT id FROM orders WHERE tenant_id=? AND department_code=?");
        ps.setString(1, ctx.tenantId); ps.setString(2, d);
        return ps.executeQuery();
    }
}
