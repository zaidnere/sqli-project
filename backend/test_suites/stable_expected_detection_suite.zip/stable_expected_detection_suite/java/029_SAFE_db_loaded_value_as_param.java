import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class SafeOrderRepository {
    private final Connection c;
    public SafeOrderRepository(Connection c) { this.c = c; }

    private String loadDepartment(AppCtx ctx, long userId) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "SELECT department_code FROM users WHERE tenant_id=? AND id=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setLong(2, userId);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("department_code") : "";
    }

    public ResultSet listOrders(AppCtx ctx, long userId) throws Exception {
        String dept = loadDepartment(ctx, userId);
        PreparedStatement ps = c.prepareStatement(
            "SELECT id FROM orders WHERE tenant_id=? AND department_code=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setString(2, dept);
        return ps.executeQuery();
    }
}
