class SecondOrder{ constructor(db,config){this.db=db;this.config=config;} async list(t){ const cfg=await this.config.loadTenant(t); const order=cfg.orderClause; return this.db.all("SELECT id,email FROM users WHERE tenant_id=? ORDER BY "+order,[t]); } }
module.exports=SecondOrder;
