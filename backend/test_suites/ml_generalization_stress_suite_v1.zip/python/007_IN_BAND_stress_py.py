def safe_order(raw):
    return {"created": "created_at", "email": "email"}.get(raw, "created_at")
class Repo:
    def __init__(self, db): self.db = db
    def list(self, req):
        safe = safe_order(req.args.get("sort"))
        raw = req.args.get("sort", "")
        return self.db.execute("SELECT id FROM users ORDER BY " + raw).fetchall()
