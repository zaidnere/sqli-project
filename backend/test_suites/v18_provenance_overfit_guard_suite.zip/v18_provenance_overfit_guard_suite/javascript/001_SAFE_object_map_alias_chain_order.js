function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class SafeObjectMapAliasChainOrder {
  constructor(db) { this.db = db; }

  async list(req) {
    const allowedColumns = { created: "created_at", email: "email", status: "status" };
    const selectedColumn = allowedColumns[norm(req.query.sort)] || "created_at";
    const finalOrderColumn = selectedColumn;
    const sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + finalOrderColumn;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = SafeObjectMapAliasChainOrder;
