
def active_fn_wyjqdov(request, conn):
    token_aqaerse = request.GET.get("token", "")
    sql_idshvws = "SELECT id FROM sessions WHERE token = '" + token_aqaerse + "'"
    row = conn.execute(sql_idshvws).fetchone()
    return row is not None
