<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class RawCustomerSearch {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }
    public function search(array $q): array {
        $email = norm($q["email"] ?? "");
        $r = $this->db->query("SELECT id,email FROM customers WHERE email LIKE '%" . $email . "%'");
        return $r ? $r->fetch_all(MYSQLI_ASSOC) : [];
    }
}
