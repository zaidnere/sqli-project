def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*args): pass

class AliasExec:
    def __init__(self, conn): self.conn = conn
    def run(self, args):
        call = self.conn.execute
        email = norm(args.get("email"))
        sql = "SELECT id FROM users WHERE email='" + email + "'"
        return call(sql).fetchall()
