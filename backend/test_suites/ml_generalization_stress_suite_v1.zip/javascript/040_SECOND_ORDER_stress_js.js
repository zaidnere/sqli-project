class Loader{ constructor(db){this.db=db;} async load(id){ const r=await this.db.get("SELECT where_clause FROM report_segments WHERE id=?",[id]); return {sql:{whereClause:r?r.where_clause:"1=1"}}; }
 async report(req){ const loaded=await this.load(req.query.segmentId); const w=loaded.sql.whereClause; return this.db.all("SELECT id FROM users WHERE "+w); } }
module.exports=Loader;
