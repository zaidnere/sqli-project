import java.sql.*;
public class UnsafeStatementConcat {
  private final Connection c; public UnsafeStatementConcat(Connection c){this.c=c;}
  public ResultSet search(String email)throws SQLException{ String sql="SELECT id FROM users WHERE email LIKE '%"+email+"%'"; return c.createStatement().executeQuery(sql); }
}
