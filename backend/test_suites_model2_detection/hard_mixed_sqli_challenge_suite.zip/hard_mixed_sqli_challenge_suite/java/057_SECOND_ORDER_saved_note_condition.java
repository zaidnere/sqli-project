import java.sql.*;
class Case057 {
  ResultSet audit(Connection c, int noteId) throws Exception {
    ResultSet rs = c.createStatement().executeQuery("SELECT condition_sql FROM notes WHERE id=" + noteId);
    rs.next();
    String condition = rs.getString("condition_sql");
    return c.createStatement().executeQuery("SELECT * FROM audit_log WHERE " + condition);
  }
}
