def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*a): pass

class SafeAllowlist:
    SORTS = {"created": "created_at", "email": "email"}
    def __init__(self, conn): self.conn = conn
    def list(self, request):
        stored_order = norm(request.get("order"))
        sort = self.SORTS.get(stored_order, "created_at")
        sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + sort
        return self.conn.execute(sql, [request["tenant"]]).fetchall()
