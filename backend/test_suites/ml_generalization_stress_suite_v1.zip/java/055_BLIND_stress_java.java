import java.sql.*;
public class BlindFeature {
  private final Connection c; public BlindFeature(Connection c){this.c=c;}
  public boolean enabled(String f)throws SQLException{ return c.createStatement().executeQuery("SELECT id FROM feature_flags WHERE feature_key='"+f+"'").next(); }
}
