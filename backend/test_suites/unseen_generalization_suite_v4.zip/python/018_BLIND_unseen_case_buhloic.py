
def active_fn_bqgozoj(request, conn):
    token_eqqtoqd = request.GET.get("token", "")
    sql_aschihb = "SELECT id FROM sessions WHERE token = '" + token_eqqtoqd + "'"
    row = conn.execute(sql_aschihb).fetchone()
    return row is not None
