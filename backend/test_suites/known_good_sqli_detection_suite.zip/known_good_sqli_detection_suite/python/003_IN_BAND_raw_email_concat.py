def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class UnsafeSearch:
    def __init__(self, conn):
        self.conn = conn

    def search(self, request):
        email = norm(request.get("email"))
        sql = "SELECT id, email FROM users WHERE email = '" + email + "'"
        return self.conn.execute(sql).fetchall()
