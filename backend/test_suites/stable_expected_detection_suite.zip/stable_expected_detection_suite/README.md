# Stable Expected Detection Suite

Generated: 2026-05-08T13:48:43.198583Z

Total cases: 40

Purpose:
This suite contains patterns the detector should be able to identify that are NOT focused on the current known weak areas.

Avoided known weak areas:
- no comments-only SQLi-looking false-positive traps
- no time-based BLIND cases
- no Java NamedParameterJdbcTemplate
- no JS/PHP allowlisted ORDER BY edge cases
- no PHP direct IN_BAND raw concat/implode cases currently known to be confused with SECOND_ORDER

Included stable categories:
- SAFE parameterized queries
- SAFE DB-loaded value used as a bound parameter
- SAFE plain no-SQL services
- IN_BAND direct raw SQLi mainly in Python/JavaScript/Java
- BLIND classic login/count/permission checks
- SECOND_ORDER real DB-loaded SQL fragments or stored SQL
