import java.sql.*;
class Case044 {
  ResultSet load(Connection c, int customerId) throws Exception {
    PreparedStatement p1 = c.prepareStatement("SELECT default_status FROM customer_defaults WHERE customer_id=?");
    p1.setInt(1, customerId);
    ResultSet rs = p1.executeQuery();
    String status = rs.next() ? rs.getString(1) : "active";
    PreparedStatement p2 = c.prepareStatement("SELECT id,total FROM orders WHERE status=? AND customer_id=?");
    p2.setString(1, status);
    p2.setInt(2, customerId);
    return p2.executeQuery();
  }
}
