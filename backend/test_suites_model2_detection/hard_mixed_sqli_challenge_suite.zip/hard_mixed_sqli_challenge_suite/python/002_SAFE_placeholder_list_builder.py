def get_orders(conn, tenant_id, order_ids):
    ids = [int(x) for x in order_ids if str(x).isdigit()]
    if not ids:
        return []
    marks = ",".join(["?"] * len(ids))
    sql = f"SELECT id,total FROM orders WHERE tenant_id=? AND id IN ({marks})"
    params = [tenant_id] + ids
    return conn.execute(sql, params).fetchall()
