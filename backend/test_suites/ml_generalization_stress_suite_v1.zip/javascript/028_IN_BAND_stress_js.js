class Repo{ constructor(db){this.db=db;} async export(req){ const table=String(req.query.table||"");
 return this.db.all("SELECT * FROM "+table+" WHERE tenant_id=?",[req.user.tenantId]); } }
module.exports=Repo;
