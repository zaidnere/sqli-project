async function loadDefaultStatusOrders(db, customerId) {
  const row = await db.get("SELECT default_status FROM customer_defaults WHERE customer_id = ?", [customerId]);
  const status = row ? row.default_status : "active";
  const sql = "SELECT id,total FROM orders WHERE status = ? AND customer_id = ?";
  return db.all(sql, [status, customerId]);
}
