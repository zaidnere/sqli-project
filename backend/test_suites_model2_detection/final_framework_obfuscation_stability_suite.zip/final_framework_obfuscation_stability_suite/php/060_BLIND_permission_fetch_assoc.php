<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? '' : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int { $n = filter_var($v, FILTER_VALIDATE_INT); if ($n === false) $n = $lo; return max($lo, min($hi, $n)); }

function helper_0($value): array { return ['idx' => 0, 'value' => $value]; }
function helper_1($value): array { return ['idx' => 1, 'value' => $value]; }
function helper_2($value): array { return ['idx' => 2, 'value' => $value]; }
function helper_3($value): array { return ['idx' => 3, 'value' => $value]; }
function helper_4($value): array { return ['idx' => 4, 'value' => $value]; }
function helper_5($value): array { return ['idx' => 5, 'value' => $value]; }
function helper_6($value): array { return ['idx' => 6, 'value' => $value]; }
function helper_7($value): array { return ['idx' => 7, 'value' => $value]; }
function helper_8($value): array { return ['idx' => 8, 'value' => $value]; }
function helper_9($value): array { return ['idx' => 9, 'value' => $value]; }
function helper_10($value): array { return ['idx' => 10, 'value' => $value]; }
function helper_11($value): array { return ['idx' => 11, 'value' => $value]; }
function helper_12($value): array { return ['idx' => 12, 'value' => $value]; }
function helper_13($value): array { return ['idx' => 13, 'value' => $value]; }
function helper_14($value): array { return ['idx' => 14, 'value' => $value]; }
function helper_15($value): array { return ['idx' => 15, 'value' => $value]; }
function helper_16($value): array { return ['idx' => 16, 'value' => $value]; }
function helper_17($value): array { return ['idx' => 17, 'value' => $value]; }
function helper_18($value): array { return ['idx' => 18, 'value' => $value]; }
function helper_19($value): array { return ['idx' => 19, 'value' => $value]; }
function helper_20($value): array { return ['idx' => 20, 'value' => $value]; }
function helper_21($value): array { return ['idx' => 21, 'value' => $value]; }
function helper_22($value): array { return ['idx' => 22, 'value' => $value]; }
function helper_23($value): array { return ['idx' => 23, 'value' => $value]; }
function helper_24($value): array { return ['idx' => 24, 'value' => $value]; }
function helper_25($value): array { return ['idx' => 25, 'value' => $value]; }
function helper_26($value): array { return ['idx' => 26, 'value' => $value]; }
function helper_27($value): array { return ['idx' => 27, 'value' => $value]; }
function helper_28($value): array { return ['idx' => 28, 'value' => $value]; }
function helper_29($value): array { return ['idx' => 29, 'value' => $value]; }
function helper_30($value): array { return ['idx' => 30, 'value' => $value]; }
function helper_31($value): array { return ['idx' => 31, 'value' => $value]; }
function helper_32($value): array { return ['idx' => 32, 'value' => $value]; }
function helper_33($value): array { return ['idx' => 33, 'value' => $value]; }
function helper_34($value): array { return ['idx' => 34, 'value' => $value]; }
function helper_35($value): array { return ['idx' => 35, 'value' => $value]; }
function helper_36($value): array { return ['idx' => 36, 'value' => $value]; }
function helper_37($value): array { return ['idx' => 37, 'value' => $value]; }
function helper_38($value): array { return ['idx' => 38, 'value' => $value]; }
function helper_39($value): array { return ['idx' => 39, 'value' => $value]; }
function helper_40($value): array { return ['idx' => 40, 'value' => $value]; }
function helper_41($value): array { return ['idx' => 41, 'value' => $value]; }
function helper_42($value): array { return ['idx' => 42, 'value' => $value]; }
function helper_43($value): array { return ['idx' => 43, 'value' => $value]; }
function helper_44($value): array { return ['idx' => 44, 'value' => $value]; }
function helper_45($value): array { return ['idx' => 45, 'value' => $value]; }
function helper_46($value): array { return ['idx' => 46, 'value' => $value]; }
function helper_47($value): array { return ['idx' => 47, 'value' => $value]; }
function helper_48($value): array { return ['idx' => 48, 'value' => $value]; }
function helper_49($value): array { return ['idx' => 49, 'value' => $value]; }
final class PermissionFetchBlind {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }
    public function canDelete(string $resource): bool {
        $r = $this->db->query("SELECT id FROM permissions WHERE resource_key = '" . $resource . "' AND can_delete = 1");
        return $r && $r->fetch_assoc() !== null;
    }
}
