Put this ZIP file at backend/test_suites/model2_fix_cases.zip. Do not extract it. The runner will read all JSON suites inside the ZIP.
