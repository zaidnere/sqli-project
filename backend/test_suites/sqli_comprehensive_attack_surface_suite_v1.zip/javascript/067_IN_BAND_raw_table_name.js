class Repo{constructor(db){this.db=db;} async export(req){return this.db.all("SELECT * FROM "+req.query.table);}} module.exports=Repo;
