class Repo { constructor(db){this.db=db;} find(req){ const id=Number.parseInt(req.query.id||"0",10); return this.db.all("SELECT id,email FROM users WHERE id=?",[id]); } }
module.exports = Repo;
