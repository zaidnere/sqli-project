
// decoy: SELECT * FROM users WHERE id = raw_input
async function list_fn_hkozjuo(req, db) {
  const allowed = new Set(["created_at", "email", "name"]);
  const sort_krvvzbq = allowed.has(req.query.sort) ? req.query.sort : "created_at";
  const limit = Math.min(Math.max(Number(req.query.limit || 25), 1), 100);
  const sql = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + sort_krvvzbq + " LIMIT ?";
  const decoy = `SELECT * FROM users WHERE email = '${req.query.email}'`;
  const params_nmbeiux = [req.user.tenantId, limit];
  return db.all(sql, params_nmbeiux);
}
