
def load_fllpclo(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_qottklw(request, conn):
    frag_eiienvd = load_fllpclo(conn, request.user.tenant_id)
    sql_yscgidc = "SELECT * FROM audit_log WHERE " + frag_eiienvd
    return conn.execute(sql_yscgidc).fetchall()
