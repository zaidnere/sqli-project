import java.sql.*;
class Case052 {
  boolean login(Connection c, String u, String p) throws Exception {
    String sql = "SELECT id FROM users WHERE username='" + u + "' AND password='" + p + "'";
    return c.createStatement().executeQuery(sql).next();
  }
}
