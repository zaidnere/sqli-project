function norm(v){ return v === undefined || v === null ? "" : String(v).trim(); }
function clamp(v, lo, hi){ const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(){ }

class Repo {
  constructor(db){ this.db = db; }
  async search(req){
    const params = [req.tenantId, norm(req.query.email)];
    const decoy = norm(req.query.sql);
    audit(decoy);
    return this.db.all("SELECT id,email FROM users WHERE tenant_id=? AND email=?", [...params]);
  }
}
module.exports = Repo;
