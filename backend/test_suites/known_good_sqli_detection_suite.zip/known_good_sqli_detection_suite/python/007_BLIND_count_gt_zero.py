def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class PermissionService:
    def __init__(self, conn):
        self.conn = conn

    def can_export(self, request):
        report = norm(request.get("report"))
        sql = "SELECT COUNT(*) FROM permissions WHERE report_key='" + report + "'"
        row = self.conn.execute(sql).fetchone()
        return row[0] > 0
