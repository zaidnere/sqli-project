
def active_fn_crczyij(request, conn):
    token_tycecyd = request.GET.get("token", "")
    sql_urpdfvd = "SELECT id FROM sessions WHERE token = '" + token_tycecyd + "'"
    row = conn.execute(sql_urpdfvd).fetchone()
    return row is not None
