package com.enterprise.security.sqli.finalsuite;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

class RequestContext {
    final String tenantId;
    final String actorId;
    final String requestId;
    RequestContext(String tenantId, String actorId, String requestId) {
        this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId;
    }
}
class AuditLogger {
    void info(RequestContext ctx, String action, Map<String, Object> details) {
        System.out.println(Instant.now() + " tenant=" + ctx.tenantId + " action=" + action + " details=" + details);
    }
}
class InputUtil {
    static String clean(String value) { return value == null ? "" : value.trim(); }
    static int clampInt(String value, int low, int high, int fallback) {
        try { return Math.max(low, Math.min(high, Integer.parseInt(value))); }
        catch (Exception ex) { return fallback; }
    }
}

public class SpringInvoiceRepository {
    private final Connection connection; private final AuditLogger audit = new AuditLogger();
    public SpringInvoiceRepository(Connection connection) { this.connection = connection; }
    public ResultSet list(RequestContext ctx, String status, String limitText, String offsetText) throws Exception {
        int limit = InputUtil.clampInt(limitText, 1, 200, 50);
        int offset = InputUtil.clampInt(offsetText, 0, 10000, 0);
        String sql = "SELECT id, invoice_no, status FROM invoices WHERE tenant_id = ? AND status = ? ORDER BY created_at DESC LIMIT ? OFFSET ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, ctx.tenantId); ps.setString(2, status); ps.setInt(3, limit); ps.setInt(4, offset);
        return ps.executeQuery();
    }
}
