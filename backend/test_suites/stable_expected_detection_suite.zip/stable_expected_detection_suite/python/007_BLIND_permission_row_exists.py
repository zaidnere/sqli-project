def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class PermissionService:
    def __init__(self, conn):
        self.conn = conn

    def can_download(self, request):
        resource = norm(request.get("resource"))
        sql = "SELECT id FROM permissions WHERE actor_id='" + request["actor"] + "' AND resource_key='" + resource + "'"
        row = self.conn.execute(sql).fetchone()
        return row is not None
