<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class Repo {
    private PDO $pdo;
    private array $sorts = ["created"=>"created_at","email"=>"email"];
    public function __construct(PDO $pdo){ $this->pdo = $pdo; }
    public function list(array $q): array {
        $raw = norm($q["sort"] ?? "created");
        $safe = $this->sorts[$raw] ?? "created_at";
        $sql = "SELECT id FROM users WHERE tenant_id=? ORDER BY " . $raw;
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
