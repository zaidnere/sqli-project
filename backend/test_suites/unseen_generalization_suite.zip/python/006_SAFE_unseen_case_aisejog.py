
# decoy: SELECT * FROM users WHERE id = raw_input
def search_fn_gaenthn(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_pbjpnuw = allowed.get(request.GET.get("sort"), "created_at")
    limit_hepaksf = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_wprbnge = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + order_pbjpnuw + " LIMIT ?"
    decoy = "SELECT * FROM users WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_wprbnge, (request.user.tenant_id, limit_hepaksf)).fetchall()
