// db.all(`SELECT * FROM users WHERE email='${req.query.email}'`)
function ok(){ return "SELECT id FROM users WHERE id=" + "not executed"; }
module.exports = { ok };
