// SELECT * FROM users WHERE id = " + raw
/*
Statement st = c.createStatement();
st.executeQuery("SELECT * FROM users WHERE x=" + input);
*/
public class OnlyCommentsJava {
    public boolean ok() { return true; }
}
