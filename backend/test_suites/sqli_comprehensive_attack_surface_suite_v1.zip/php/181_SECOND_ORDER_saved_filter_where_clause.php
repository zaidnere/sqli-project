<?php
interface ConfigService { public function load(string $id): object; }
final class CaseRepo {
  public function __construct(private PDO $pdo, private ConfigService $config) {}
  public function run(string $id): array {
    $cfg = $this->config->load($id);
    $where = $cfg->whereClause ?? "1=1";
    $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE " . $where);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
}
