class Repo{constructor(db){this.db=db;} list(req){return this.db.all("SELECT id,email FROM users ORDER BY created_at "+req.query.dir);}} module.exports=Repo;
