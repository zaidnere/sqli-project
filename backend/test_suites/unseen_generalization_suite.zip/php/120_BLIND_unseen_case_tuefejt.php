<?php
function login_fn_cerbpup($mysqli) {
    $name = $_POST["name"] ?? "";
    $sql = "SELECT id FROM users WHERE name='" . $name . "'";
    $res = mysqli_query($mysqli, $sql);
    return mysqli_num_rows($res) > 0;
}
?>