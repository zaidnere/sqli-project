import javax.persistence.*;
public class Repo { private final EntityManager em; public Repo(EntityManager em){this.em=em;}
  public Object find(String email){ return em.createQuery("select u from User u where u.email = :email").setParameter("email", email).getResultList(); }
}
