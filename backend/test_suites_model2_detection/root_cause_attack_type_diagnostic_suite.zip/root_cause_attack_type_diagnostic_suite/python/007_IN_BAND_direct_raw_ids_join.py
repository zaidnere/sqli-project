def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*a): pass

class BulkLookup:
    def __init__(self, conn): self.conn = conn
    def load(self, request):
        ids = request.get("ids", [])
        joined = ",".join(ids)
        sql = "SELECT id,email FROM users WHERE tenant_id=? AND id IN (" + joined + ")"
        return self.conn.execute(sql, [request["tenant"]]).fetchall()
