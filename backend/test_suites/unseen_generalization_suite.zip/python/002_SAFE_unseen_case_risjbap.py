
# safe path uses parameters, unsafe path should be detected
def search_fn_qzeeyhx(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_brrluqi = allowed.get(request.GET.get("sort"), "created_at")
    limit_imgjxdp = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_ipphyhb = "SELECT id, email FROM orders WHERE tenant_id = ? ORDER BY " + order_brrluqi + " LIMIT ?"
    decoy = "SELECT * FROM orders WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_ipphyhb, (request.user.tenant_id, limit_imgjxdp)).fetchall()
