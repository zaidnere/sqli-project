
# decoy: SELECT * FROM users WHERE id = raw_input
def lookup_fn_zqyrdqj(request, conn):
    email_waowhzu = request.GET.get("email", "")
    sql_jvmzvif = "SELECT * FROM users WHERE email = '" + email_waowhzu + "'"
    return conn.execute(sql_jvmzvif).fetchall()
