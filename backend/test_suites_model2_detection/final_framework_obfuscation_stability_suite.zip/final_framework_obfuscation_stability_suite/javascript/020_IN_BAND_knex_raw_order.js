function norm(v) { return v === undefined || v === null ? '' : String(v).trim(); }
function clamp(v, lo, hi) { const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(logger, ctx, action, details) { if (logger) logger.info({ctx, action, details}); }

function helper0(value) { return { idx: 0, value, at: new Date().toISOString() }; }
function helper1(value) { return { idx: 1, value, at: new Date().toISOString() }; }
function helper2(value) { return { idx: 2, value, at: new Date().toISOString() }; }
function helper3(value) { return { idx: 3, value, at: new Date().toISOString() }; }
function helper4(value) { return { idx: 4, value, at: new Date().toISOString() }; }
function helper5(value) { return { idx: 5, value, at: new Date().toISOString() }; }
function helper6(value) { return { idx: 6, value, at: new Date().toISOString() }; }
function helper7(value) { return { idx: 7, value, at: new Date().toISOString() }; }
function helper8(value) { return { idx: 8, value, at: new Date().toISOString() }; }
function helper9(value) { return { idx: 9, value, at: new Date().toISOString() }; }
function helper10(value) { return { idx: 10, value, at: new Date().toISOString() }; }
function helper11(value) { return { idx: 11, value, at: new Date().toISOString() }; }
function helper12(value) { return { idx: 12, value, at: new Date().toISOString() }; }
function helper13(value) { return { idx: 13, value, at: new Date().toISOString() }; }
function helper14(value) { return { idx: 14, value, at: new Date().toISOString() }; }
function helper15(value) { return { idx: 15, value, at: new Date().toISOString() }; }
function helper16(value) { return { idx: 16, value, at: new Date().toISOString() }; }
function helper17(value) { return { idx: 17, value, at: new Date().toISOString() }; }
function helper18(value) { return { idx: 18, value, at: new Date().toISOString() }; }
function helper19(value) { return { idx: 19, value, at: new Date().toISOString() }; }
function helper20(value) { return { idx: 20, value, at: new Date().toISOString() }; }
function helper21(value) { return { idx: 21, value, at: new Date().toISOString() }; }
function helper22(value) { return { idx: 22, value, at: new Date().toISOString() }; }
function helper23(value) { return { idx: 23, value, at: new Date().toISOString() }; }
function helper24(value) { return { idx: 24, value, at: new Date().toISOString() }; }
function helper25(value) { return { idx: 25, value, at: new Date().toISOString() }; }
function helper26(value) { return { idx: 26, value, at: new Date().toISOString() }; }
function helper27(value) { return { idx: 27, value, at: new Date().toISOString() }; }
function helper28(value) { return { idx: 28, value, at: new Date().toISOString() }; }
function helper29(value) { return { idx: 29, value, at: new Date().toISOString() }; }
function helper30(value) { return { idx: 30, value, at: new Date().toISOString() }; }
function helper31(value) { return { idx: 31, value, at: new Date().toISOString() }; }
function helper32(value) { return { idx: 32, value, at: new Date().toISOString() }; }
function helper33(value) { return { idx: 33, value, at: new Date().toISOString() }; }
function helper34(value) { return { idx: 34, value, at: new Date().toISOString() }; }
function helper35(value) { return { idx: 35, value, at: new Date().toISOString() }; }
function helper36(value) { return { idx: 36, value, at: new Date().toISOString() }; }
function helper37(value) { return { idx: 37, value, at: new Date().toISOString() }; }
function helper38(value) { return { idx: 38, value, at: new Date().toISOString() }; }
function helper39(value) { return { idx: 39, value, at: new Date().toISOString() }; }
class KnexRawOrder {
  async list(knex, req) {
    const raw = norm(req.query.sort);
    return knex.raw("SELECT id,email FROM users WHERE tenant_id = ? ORDER BY " + raw, [req.tenantId]);
  }
}
module.exports = KnexRawOrder;
