<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class FeatureFlagRaw {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }
    public function enabled(array $q): bool {
        $feature = norm($q["feature"] ?? "");
        $r = $this->db->query("SELECT COUNT(*) AS c FROM feature_flags WHERE feature_key='" . $feature . "'");
        $row = $r ? $r->fetch_assoc() : ["c" => 0];
        return (int)$row["c"] > 0;
    }
}
