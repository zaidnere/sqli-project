class Tokens:
    def __init__(self, db): self.db = db
    def exists(self, req):
        token = req.headers.get("X-Token","")
        return self.db.execute("SELECT id FROM tokens WHERE token='" + token + "'").fetchone() is not None
