async function listOrdersSafeSequelizeReplacements(req, sequelize) {
  const sql = "SELECT id, email FROM users WHERE tenant_id = :tenant AND email = :email";
  return sequelize.query(sql, {
    replacements: {
      tenant: req.user.tenantId,
      email: String(req.query.email || "").trim()
    }
  });
}

module.exports = { listOrdersSafeSequelizeReplacements };
