
# noise comment with SQL_CONCAT looking words but no sink
def lookup_fn_dqwldmg(request, conn):
    email_fxwvqwm = request.GET.get("email", "")
    sql_kcxeyeq = "SELECT * FROM users WHERE email = '" + email_fxwvqwm + "'"
    return conn.execute(sql_kcxeyeq).fetchall()
