import java.sql.*;
public class SOConfig {
  private final Connection c; private final ConfigService svc; public SOConfig(Connection c,ConfigService svc){this.c=c;this.svc=svc;}
  public ResultSet list(String tenant)throws SQLException{ Config cfg=svc.load(tenant); String cond=cfg.whereClause; return c.createStatement().executeQuery("SELECT id FROM users WHERE tenant_id='"+tenant+"' AND "+cond); }
  interface ConfigService{ Config load(String t); } static class Config{ String whereClause; }
}
