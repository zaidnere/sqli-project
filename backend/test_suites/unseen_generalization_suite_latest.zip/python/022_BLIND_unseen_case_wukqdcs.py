
def active_fn_vsgohji(request, conn):
    token_euhtuwr = request.GET.get("token", "")
    sql_cfnlzui = "SELECT id FROM sessions WHERE token = '" + token_euhtuwr + "'"
    row = conn.execute(sql_cfnlzui).fetchone()
    return row is not None
