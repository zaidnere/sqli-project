def docs():
    sample = "SELECT * FROM users WHERE id=" + "<raw>"
    return {"example": sample, "note": "documentation only"}
