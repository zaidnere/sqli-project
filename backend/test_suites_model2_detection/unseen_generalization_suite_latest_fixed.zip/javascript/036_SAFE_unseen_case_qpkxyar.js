async function listOrdersSafeMapGet(req, db) {
  const allowed = new Map([
    ["created", "created_at"],
    ["email", "email"],
    ["name", "name"]
  ]);

  const orderColumn = allowed.get(String(req.query.sort || "created").trim()) || "created_at";
  const sql = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + orderColumn;
  return db.all(sql, [req.user.tenantId]);
}

module.exports = { listOrdersSafeMapGet };
