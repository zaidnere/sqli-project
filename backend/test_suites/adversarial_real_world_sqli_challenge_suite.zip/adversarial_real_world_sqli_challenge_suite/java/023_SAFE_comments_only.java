// c.createStatement().executeQuery("SELECT * FROM users WHERE id=" + raw);
public class CommentsOnly {
    public String demo(){ return "SELECT id FROM users WHERE id=" + "not executed"; }
}
