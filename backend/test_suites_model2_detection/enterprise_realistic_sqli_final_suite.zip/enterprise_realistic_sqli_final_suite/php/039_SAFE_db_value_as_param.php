<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class SafeDepartmentRepository {
    private PDO $pdo; public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function departmentCode(array $ctx, int $userId): string { $stmt = $this->pdo->prepare("SELECT department_code FROM users WHERE tenant_id = ? AND id = ?"); $stmt->execute([$ctx["tenant"], $userId]); $row = $stmt->fetch(PDO::FETCH_ASSOC); return $row["department_code"] ?? ""; }
    public function listOrders(array $ctx, int $userId): array { $code = $this->departmentCode($ctx, $userId); $stmt = $this->pdo->prepare("SELECT id, order_no FROM orders WHERE tenant_id = ? AND department_code = ?"); $stmt->execute([$ctx["tenant"], $code]); return $stmt->fetchAll(PDO::FETCH_ASSOC); }
}
