<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class TokenExistsCheck {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }
    public function tokenExists(array $q): bool {
        $token = norm($q["token"] ?? "");
        $r = $this->db->query("SELECT id FROM api_tokens WHERE token='" . $token . "' AND active=1");
        $row = $r ? $r->fetch_assoc() : null;
        return $row !== null;
    }
}
