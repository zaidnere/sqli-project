<?php
final class Repo { public function __construct(private mysqli $db) {} public function page(array $q): array { $r=$this->db->query("SELECT id FROM users LIMIT ".($q["limit"]??"25")." OFFSET ".($q["offset"]??"0")); return $r?$r->fetch_all(MYSQLI_ASSOC):[]; } }
