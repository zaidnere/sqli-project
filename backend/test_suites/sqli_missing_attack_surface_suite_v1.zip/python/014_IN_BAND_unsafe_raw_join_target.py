class Repo:
    def __init__(self, db): self.db = db
    def report(self, req):
        table = req.args.get("join","")
        return self.db.execute("SELECT u.id FROM users u JOIN " + table + " x ON x.user_id=u.id").fetchall()
