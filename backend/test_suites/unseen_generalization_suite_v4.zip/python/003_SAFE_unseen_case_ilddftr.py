
# decoy: SELECT * FROM users WHERE id = raw_input
def search_fn_fsvgzyh(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_wflaluj = allowed.get(request.GET.get("sort"), "created_at")
    limit_zjooliy = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_fvfesma = "SELECT id, email FROM reports WHERE tenant_id = ? ORDER BY " + order_wflaluj + " LIMIT ?"
    decoy = "SELECT * FROM reports WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_fvfesma, (request.user.tenant_id, limit_zjooliy)).fetchall()
