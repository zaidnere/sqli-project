async function runAdminQuery(db, queryId) {
  const row = await db.get("SELECT sql_text FROM admin_queries WHERE id=?", [queryId]);
  return db.all(row.sql_text);
}
