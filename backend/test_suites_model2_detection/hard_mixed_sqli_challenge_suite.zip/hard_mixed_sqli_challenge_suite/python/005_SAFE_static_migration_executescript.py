def migrate(conn):
    schema = """
    CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY, message TEXT);
    CREATE INDEX IF NOT EXISTS idx_audit_message ON audit_log(message);
    """
    return conn.executescript(schema)
