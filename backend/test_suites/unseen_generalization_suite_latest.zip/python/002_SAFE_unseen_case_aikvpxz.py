
# safe path uses parameters, unsafe path should be detected
def search_fn_tzxfxeh(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_flbxxiy = allowed.get(request.GET.get("sort"), "created_at")
    limit_vjqbkek = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_duyqstq = "SELECT id, email FROM profiles WHERE tenant_id = ? ORDER BY " + order_flbxxiy + " LIMIT ?"
    decoy = "SELECT * FROM profiles WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_duyqstq, (request.user.tenant_id, limit_vjqbkek)).fetchall()
