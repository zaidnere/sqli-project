// c.createStatement().executeQuery("SELECT * FROM users WHERE email='" + email + "'");
public class JavaCommentsOnly {
    public String text(String email) {
        return "SELECT id FROM users WHERE email='" + email + "'";
    }
}
