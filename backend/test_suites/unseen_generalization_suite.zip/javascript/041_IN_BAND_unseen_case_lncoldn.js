
async function find_fn_xqnktre(req, db) {
  const email = req.query.email || "";
  const sql = `SELECT * FROM users WHERE email = '${email}'`;
  return db.all(sql);
}
