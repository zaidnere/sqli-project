
# safe path uses parameters, unsafe path should be detected
def search_fn_sgkpsjh(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_hzmoooa = allowed.get(request.GET.get("sort"), "created_at")
    limit_baedimt = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_tpfovxv = "SELECT id, email FROM invoices WHERE tenant_id = ? ORDER BY " + order_hzmoooa + " LIMIT ?"
    decoy = "SELECT * FROM invoices WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_tpfovxv, (request.user.tenant_id, limit_baedimt)).fetchall()
