
def load_kplbxcq(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_tlagkfw(request, conn):
    frag_cxfunmh = load_kplbxcq(conn, request.user.tenant_id)
    sql_beecxsm = "SELECT * FROM audit_log WHERE " + frag_cxfunmh
    return conn.execute(sql_beecxsm).fetchall()
