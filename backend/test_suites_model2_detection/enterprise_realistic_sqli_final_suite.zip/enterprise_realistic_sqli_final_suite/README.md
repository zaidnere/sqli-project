# Enterprise Realistic SQLi Final Suite

Generated: 2026-05-06T08:02:55.589767Z

A final hard realistic suite for the ML/SAST SQL Injection detector.

Total cases: 40

Languages:
- Python: 10
- JavaScript: 10
- Java: 10
- PHP: 10

Design goals:
- long repository/service/controller-style files
- realistic helper code and audit/logging context
- safe and unsafe queries with similar structure
- decoy variables that look dangerous but are not executed
- direct in-band SQLi
- blind boolean/security decisions
- second-order stored/config/cache/DB-loaded SQL fragments
- strong safe evidence: placeholders, PreparedStatement, PDO prepare, db.all params, allowlists, numeric bounds
