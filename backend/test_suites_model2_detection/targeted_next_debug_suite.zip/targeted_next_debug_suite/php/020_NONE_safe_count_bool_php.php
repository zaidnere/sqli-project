<?php
function isEmailRegisteredSafe($conn, $email) {
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    return $row["c"] > 0;
}
?>
