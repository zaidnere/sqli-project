import sqlite3
def get_orders(conn, ids):
    if not ids:
        return []
    placeholders = ",".join("?" for _ in ids)
    sql = f"SELECT id, total FROM orders WHERE id IN ({placeholders})"
    cur = conn.cursor()
    cur.execute(sql, tuple(ids))
    return cur.fetchall()
