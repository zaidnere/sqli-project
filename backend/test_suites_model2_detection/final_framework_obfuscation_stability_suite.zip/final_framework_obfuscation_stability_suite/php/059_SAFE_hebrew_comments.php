<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? '' : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int { $n = filter_var($v, FILTER_VALIDATE_INT); if ($n === false) $n = $lo; return max($lo, min($hi, $n)); }

function helper_0($value): array { return ['idx' => 0, 'value' => $value]; }
function helper_1($value): array { return ['idx' => 1, 'value' => $value]; }
function helper_2($value): array { return ['idx' => 2, 'value' => $value]; }
function helper_3($value): array { return ['idx' => 3, 'value' => $value]; }
function helper_4($value): array { return ['idx' => 4, 'value' => $value]; }
function helper_5($value): array { return ['idx' => 5, 'value' => $value]; }
function helper_6($value): array { return ['idx' => 6, 'value' => $value]; }
function helper_7($value): array { return ['idx' => 7, 'value' => $value]; }
function helper_8($value): array { return ['idx' => 8, 'value' => $value]; }
function helper_9($value): array { return ['idx' => 9, 'value' => $value]; }
function helper_10($value): array { return ['idx' => 10, 'value' => $value]; }
function helper_11($value): array { return ['idx' => 11, 'value' => $value]; }
function helper_12($value): array { return ['idx' => 12, 'value' => $value]; }
function helper_13($value): array { return ['idx' => 13, 'value' => $value]; }
function helper_14($value): array { return ['idx' => 14, 'value' => $value]; }
function helper_15($value): array { return ['idx' => 15, 'value' => $value]; }
function helper_16($value): array { return ['idx' => 16, 'value' => $value]; }
function helper_17($value): array { return ['idx' => 17, 'value' => $value]; }
function helper_18($value): array { return ['idx' => 18, 'value' => $value]; }
function helper_19($value): array { return ['idx' => 19, 'value' => $value]; }
// הערה: SELECT * FROM users WHERE id = " . $_GET["id"]
final class HebrewCommentPhpSafe {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function get(array $q): array {
        $stmt = $this->pdo->prepare("SELECT id FROM users WHERE tenant_id=? AND id=?");
        $stmt->execute([$q["tenant"], (int)$q["id"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
