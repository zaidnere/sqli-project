import java.sql.*;
import java.util.*;

class AppCtx {
    String tenantId;
    String actorId;
    AppCtx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class SavedReportRunner {
    private final Connection c;
    public SavedReportRunner(Connection c) { this.c = c; }

    private String loadWhere(AppCtx ctx, long reportId) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "SELECT where_clause FROM saved_reports WHERE tenant_id=? AND report_id=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setLong(2, reportId);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("where_clause") : "1=1";
    }

    public ResultSet run(AppCtx ctx, long reportId) throws Exception {
        String where = loadWhere(ctx, reportId);
        String sql = "SELECT id,email FROM customers WHERE tenant_id='" + ctx.tenantId + "' AND " + where;
        return c.createStatement().executeQuery(sql);
    }
}
