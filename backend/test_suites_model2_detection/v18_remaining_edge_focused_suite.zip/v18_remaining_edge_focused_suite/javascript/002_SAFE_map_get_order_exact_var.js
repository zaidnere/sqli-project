function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class SafeMapGetOrder {
  constructor(db) { this.db = db; }
  async list(req) {
    const allowed = new Map([["created", "created_at"], ["email", "email"], ["lastLogin", "last_login_at"]]);
    const selected = allowed.get(norm(req.query.sort)) || "created_at";
    const sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + selected;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = SafeMapGetOrder;
