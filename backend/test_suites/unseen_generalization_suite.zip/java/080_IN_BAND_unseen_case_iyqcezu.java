
import java.sql.*;
class Svctaqpgzf {
  ResultSet find(HttpServletRequest req, Statement st) throws Exception {
    String email = req.getParameter("email");
    String sql = "SELECT * FROM users WHERE email='" + email + "'";
    return st.executeQuery(sql);
  }
}
