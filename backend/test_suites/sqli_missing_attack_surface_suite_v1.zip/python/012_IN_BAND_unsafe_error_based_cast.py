class Repo:
    def __init__(self, db): self.db = db
    def probe(self, req):
        value = req.args.get("value","")
        return self.db.execute("SELECT CAST('" + value + "' AS INT)").fetchall()
