class Repo:
    def __init__(self, db): self.db = db
    def find(self, req):
        user_id = int(req.args.get("id", "0"))
        return self.db.execute("SELECT id,email FROM users WHERE id=?", [user_id]).fetchone()
