import java.sql.*;
class Case055 {
  boolean validToken(Connection c, String token) throws Exception {
    String sql = "SELECT id FROM reset_tokens WHERE used=0 AND token='" + token + "'";
    return c.createStatement().executeQuery(sql).next();
  }
}
