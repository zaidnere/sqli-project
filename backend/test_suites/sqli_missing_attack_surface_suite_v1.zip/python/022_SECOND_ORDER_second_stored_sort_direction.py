class Repo:
    def __init__(self, db): self.db = db
    def run(self, req):
        row = self.db.execute("SELECT sort_direction FROM report_settings WHERE id=?", [req.args.get("id")]).fetchone()
        fragment = row["sort_direction"]
        return self.db.execute("SELECT id,email FROM users WHERE " + fragment).fetchall()
