function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class UserRepo {
  constructor(db) { this.db = db; }

  async findByEmail(req) {
    const sql = "SELECT id,email FROM users WHERE tenant_id=? AND email=?";
    return this.db.get(sql, [req.tenantId, norm(req.query.email)]);
  }
}
module.exports = UserRepo;
