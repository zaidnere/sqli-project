class Repo { constructor(db){ this.db=db; }
  async find(req){ const email=String(req.query.email||"").trim();
    return this.db.all("SELECT id,email FROM users WHERE tenant_id=? AND email=?", [req.user.tenantId,email]); } }
module.exports=Repo;
