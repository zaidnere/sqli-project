class Repo:
    def __init__(self, db): self.db = db
    def list(self):
        sql = "SELECT id,email FROM users " + "WHERE active=1 " + "ORDER BY created_at DESC"
        return self.db.execute(sql).fetchall()
