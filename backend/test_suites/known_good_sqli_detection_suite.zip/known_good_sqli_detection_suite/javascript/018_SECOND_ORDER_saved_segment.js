function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class SegmentRunner {
  constructor(db) { this.db = db; }

  async loadSegment(ctx, key) {
    const row = await this.db.get(
      "SELECT where_clause FROM saved_segments WHERE tenant_id=? AND segment_key=?",
      [ctx.tenantId, key]
    );
    return row ? row.where_clause : "1=1";
  }

  async run(ctx, key) {
    const where = await this.loadSegment(ctx, key);
    const sql = "SELECT id,email FROM users WHERE tenant_id=? AND " + where;
    return this.db.all(sql, [ctx.tenantId]);
  }
}
module.exports = SegmentRunner;
