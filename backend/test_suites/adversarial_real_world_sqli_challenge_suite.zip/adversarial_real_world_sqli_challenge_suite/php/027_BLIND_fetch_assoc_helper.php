<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class Gate {
    private mysqli $db;
    public function __construct(mysqli $db){ $this->db = $db; }
    private function hasRow(string $sql): bool {
        $r = $this->db->query($sql);
        return $r && $r->fetch_assoc() !== null;
    }
    public function canDelete(array $q): bool {
        $res = norm($q["resource"] ?? "");
        $sql = "SELECT id FROM permissions WHERE actor_id='" . $q["actor"] . "' AND resource_key='" . $res . "'";
        return $this->hasRow($sql);
    }
}
