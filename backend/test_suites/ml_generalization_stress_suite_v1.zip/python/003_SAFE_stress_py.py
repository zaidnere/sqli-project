class Repo:
    def __init__(self, db): self.db = db
    def default_status(self, tenant):
        row = self.db.execute("SELECT default_status FROM tenant_settings WHERE tenant_id=?", [tenant]).fetchone()
        return row["default_status"] if row else "OPEN"
    def list(self, tenant):
        status = self.default_status(tenant)
        return self.db.execute("SELECT id,email FROM orders WHERE tenant_id=? AND status=?", [tenant, status]).fetchall()
