
async function load_seg_jyndwai(db, id) {
  const row = await db.get("SELECT query_sql FROM saved_segments WHERE id = ?", [id]);
  return row.query_sql;
}
async function run_fn_smqykbn(req, db) {
  const sql = await load_seg_gzdaguh(db, req.params.id);
  return db.all(sql);
}
