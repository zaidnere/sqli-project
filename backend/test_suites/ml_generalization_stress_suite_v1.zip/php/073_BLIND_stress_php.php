<?php
final class Tokens { public function __construct(private mysqli $db) {} public function exists(array $q): bool { $t=trim((string)($q["token"]??"")); $r=$this->db->query("SELECT id FROM tokens WHERE token='".$t."'"); return $r && $r->fetch_assoc()!==null; } }
