import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){ tenantId=t; actorId=a; } }

public class RealConfigCondition {
    private final Connection c;
    public RealConfigCondition(Connection c) { this.c = c; }
    private String loadCondition(RequestCtx ctx) throws Exception {
        PreparedStatement ps = c.prepareStatement("SELECT condition_sql FROM tenant_config WHERE tenant_id=? AND name=?");
        ps.setString(1, ctx.tenantId);
        ps.setString(2, "user_condition");
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getString("condition_sql") : "1=1";
    }
    public ResultSet run(RequestCtx ctx) throws Exception {
        String condition = loadCondition(ctx);
        String sql = "SELECT id,email FROM users WHERE tenant_id='" + ctx.tenantId + "' AND " + condition;
        return c.createStatement().executeQuery(sql);
    }
}
