class Repo { constructor(db){this.db=db;} list(){ const sql="SELECT id,email FROM users "+"WHERE active=1 "+"ORDER BY created_at DESC"; return this.db.all(sql); } }
module.exports = Repo;
