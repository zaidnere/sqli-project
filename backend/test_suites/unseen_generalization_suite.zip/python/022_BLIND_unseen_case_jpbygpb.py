
def active_fn_oemlrop(request, conn):
    token_axejwry = request.GET.get("token", "")
    sql_pxqsldf = "SELECT id FROM sessions WHERE token = '" + token_axejwry + "'"
    row = conn.execute(sql_pxqsldf).fetchone()
    return row is not None
