
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def lookup_fn_djhtecn(request, conn):
    email_iuhvrha = request.GET.get("email", "")
    sql_umjkoru = "SELECT * FROM users WHERE email = '" + email_iuhvrha + "'"
    return conn.execute(sql_umjkoru).fetchall()
