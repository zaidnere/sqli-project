
def active_fn_qblywrl(request, conn):
    token_jipmsuj = request.GET.get("token", "")
    sql_uvzahsf = "SELECT id FROM sessions WHERE token = '" + token_jipmsuj + "'"
    row = conn.execute(sql_uvzahsf).fetchone()
    return row is not None
