// c.createStatement().executeQuery("SELECT * FROM users WHERE id=" + raw);
public class CommentsOnly {
    public String debug(String email) {
        return "SELECT id FROM users WHERE email='" + email + "'";
    }
}
