function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class CacheConfigOrderClause {
  constructor(db, configCache) {
    this.db = db;
    this.configCache = configCache;
  }

  async list(ctx) {
    const config = await this.configCache.getTenantConfig(ctx.tenantId);
    const orderClause = config && config.orderClause ? config.orderClause : "created_at DESC";
    const sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + orderClause;
    return this.db.all(sql, [ctx.tenantId]);
  }
}
module.exports = CacheConfigOrderClause;
