class Repo{async find(sequelize,req){const email=String(req.query.email||""); return sequelize.query(`SELECT id,email FROM users WHERE email='${email}'`);}} module.exports=Repo;
