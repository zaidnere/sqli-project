class Jobs:
    def __init__(self, db): self.db = db
    def run(self, job_id):
        row = self.db.execute("SELECT sql_body FROM jobs WHERE id=?", [job_id]).fetchone()
        return self.db.execute(row["sql_body"]).fetchall()
