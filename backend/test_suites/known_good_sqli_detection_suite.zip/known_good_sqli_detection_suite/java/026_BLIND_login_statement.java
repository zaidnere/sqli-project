import java.sql.*;
import java.util.*;

class Ctx {
    String tenantId;
    String actorId;
    Ctx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class Login {
    private final Connection c;
    public Login(Connection c) { this.c = c; }

    public boolean login(String email, String password) throws Exception {
        String sql = "SELECT id FROM users WHERE email='" + email + "' AND password_hash='" + password + "'";
        ResultSet rs = c.createStatement().executeQuery(sql);
        return rs.next();
    }
}
