class UnsafeColumnRepository:
    def __init__(self, db): self.db = db
    def values(self, req):
        col = req.args.get("column", "")
        return self.db.execute("SELECT " + col + " FROM users WHERE tenant_id=?", [req.tenant_id]).fetchall()
