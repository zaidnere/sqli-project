<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class Runner {
    private PDO $pdo;
    public function __construct(PDO $pdo){ $this->pdo = $pdo; }
    private function loadOrder(array $q): string {
        $stmt = $this->pdo->prepare("SELECT value FROM tenant_config WHERE tenant_id=? AND name=?");
        $stmt->execute([$q["tenant"], "user_order"]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row["value"] ?? "created_at DESC";
    }
    public function list(array $q): array {
        $order = $this->loadOrder($q);
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? ORDER BY " . $order);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
