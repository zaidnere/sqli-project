<?php
function load_f_tsfnhzy($pdo, $id) {
    $stmt = $pdo->prepare("SELECT where_clause FROM saved_filters WHERE id=?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row["where_clause"];
}
function run_fn_igmolft($pdo, $id) {
    $where = load_f_jqtndge($pdo, $id);
    $sql = "SELECT * FROM audit_log WHERE " . $where;
    return $pdo->query($sql)->fetchAll();
}
?>