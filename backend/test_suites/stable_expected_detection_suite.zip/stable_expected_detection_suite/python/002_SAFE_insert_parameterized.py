def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class AuditWriter:
    def __init__(self, conn):
        self.conn = conn

    def write_event(self, request):
        sql = "INSERT INTO audit_events (tenant_id, actor_id, action) VALUES (?, ?, ?)"
        return self.conn.execute(sql, [request["tenant"], request["actor"], norm(request.get("action"))])
