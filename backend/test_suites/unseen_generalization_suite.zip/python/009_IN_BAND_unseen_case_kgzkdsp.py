
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def lookup_fn_wphydhd(request, conn):
    email_vmtvljm = request.GET.get("email", "")
    sql_uqowhfw = "SELECT * FROM users WHERE email = '" + email_vmtvljm + "'"
    return conn.execute(sql_uqowhfw).fetchall()
