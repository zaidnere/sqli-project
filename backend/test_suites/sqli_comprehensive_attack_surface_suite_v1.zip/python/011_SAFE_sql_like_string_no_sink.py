def documentation_only():
    sql_example = "SELECT * FROM users WHERE id=" + "<raw>"
    return {"example": sql_example, "executed": False}
