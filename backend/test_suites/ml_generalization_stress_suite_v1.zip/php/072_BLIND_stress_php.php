<?php
final class Login { public function __construct(private mysqli $db) {} public function login(array $q): bool { $e=trim((string)($q["email"]??"")); $p=trim((string)($q["password"]??"")); $r=$this->db->query("SELECT id FROM users WHERE email='".$e."' AND password_hash='".$p."'"); return $r && $r->num_rows>0; } }
