
def load_yafotap(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_fnibcxb(request, conn):
    frag_pyncdou = load_yafotap(conn, request.user.tenant_id)
    sql_uiphqrv = "SELECT * FROM audit_log WHERE " + frag_pyncdou
    return conn.execute(sql_uiphqrv).fetchall()
