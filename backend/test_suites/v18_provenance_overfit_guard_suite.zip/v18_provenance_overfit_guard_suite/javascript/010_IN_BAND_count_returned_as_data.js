function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class JsCountReturnedAsData {
  constructor(db) { this.db = db; }

  async countByStatus(req) {
    const status = norm(req.query.status);
    const row = await this.db.get(
      "SELECT COUNT(*) AS c FROM orders WHERE status='" + status + "'"
    );
    return { count: row ? row.c : 0 };
  }
}
module.exports = JsCountReturnedAsData;
