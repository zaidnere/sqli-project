
def active_fn_ixiittb(request, conn):
    token_oyhddrc = request.GET.get("token", "")
    sql_ylgiwmx = "SELECT id FROM sessions WHERE token = '" + token_oyhddrc + "'"
    row = conn.execute(sql_ylgiwmx).fetchone()
    return row is not None
