function norm(v){ return v === undefined || v === null ? "" : String(v).trim(); }
function clamp(v, lo, hi){ const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(){ }

class Repo {
  constructor(db){ this.db = db; }
  async count(req){
    const table = norm(req.query.table);
    const sql = "SELECT COUNT(*) AS c FROM " + table + " WHERE tenant_id=?";
    const call = this.db.get.bind(this.db);
    return call(sql, [req.tenantId]);
  }
}
module.exports = Repo;
