def email_exists(conn, email):
    sql = "SELECT COUNT(*) FROM users WHERE email = '" + email + "'"
    row = conn.execute(sql).fetchone()
    return row[0] > 0
