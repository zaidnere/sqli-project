<?php
function listUsers($pdo, $rawSort) {
    $allowed = ["name" => "name", "created" => "created_at"];
    $safeSort = $allowed[$rawSort] ?? "created_at";
    return $pdo->query("SELECT id,email FROM users ORDER BY " . $rawSort)->fetchAll();
}
?>
