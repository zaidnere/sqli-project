class StaticLookup:
    def __init__(self, db): self.db = db
    def statuses(self):
        return self.db.execute("SELECT code,label FROM status_codes ORDER BY code").fetchall()
