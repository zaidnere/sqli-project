
# decoy: SELECT * FROM users WHERE id = raw_input
def lookup_fn_cdhwtig(request, conn):
    email_ktikaxw = request.GET.get("email", "")
    sql_sunwmhb = "SELECT * FROM users WHERE email = '" + email_ktikaxw + "'"
    return conn.execute(sql_sunwmhb).fetchall()
