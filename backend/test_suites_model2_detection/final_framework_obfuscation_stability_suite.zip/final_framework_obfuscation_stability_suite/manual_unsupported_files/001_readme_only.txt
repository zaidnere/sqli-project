This is a TXT file with SELECT * FROM users WHERE id = ' + input. Should be used for unsupported-file handling/manual upload.
