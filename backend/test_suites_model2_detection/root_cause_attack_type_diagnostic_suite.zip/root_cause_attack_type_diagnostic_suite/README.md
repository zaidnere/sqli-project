# Root Cause Attack-Type Diagnostic SQLi Suite

Generated: 2026-05-08T13:23:09.576725Z

Total cases: 32

Purpose:
This is a diagnostic suite aimed at the current weak spots:
1. IN_BAND misclassified as SECOND_ORDER.
2. BLIND misclassified as IN_BAND.
3. SQL-looking comments/strings without execution sinks.
4. Java NamedParameterJdbcTemplate safe parameterization.
5. PHP callable aliases to query.
6. Safe DB-loaded value as parameter vs real DB-loaded SQL syntax.

The manifest includes a focus_area column so failures can be grouped by root cause.
