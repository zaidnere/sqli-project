import java.sql.*;
class Case045 {
  ResultSet page(Connection c, String rawLimit, String rawOffset) throws Exception {
    int limit = Math.max(1, Math.min(Integer.parseInt(rawLimit), 100));
    int offset = Math.max(0, Math.min(Integer.parseInt(rawOffset), 10000));
    String sql = "SELECT id,message FROM logs ORDER BY id DESC LIMIT " + limit + " OFFSET " + offset;
    return c.createStatement().executeQuery(sql);
  }
}
