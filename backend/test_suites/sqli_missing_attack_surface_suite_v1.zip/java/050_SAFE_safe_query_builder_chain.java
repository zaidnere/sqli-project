import javax.persistence.criteria.*; public class Repo { public Object build(CriteriaBuilder cb, CriteriaQuery<?> q, Root<?> r, String email){ q.where(cb.equal(r.get("email"), email)); return q; } }
