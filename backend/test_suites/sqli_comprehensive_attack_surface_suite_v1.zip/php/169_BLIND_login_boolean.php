<?php
final class CaseRepo {
  public function __construct(private mysqli $db) {}
  public function run(array $q): bool {
    $key = trim((string)($q["key"] ?? $q["email"] ?? ""));
    $res = $this->db->query("SELECT id FROM security_checks WHERE lookup_key='" . $key . "'");
    return $res && $res->num_rows > 0;
  }
}
