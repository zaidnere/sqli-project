function norm(v){ return v === undefined || v === null ? "" : String(v).trim(); }
function clamp(v, lo, hi){ const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(){ }

class Probe {
  constructor(db){ this.db = db; }
  async run(req){
    const email = norm(req.query.email);
    const sql = `SELECT CASE WHEN email='${email}' THEN SLEEP(5) ELSE 0 END FROM users`;
    await this.db.get(sql);
    return true;
  }
}
module.exports = Probe;
