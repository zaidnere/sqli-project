const allowed = new Set(["name", "created_at", "total"]);
function safeSort(raw) {
  return allowed.has(raw) ? raw : "created_at";
}
async function listOrders(db, rawSort, tenantId) {
  const sort = safeSort(rawSort);
  const sql = "SELECT id,total FROM orders WHERE tenant_id = ? ORDER BY " + sort;
  return db.all(sql, [tenantId]);
}
