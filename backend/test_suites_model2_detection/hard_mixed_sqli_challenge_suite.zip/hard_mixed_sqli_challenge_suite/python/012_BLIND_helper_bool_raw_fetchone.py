def has_permission(conn, user_id, perm):
    sql = f"SELECT 1 FROM permissions WHERE user_id = {user_id} AND perm = '{perm}'"
    return conn.execute(sql).fetchone() is not None
