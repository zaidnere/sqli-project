<?php
function safe_sort($raw): string { return ["created"=>"created_at","email"=>"email"][trim((string)$raw)]??"created_at"; }
final class Repo { public function __construct(private PDO $pdo) {} public function list(array $q): array { $safe=safe_sort($q["sort"]??"created"); $raw=trim((string)($q["sort"]??"")); $s=$this->pdo->query("SELECT id FROM users ORDER BY ".$raw); return $s?$s->fetchAll(PDO::FETCH_ASSOC):[]; } }
