import java.sql.*;
import java.util.*;
import java.time.Instant;

class Ctx { String tenantId; String actorId; Ctx(String t, String a) { tenantId=t; actorId=a; } }
class Page { int limit; int offset; Page(String l, String o) { limit=Math.max(1, Math.min(200, Integer.parseInt(l))); offset=Math.max(0, Math.min(10000, Integer.parseInt(o))); } }

class Helper0 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper1 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper2 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper3 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper4 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper5 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper6 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper7 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper8 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper9 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper10 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper11 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper12 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper13 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper14 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper15 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper16 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper17 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper18 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper19 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper20 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper21 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper22 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper23 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper24 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper25 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper26 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper27 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper28 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper29 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper30 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper31 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper32 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper33 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper34 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper35 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper36 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper37 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper38 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper39 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper40 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper41 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper42 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper43 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper44 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper45 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper46 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper47 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper48 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper49 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper50 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper51 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper52 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper53 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper54 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper55 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper56 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper57 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper58 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper59 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper60 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper61 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper62 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper63 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper64 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper65 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper66 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper67 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper68 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper69 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper70 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper71 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper72 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper73 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper74 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper75 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper76 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper77 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper78 { String normalize(String v) { return v == null ? "" : v.trim(); } }
class Helper79 { String normalize(String v) { return v == null ? "" : v.trim(); } }
public class JavaAllowlistDecoyUnsafe {
    private final Connection c;
    private static final Set<String> SORTS = new HashSet<>(Arrays.asList("created_at", "email"));
    public JavaAllowlistDecoyUnsafe(Connection c) { this.c = c; }
    public ResultSet list(String tenant, String rawSort) throws Exception {
        String safe = SORTS.contains(rawSort) ? rawSort : "created_at";
        String sql = "SELECT id,email FROM users WHERE tenant_id='" + tenant + "' ORDER BY " + rawSort;
        return c.createStatement().executeQuery(sql);
    }
}
