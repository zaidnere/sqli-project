
# safe path uses parameters, unsafe path should be detected
def search_fn_rgzakbz(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_anikmpq = allowed.get(request.GET.get("sort"), "created_at")
    limit_yqmjagk = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_dcxznfh = "SELECT id, email FROM invoices WHERE tenant_id = ? ORDER BY " + order_anikmpq + " LIMIT ?"
    decoy = "SELECT * FROM invoices WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_dcxznfh, (request.user.tenant_id, limit_yqmjagk)).fetchall()
