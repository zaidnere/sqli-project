import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
class RequestCtx { String tenantId; String actorId; RequestCtx(String t,String a){ tenantId=t; actorId=a; } }

public class CountHelper {
    private final Connection c;
    public CountHelper(Connection c) { this.c = c; }
    private int count(String sql) throws Exception {
        ResultSet rs = c.createStatement().executeQuery(sql);
        return rs.next() ? rs.getInt(1) : 0;
    }
    public boolean enabled(String feature) throws Exception {
        String sql = "SELECT COUNT(*) FROM feature_flags WHERE feature_key='" + feature + "'";
        return count(sql) > 0;
    }
}
