function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class CachedFilterRunner {
  constructor(db, cache) { this.db = db; this.cache = cache; }
  async run(ctx, filterKey) {
    const cached = await this.cache.get("filter:" + filterKey);
    const fragment = cached ? cached.filterSql : "1=1";
    const sql = `SELECT id,email FROM users WHERE tenant_id=? AND ${fragment}`;
    return this.db.all(sql, [ctx.tenantId]);
  }
}
module.exports = CachedFilterRunner;
