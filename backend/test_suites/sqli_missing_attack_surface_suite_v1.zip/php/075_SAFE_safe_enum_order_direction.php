<?php
final class Repo { private array $cols=["created"=>"created_at","email"=>"email"]; private array $dirs=["asc"=>"ASC","desc"=>"DESC"];
  public function __construct(private PDO $pdo) {}
  public function run(array $q): array { $col=$this->cols[$q["sort"]??"created"]??"created_at"; $dir=$this->dirs[strtolower((string)($q["dir"]??"asc"))]??"ASC"; $s=$this->pdo->prepare("SELECT id,email FROM users ORDER BY ".$col." ".$dir); $s->execute(); return $s->fetchAll(PDO::FETCH_ASSOC); }
}
