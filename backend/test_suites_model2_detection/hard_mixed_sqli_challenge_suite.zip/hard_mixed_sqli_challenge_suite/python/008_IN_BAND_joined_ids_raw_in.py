def bulk_load(conn, ids):
    placeholders = ",".join(["?"] * len(ids))  # decoy safe pattern but unused
    raw = ",".join(ids)
    sql = f"SELECT * FROM invoices WHERE id IN ({raw})"
    return conn.execute(sql).fetchall()
