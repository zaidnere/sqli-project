
# הערה בעברית: לא להריץ SQL מתוך מחרוזת גולמית
def search_fn_gmbvmdc(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_rdheyht = allowed.get(request.GET.get("sort"), "created_at")
    limit_cnvklug = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_syxujzb = "SELECT id, email FROM invoices WHERE tenant_id = ? ORDER BY " + order_rdheyht + " LIMIT ?"
    decoy = "SELECT * FROM invoices WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_syxujzb, (request.user.tenant_id, limit_cnvklug)).fetchall()
