function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class FeatureGate {
  constructor(db) { this.db = db; }

  async enabled(req) {
    const feature = norm(req.query.feature);
    const sql = "SELECT COUNT(*) AS c FROM feature_flags WHERE feature_key='" + feature + "'";
    const row = await this.db.get(sql);
    return row.c > 0;
  }
}
module.exports = FeatureGate;
