
# safe path uses parameters, unsafe path should be detected
def search_fn_arlrkcl(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_xbqogmv = allowed.get(request.GET.get("sort"), "created_at")
    limit_oaxovdb = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_uqgksaa = "SELECT id, email FROM users WHERE tenant_id = ? ORDER BY " + order_xbqogmv + " LIMIT ?"
    decoy = "SELECT * FROM users WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_uqgksaa, (request.user.tenant_id, limit_oaxovdb)).fetchall()
