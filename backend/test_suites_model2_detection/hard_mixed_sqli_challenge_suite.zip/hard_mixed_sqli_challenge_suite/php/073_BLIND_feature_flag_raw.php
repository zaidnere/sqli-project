<?php
function isFeatureEnabled($pdo, $userId, $flag) {
    $sql = "SELECT 1 FROM flags WHERE user_id=$userId AND name='$flag'";
    return $pdo->query($sql)->fetch() !== false;
}
?>
