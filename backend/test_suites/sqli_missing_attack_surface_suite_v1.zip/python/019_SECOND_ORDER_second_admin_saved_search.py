class Repo:
    def __init__(self, db): self.db = db
    def run(self, req):
        row = self.db.execute("SELECT condition_sql FROM admin_saved_searches WHERE id=?", [req.args.get("id")]).fetchone()
        fragment = row["condition_sql"]
        return self.db.execute("SELECT id,email FROM users WHERE " + fragment).fetchall()
