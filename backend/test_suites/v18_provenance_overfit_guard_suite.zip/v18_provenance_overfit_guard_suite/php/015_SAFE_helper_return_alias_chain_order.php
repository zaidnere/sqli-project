<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

function allowed_sort_column($raw): string {
    $map = ["created" => "created_at", "email" => "email", "status" => "status"];
    return $map[norm($raw)] ?? "created_at";
}

final class SafeHelperReturnAliasChainOrder {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function list(array $q): array {
        $fromHelper = allowed_sort_column($q["sort"] ?? "created");
        $orderColumn = $fromHelper;
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? ORDER BY " . $orderColumn);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
