function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }

class SafeObjectMapOrder {
  constructor(db) { this.db = db; }
  async list(req) {
    const columns = { created: "created_at", email: "email", name: "display_name" };
    const col = columns[norm(req.query.sort)] || "created_at";
    const sql = `SELECT id,email FROM users WHERE tenant_id=? ORDER BY ${col}`;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = SafeObjectMapOrder;
