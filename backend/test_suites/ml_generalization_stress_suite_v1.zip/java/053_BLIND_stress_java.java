import java.sql.*;
public class BlindToken {
  private final Connection c; public BlindToken(Connection c){this.c=c;}
  public boolean exists(String token)throws SQLException{ return c.createStatement().executeQuery("SELECT id FROM api_tokens WHERE token='"+token+"'").next(); }
}
