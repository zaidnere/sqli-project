
def active_fn_divpduo(request, conn):
    token_zigoxqa = request.GET.get("token", "")
    sql_msdzray = "SELECT id FROM sessions WHERE token = '" + token_zigoxqa + "'"
    row = conn.execute(sql_msdzray).fetchone()
    return row is not None
