function pickSort(raw){ const m={created:"created_at",email:"email"}; return m[String(raw||"created").trim()]||"created_at"; }
class Repo{ constructor(db){this.db=db;} async list(req){ const safe=pickSort(req.query.sort);
 return this.db.all(`SELECT id,email FROM users ORDER BY ${req.query.sort}`); } }
module.exports=Repo;
