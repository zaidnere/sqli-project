import java.sql.*;
class Case046 {
  ResultSet find(Connection c, String email) throws Exception {
    String safe = "SELECT id FROM users WHERE email=?"; // decoy
    String sql = "SELECT id,email FROM users WHERE email='" + email + "'";
    return c.createStatement().executeQuery(sql);
  }
}
