<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class LoginGateway {
    private mysqli $db; public function __construct(mysqli $db) { $this->db = $db; }
    public function authenticate(array $ctx, string $email, string $hash): bool {
        $sql = "SELECT id FROM users WHERE tenant_id = '" . $ctx["tenant"] . "' AND email = '" . $email . "' AND password_hash = '" . $hash . "'";
        $result = $this->db->query($sql); return $result && $result->num_rows > 0;
    }
}
