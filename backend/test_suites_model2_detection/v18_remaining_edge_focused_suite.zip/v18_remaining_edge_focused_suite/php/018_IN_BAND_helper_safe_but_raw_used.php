<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

function pick_safe_sort($raw): string {
    $allowed = ["created" => "created_at", "email" => "email"];
    return $allowed[norm($raw)] ?? "created_at";
}
final class UnsafeHelperRawUsed {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function list(array $q): array {
        $safe = pick_safe_sort($q["sort"] ?? "created");
        $raw = norm($q["sort"] ?? "");
        $stmt = $this->pdo->query("SELECT id,email FROM users ORDER BY " . $raw);
        return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}
