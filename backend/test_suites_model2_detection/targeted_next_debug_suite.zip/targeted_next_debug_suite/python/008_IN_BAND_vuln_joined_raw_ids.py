import sqlite3
def get_orders(conn, ids):
    csv_ids = ",".join(ids)
    sql = "SELECT id, total FROM orders WHERE id IN (" + csv_ids + ")"
    cur = conn.cursor()
    cur.execute(sql)
    return cur.fetchall()
