function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class RealDbLoadedFragmentPropertyChain {
  constructor(db) { this.db = db; }

  async loadSavedSegment(ctx, segmentId) {
    const row = await this.db.get(
      "SELECT sql_fragment FROM saved_segments WHERE tenant_id=? AND id=?",
      [ctx.tenantId, toInt(segmentId)]
    );
    return { meta: { sqlFragment: row ? row.sql_fragment : "1=1" } };
  }

  async run(ctx, segmentId) {
    const savedSegment = await this.loadSavedSegment(ctx, segmentId);
    const fragment = savedSegment.meta.sqlFragment;
    const sql = "SELECT id,email FROM users WHERE tenant_id=? AND " + fragment;
    return this.db.all(sql, [ctx.tenantId]);
  }
}
module.exports = RealDbLoadedFragmentPropertyChain;
