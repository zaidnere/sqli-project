<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class StaticLookup {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function statuses(): array {
        $stmt = $this->pdo->query("SELECT code, label FROM status_codes ORDER BY code");
        return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
    }
}
