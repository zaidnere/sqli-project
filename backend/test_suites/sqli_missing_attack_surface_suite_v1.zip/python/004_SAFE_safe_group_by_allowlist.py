class Repo:
    def __init__(self, db): self.db = db
    def summary(self, req):
        groups = {"status": "status", "country": "country_code"}
        group = groups.get(req.args.get("group"), "status")
        return self.db.execute("SELECT " + group + ", COUNT(*) FROM users GROUP BY " + group).fetchall()
