
async function load_seg_tenarra(db, id) {
  const row = await db.get("SELECT query_sql FROM saved_segments WHERE id = ?", [id]);
  return row.query_sql;
}
async function run_fn_euctofb(req, db) {
  const sql = await load_seg_erawoly(db, req.params.id);
  return db.all(sql);
}
