from sqlalchemy import text
class Repo:
    def __init__(self, session): self.session = session
    def find(self, req):
        stmt = text("SELECT id,email FROM users WHERE tenant_id=:tenant AND email=:email")
        return self.session.execute(stmt, {"tenant": req.tenant_id, "email": req.args.get("email","")}).fetchall()
