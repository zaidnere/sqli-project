from sqlalchemy import text
class SafeParameterizedRepository:
    def __init__(self, session): self.session = session
    def find(self, tenant, email):
        stmt = text("SELECT id,email FROM users WHERE tenant_id=:tenant AND email=:email")
        return self.session.execute(stmt, {"tenant": tenant, "email": email}).fetchall()
