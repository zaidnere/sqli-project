function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class UnsafeOrder {
  constructor(db) { this.db = db; }

  async list(req) {
    const order = norm(req.query.order);
    const sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + order;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = UnsafeOrder;
