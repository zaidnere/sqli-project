<?php
final class CaseRepo {
  private array $cols = ["created"=>"created_at","email"=>"email","status"=>"status"];
  public function __construct(private PDO $pdo) {}
  public function run(array $q): array {
    $selected = $this->cols[trim((string)($q["sort"] ?? "created"))] ?? "created_at";
    $final = $selected;
    $stmt = $this->pdo->prepare("SELECT id,email FROM users ORDER BY " . $final);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
}
