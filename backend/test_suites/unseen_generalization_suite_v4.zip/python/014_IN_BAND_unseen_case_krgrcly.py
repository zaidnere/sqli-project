
# safe path uses parameters, unsafe path should be detected
def lookup_fn_otafkws(request, conn):
    email_ehnmsgq = request.GET.get("email", "")
    sql_ckahgsf = "SELECT * FROM users WHERE email = '" + email_ehnmsgq + "'"
    return conn.execute(sql_ckahgsf).fetchall()
