class Report{ constructor(db,cache){this.db=db;this.cache=cache;} async run(req){ const c=await this.cache.get("filter:"+req.query.filterId);
 const frag=c?c.filterSql:"1=1"; return this.db.all("SELECT id FROM users WHERE tenant_id=? AND "+frag,[req.user.tenantId]); } }
module.exports=Report;
