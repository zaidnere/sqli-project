
# noise comment with SQL_CONCAT looking words but no sink
def search_fn_cadljda(request, conn):
    allowed = {"created": "created_at", "email": "email", "name": "name"}
    order_yobhkcj = allowed.get(request.GET.get("sort"), "created_at")
    limit_ybfkdmi = min(max(int(request.GET.get("limit", 25)), 1), 100)
    q_hqhryuv = "SELECT id, email FROM reports WHERE tenant_id = ? ORDER BY " + order_yobhkcj + " LIMIT ?"
    decoy = "SELECT * FROM reports WHERE email = " + request.GET.get("email", "")
    return conn.execute(q_hqhryuv, (request.user.tenant_id, limit_ybfkdmi)).fetchall()
