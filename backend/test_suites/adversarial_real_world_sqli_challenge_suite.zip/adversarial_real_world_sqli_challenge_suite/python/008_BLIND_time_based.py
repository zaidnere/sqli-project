def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*args): pass

class Probe:
    def __init__(self, conn): self.conn = conn
    def run(self, args):
        token = norm(args.get("token"))
        sql = "SELECT CASE WHEN token='" + token + "' THEN pg_sleep(5) ELSE 0 END FROM tokens"
        self.conn.execute(sql)
        return True
