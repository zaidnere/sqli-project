async function runSegment(db, segmentId) {
  const row = await db.get("SELECT where_clause FROM saved_segments WHERE id = ?", [segmentId]);
  const sql = "SELECT id,email FROM users WHERE " + row.where_clause;
  return db.all(sql);
}
