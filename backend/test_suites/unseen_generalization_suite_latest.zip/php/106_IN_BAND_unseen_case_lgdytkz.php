<?php
function search_fn_dhutlox($mysqli) {
    $email = $_GET["email"] ?? "";
    $sql = "SELECT * FROM users WHERE email='" . $email . "'";
    return mysqli_query($mysqli, $sql);
}
?>