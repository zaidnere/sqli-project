<?php
final class Flags { public function __construct(private mysqli $db) {} public function enabled(array $q): bool { $f=trim((string)($q["feature"]??"")); $r=$this->db->query("SELECT id FROM feature_flags WHERE feature_key='".$f."'"); return $r && $r->num_rows>0; } }
