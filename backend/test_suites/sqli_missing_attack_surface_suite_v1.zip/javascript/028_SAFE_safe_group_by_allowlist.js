class Repo { constructor(db){this.db=db;} summary(req){ const m={status:"status",country:"country_code"}; const g=m[String(req.query.group||"status")]||"status"; return this.db.all("SELECT "+g+", COUNT(*) FROM users GROUP BY "+g); } }
module.exports = Repo;
