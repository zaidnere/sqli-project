package com.enterprise.security.sqli.finalsuite;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

class RequestContext {
    final String tenantId;
    final String actorId;
    final String requestId;
    RequestContext(String tenantId, String actorId, String requestId) {
        this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId;
    }
}
class AuditLogger {
    void info(RequestContext ctx, String action, Map<String, Object> details) {
        System.out.println(Instant.now() + " tenant=" + ctx.tenantId + " action=" + action + " details=" + details);
    }
}
class InputUtil {
    static String clean(String value) { return value == null ? "" : value.trim(); }
    static int clampInt(String value, int low, int high, int fallback) {
        try { return Math.max(low, Math.min(high, Integer.parseInt(value))); }
        catch (Exception ex) { return fallback; }
    }
}

public class SafeDepartmentRepository {
    private final Connection connection;
    public SafeDepartmentRepository(Connection connection) { this.connection = connection; }
    String department(RequestContext ctx, long userId) throws Exception { PreparedStatement ps = connection.prepareStatement("SELECT department_code FROM users WHERE tenant_id = ? AND id = ?"); ps.setString(1, ctx.tenantId); ps.setLong(2, userId); ResultSet rs = ps.executeQuery(); return rs.next() ? rs.getString("department_code") : ""; }
    public ResultSet orders(RequestContext ctx, long userId) throws Exception { String dept = department(ctx, userId); PreparedStatement ps = connection.prepareStatement("SELECT id, order_no FROM orders WHERE tenant_id = ? AND department_code = ?"); ps.setString(1, ctx.tenantId); ps.setString(2, dept); return ps.executeQuery(); }
}
