function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class SafeConfigValueParam {
  constructor(db, configService) { this.db = db; this.configService = configService; }

  async list(ctx) {
    const cfg = await this.configService.load(ctx.tenantId);
    const status = cfg && cfg.defaultStatus ? cfg.defaultStatus : "ACTIVE";
    return this.db.all(
      "SELECT id,email FROM users WHERE tenant_id=? AND status=?",
      [ctx.tenantId, status]
    );
  }
}
module.exports = SafeConfigValueParam;
