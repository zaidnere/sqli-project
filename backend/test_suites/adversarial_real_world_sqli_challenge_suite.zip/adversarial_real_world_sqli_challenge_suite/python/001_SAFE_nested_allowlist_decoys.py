def norm(v): return "" if v is None else str(v).strip()
def clamp(v, lo, hi):
    try: n = int(v)
    except Exception: n = lo
    return max(lo, min(hi, n))
def audit(*args): pass

class Repo:
    SORTS = {"created":"created_at","email":"email"}
    def __init__(self, conn): self.conn = conn
    def pick(self, raw): return self.SORTS.get(norm(raw), "created_at")
    def list(self, args):
        decoy = norm(args.get("where"))
        sort = self.pick(args.get("sort"))
        limit = clamp(args.get("limit",50),1,100)
        sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY " + sort + f" LIMIT {limit}"
        audit(decoy)
        return self.conn.execute(sql, [args["tenant"]]).fetchall()
