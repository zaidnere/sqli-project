
def active_fn_filouxd(request, conn):
    token_wnngtge = request.GET.get("token", "")
    sql_pelmsiq = "SELECT id FROM sessions WHERE token = '" + token_wnngtge + "'"
    row = conn.execute(sql_pelmsiq).fetchone()
    return row is not None
