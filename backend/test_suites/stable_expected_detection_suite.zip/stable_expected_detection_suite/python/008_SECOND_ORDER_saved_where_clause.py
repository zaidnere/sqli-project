def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class SavedReportRunner:
    def __init__(self, conn):
        self.conn = conn

    def load_where_clause(self, request):
        row = self.conn.execute(
            "SELECT where_clause FROM saved_reports WHERE tenant_id=? AND report_id=?",
            [request["tenant"], to_int(request.get("report_id"))]
        ).fetchone()
        return row["where_clause"] if row else "1=1"

    def run_report(self, request):
        where_clause = self.load_where_clause(request)
        sql = "SELECT id,email FROM customers WHERE tenant_id=? AND " + where_clause
        return self.conn.execute(sql, [request["tenant"]]).fetchall()
