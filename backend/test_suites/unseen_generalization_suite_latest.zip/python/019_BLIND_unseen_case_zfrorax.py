
def active_fn_xzrdfja(request, conn):
    token_xdmtalp = request.GET.get("token", "")
    sql_snrzszu = "SELECT id FROM sessions WHERE token = '" + token_xdmtalp + "'"
    row = conn.execute(sql_snrzszu).fetchone()
    return row is not None
