class Repo{constructor(db){this.db=db;} report(req){const t=String(req.query.join||""); return this.db.all("SELECT u.id FROM users u JOIN "+t+" x ON x.user_id=u.id");}} module.exports=Repo;
