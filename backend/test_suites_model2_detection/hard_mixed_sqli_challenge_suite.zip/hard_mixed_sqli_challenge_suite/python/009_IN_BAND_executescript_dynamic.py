def dangerous_purge(conn, table):
    script = f"DELETE FROM {table}; VACUUM;"
    return conn.executescript(script)
