<?php
final class Ping { public function __construct(private mysqli $db) {} public function ping(array $q): bool { $m=trim((string)($q["marker"]??"")); $this->db->query("SELECT IF('".$m."'='slow', SLEEP(3), 1)"); return true; } }
