function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class AccountRepository {
  constructor(db) { this.db = db; }

  async find(req) {
    const sql = "SELECT id, account_no FROM accounts WHERE tenant_id=? AND id=?";
    return this.db.get(sql, [req.tenantId, toInt(req.params.id)]);
  }
}
module.exports = AccountRepository;
