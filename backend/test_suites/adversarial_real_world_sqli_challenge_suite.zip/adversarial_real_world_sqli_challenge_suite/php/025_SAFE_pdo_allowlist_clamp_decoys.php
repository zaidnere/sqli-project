<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class Repo {
    private PDO $pdo;
    private array $sorts = ["created"=>"created_at","email"=>"email"];
    public function __construct(PDO $pdo){ $this->pdo = $pdo; }
    public function list(array $q): array {
        $decoy = norm($q["where"] ?? "");
        $sort = $this->sorts[norm($q["sort"] ?? "created")] ?? "created_at";
        $limit = clamp_int($q["limit"] ?? 50, 1, 100);
        $sql = "SELECT id,email FROM users WHERE tenant_id=? ORDER BY {$sort} DESC LIMIT {$limit}";
        audit_event("decoy", ["where" => $decoy !== ""]);
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$q["tenant"]]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
