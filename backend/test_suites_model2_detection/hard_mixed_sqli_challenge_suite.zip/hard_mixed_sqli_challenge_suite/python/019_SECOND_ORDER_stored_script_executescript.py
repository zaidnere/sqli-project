def execute_admin_macro(conn, macro_id):
    row = conn.execute("SELECT sql_script FROM admin_macros WHERE id=?", (macro_id,)).fetchone()
    script = row[0]
    return conn.executescript(script)
