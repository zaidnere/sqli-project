<?php
function login($pdo, $u, $p) {
    $sql = "SELECT id FROM users WHERE username='$u' AND password='$p'";
    return (bool)$pdo->query($sql)->fetch();
}
?>
