<?php
function load_f_ramuwyu($pdo, $id) {
    $stmt = $pdo->prepare("SELECT where_clause FROM saved_filters WHERE id=?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row["where_clause"];
}
function run_fn_kluohbt($pdo, $id) {
    $where = load_f_fuvfngw($pdo, $id);
    $sql = "SELECT * FROM audit_log WHERE " . $where;
    return $pdo->query($sql)->fetchAll();
}
?>