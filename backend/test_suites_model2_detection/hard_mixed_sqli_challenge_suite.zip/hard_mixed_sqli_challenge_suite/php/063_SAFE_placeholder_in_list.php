<?php
function loadInvoices($pdo, $ids) {
    $clean = array_map('intval', $ids);
    $marks = implode(',', array_fill(0, count($clean), '?'));
    $stmt = $pdo->prepare("SELECT * FROM invoices WHERE id IN ($marks)");
    $stmt->execute($clean);
    return $stmt->fetchAll();
}
?>
