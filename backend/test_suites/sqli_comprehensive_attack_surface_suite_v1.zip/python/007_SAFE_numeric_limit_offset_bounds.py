def clamp_int(v, lo, hi, default):
    try: n = int(v)
    except Exception: return default
    return min(max(n, lo), hi)

class SafePagingRepository:
    def __init__(self, db): self.db = db
    def page(self, req):
        limit = clamp_int(req.args.get("limit"), 1, 100, 25)
        offset = clamp_int(req.args.get("offset"), 0, 10000, 0)
        return self.db.execute("SELECT id,email FROM users LIMIT ? OFFSET ?", [limit, offset]).fetchall()
