
# safe path uses parameters, unsafe path should be detected
def lookup_fn_ulimyxu(request, conn):
    email_ykplvcy = request.GET.get("email", "")
    sql_gzbwhzg = "SELECT * FROM users WHERE email = '" + email_ykplvcy + "'"
    return conn.execute(sql_gzbwhzg).fetchall()
