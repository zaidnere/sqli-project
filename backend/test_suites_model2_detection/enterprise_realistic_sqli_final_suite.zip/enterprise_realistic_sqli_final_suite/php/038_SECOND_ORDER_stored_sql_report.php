<?php
declare(strict_types=1);

function normalize_text($value): string {
    if ($value === null) return "";
    return trim((string)$value);
}
function clamp_int($value, int $low, int $high, int $fallback): int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) $n = $fallback;
    return max($low, min($high, $n));
}
function audit_event(array $ctx, string $action, array $details): void {
    error_log(json_encode([
        "tenant" => $ctx["tenant"] ?? "",
        "actor" => $ctx["actor"] ?? "",
        "request" => $ctx["request"] ?? "",
        "action" => $action,
        "details" => $details
    ]));
}

final class StoredSqlReportRunner {
    private PDO $pdo; public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function loadSql(array $ctx, string $key): string { $stmt = $this->pdo->prepare("SELECT sql_body FROM report_definitions WHERE tenant_id = ? AND report_key = ?"); $stmt->execute([$ctx["tenant"], $key]); $row = $stmt->fetch(PDO::FETCH_ASSOC); return $row["sql_body"] ?? ""; }
    public function run(array $ctx, string $key): array { $sql = $this->loadSql($ctx, $key); $stmt = $this->pdo->query($sql); return $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : []; }
}
