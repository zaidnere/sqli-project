class Report:
    def __init__(self, db, cache): self.db = db; self.cache = cache
    def list(self, tenant):
        cfg = self.cache.get("order:" + str(tenant)) or {}
        order_sql = cfg.get("order_sql", "created_at DESC")
        return self.db.execute("SELECT id FROM users WHERE tenant_id=? ORDER BY " + order_sql, [tenant]).fetchall()
