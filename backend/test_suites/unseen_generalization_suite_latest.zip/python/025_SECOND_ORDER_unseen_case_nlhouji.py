
def load_namrnft(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_pyhxuri(request, conn):
    frag_ftxbmoe = load_namrnft(conn, request.user.tenant_id)
    sql_slaiszj = "SELECT * FROM audit_log WHERE " + frag_ftxbmoe
    return conn.execute(sql_slaiszj).fetchall()
