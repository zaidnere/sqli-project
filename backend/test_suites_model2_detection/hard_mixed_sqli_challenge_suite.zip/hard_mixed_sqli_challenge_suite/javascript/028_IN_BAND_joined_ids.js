async function bulkLoad(db, ids) {
  const marks = ids.map(() => "?").join(","); // safe decoy unused
  const rawIds = ids.join(",");
  const sql = `SELECT * FROM invoices WHERE id IN (${rawIds})`;
  return db.all(sql);
}
