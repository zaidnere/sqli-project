function norm(v){ return v===undefined || v===null ? "" : String(v).trim(); }
function clamp(v,lo,hi){ const n=Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi,n)) : lo; }
function audit(){}

class DirectTemplate {
  constructor(db) { this.db = db; }
  async search(req) {
    const storedSegment = norm(req.query.q);
    const sql = `SELECT id,email FROM users WHERE email LIKE '%${storedSegment}%'`;
    return this.db.all(sql);
  }
}
module.exports = DirectTemplate;
