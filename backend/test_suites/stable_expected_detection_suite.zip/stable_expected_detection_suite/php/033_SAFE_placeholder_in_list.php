<?php
declare(strict_types=1);

function norm($v): string {
    return $v === null ? "" : trim((string)$v);
}
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class BulkSafeLookup {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function load(array $q): array {
        $ids = array_values(array_filter(array_map("intval", $q["ids"] ?? []), fn($id) => $id > 0));
        if (!$ids) {
            return [];
        }
        $ph = implode(",", array_fill(0, count($ids), "?"));
        $params = array_merge([$q["tenant"]], $ids);
        $stmt = $this->pdo->prepare("SELECT id,email FROM users WHERE tenant_id=? AND id IN ($ph)");
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
