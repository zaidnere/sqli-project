function norm(v){ return v === undefined || v === null ? "" : String(v).trim(); }
function clamp(v, lo, hi){ const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function audit(){ }

class Runner {
  constructor(db, cache){ this.db=db; this.cache=cache; }
  async load(ctx, key){
    let order = await this.cache.get(`${ctx.tenant}:${key}:order`);
    if(!order){
      const row = await this.db.get("SELECT order_clause FROM widgets WHERE tenant_id=? AND k=?", [ctx.tenant, key]);
      order = row ? row.order_clause : "created_at DESC";
    }
    return order;
  }
  async list(ctx, key){
    const order = await this.load(ctx, key);
    return this.db.all("SELECT id FROM widget_rows WHERE tenant_id=? ORDER BY " + order, [ctx.tenant]);
  }
}
module.exports = Runner;
