function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function safeSortColumn(rawSort) {
  const m = { created: "created_at", email: "email", status: "status" };
  return m[norm(rawSort)] || "created_at";
}

class UnsafeHelperCalledButRequestUsed {
  constructor(db) { this.db = db; }

  async list(req) {
    const safe = safeSortColumn(req.query.sort);
    const sql = `SELECT id,email FROM users WHERE tenant_id=? ORDER BY ${req.query.sort}`;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = UnsafeHelperCalledButRequestUsed;
