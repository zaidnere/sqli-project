<?php
function findUser($mysqli, $email) {
    $sql = "SELECT id,email FROM users WHERE email='" . $email . "'";
    return $mysqli->query($sql);
}
?>
