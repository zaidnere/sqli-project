function norm(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class RequestConfigWhereClauseRaw {
  constructor(db) { this.db = db; }

  async run(req) {
    const configWhereClause = norm(req.query.configWhereClause);
    const sql = "SELECT id,email FROM users WHERE tenant_id=? AND " + configWhereClause;
    return this.db.all(sql, [req.tenantId]);
  }
}
module.exports = RequestConfigWhereClauseRaw;
