function pickColumn(raw){ const m={created:"created_at",email:"email",status:"status"}; return {column:m[String(raw||"created").trim()]||"created_at"}; }
class Repo{ constructor(db){this.db=db;} async list(req){ const info=pickColumn(req.query.sort); const finalColumn=info.column; return this.db.all("SELECT id,email FROM users WHERE tenant_id=? ORDER BY "+finalColumn,[req.user.tenantId]); } }
module.exports=Repo;
