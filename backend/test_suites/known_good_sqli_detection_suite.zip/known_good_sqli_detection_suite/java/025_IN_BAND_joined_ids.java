import java.sql.*;
import java.util.*;

class Ctx {
    String tenantId;
    String actorId;
    Ctx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class JoinedIds {
    private final Connection c;
    public JoinedIds(Connection c) { this.c = c; }

    public ResultSet load(Ctx ctx, List<String> ids) throws Exception {
        String joined = String.join(",", ids);
        String sql = "SELECT id,email FROM users WHERE tenant_id='" + ctx.tenantId + "' AND id IN (" + joined + ")";
        return c.createStatement().executeQuery(sql);
    }
}
