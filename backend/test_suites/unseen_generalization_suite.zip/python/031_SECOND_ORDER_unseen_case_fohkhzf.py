
def load_urwerqh(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_nplecae(request, conn):
    frag_cizyxjq = load_urwerqh(conn, request.user.tenant_id)
    sql_ilhusrw = "SELECT * FROM audit_log WHERE " + frag_cizyxjq
    return conn.execute(sql_ilhusrw).fetchall()
