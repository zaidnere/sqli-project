import java.sql.*;
public class UnsafeTable {
  private final Connection c; public UnsafeTable(Connection c){this.c=c;}
  public ResultSet export(String table)throws SQLException{ return c.createStatement().executeQuery("SELECT * FROM "+table); }
}
