
# decoy: SELECT * FROM users WHERE id = raw_input
def lookup_fn_fhfmhve(request, conn):
    email_xqpejlg = request.GET.get("email", "")
    sql_ebqvunu = "SELECT * FROM users WHERE email = '" + email_xqpejlg + "'"
    return conn.execute(sql_ebqvunu).fetchall()
