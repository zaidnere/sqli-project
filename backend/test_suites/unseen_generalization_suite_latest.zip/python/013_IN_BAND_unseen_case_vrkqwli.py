
# decoy: SELECT * FROM users WHERE id = raw_input
def lookup_fn_sknepgg(request, conn):
    email_woqbgmh = request.GET.get("email", "")
    sql_fcyqopd = "SELECT * FROM users WHERE email = '" + email_woqbgmh + "'"
    return conn.execute(sql_fcyqopd).fetchall()
