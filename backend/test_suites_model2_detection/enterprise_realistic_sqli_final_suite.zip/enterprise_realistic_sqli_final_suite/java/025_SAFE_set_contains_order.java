package com.enterprise.security.sqli.finalsuite;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

class RequestContext {
    final String tenantId;
    final String actorId;
    final String requestId;
    RequestContext(String tenantId, String actorId, String requestId) {
        this.tenantId = tenantId; this.actorId = actorId; this.requestId = requestId;
    }
}
class AuditLogger {
    void info(RequestContext ctx, String action, Map<String, Object> details) {
        System.out.println(Instant.now() + " tenant=" + ctx.tenantId + " action=" + action + " details=" + details);
    }
}
class InputUtil {
    static String clean(String value) { return value == null ? "" : value.trim(); }
    static int clampInt(String value, int low, int high, int fallback) {
        try { return Math.max(low, Math.min(high, Integer.parseInt(value))); }
        catch (Exception ex) { return fallback; }
    }
}

public class SafeProductRepository {
    private final Connection connection; private static final Set<String> SORTS = new HashSet<>(Arrays.asList("name", "sku", "created_at"));
    public SafeProductRepository(Connection connection) { this.connection = connection; }
    public ResultSet list(RequestContext ctx, String sort, String category) throws Exception {
        String order = SORTS.contains(sort) ? sort : "name";
        String sql = "SELECT id, sku, name FROM products WHERE tenant_id = ? AND category = ? ORDER BY " + order;
        PreparedStatement ps = connection.prepareStatement(sql); ps.setString(1, ctx.tenantId); ps.setString(2, category); return ps.executeQuery();
    }
}
