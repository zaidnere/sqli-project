class Repo:
    def __init__(self, db, cache): self.db = db; self.cache = cache
    def list(self, tenant):
        policy = self.cache.get("tenant-policy:" + str(tenant))
        fragment = policy["sql_condition"]
        return self.db.execute("SELECT id,email FROM users WHERE tenant_id=? AND " + fragment, [tenant]).fetchall()
