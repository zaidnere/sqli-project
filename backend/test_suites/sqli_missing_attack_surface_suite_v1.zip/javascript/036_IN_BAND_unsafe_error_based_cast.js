class Repo{constructor(db){this.db=db;} probe(req){const v=String(req.query.value||""); return this.db.all("SELECT CAST('"+v+"' AS INT)");}} module.exports=Repo;
