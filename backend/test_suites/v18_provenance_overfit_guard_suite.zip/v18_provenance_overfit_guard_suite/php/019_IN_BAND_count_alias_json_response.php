<?php
declare(strict_types=1);

function norm($v): string { return $v === null ? "" : trim((string)$v); }
function to_int($v, int $default = 0): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    return $n === false ? $default : (int)$n;
}

final class InBandCountAliasJsonResponse {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }

    public function countByStatus(array $q): array {
        $status = norm($q["status"] ?? "");
        $res = $this->db->query("SELECT COUNT(*) AS c FROM orders WHERE status='" . $status . "'");
        $row = $res ? $res->fetch_assoc() : ["c" => 0];
        return ["ok" => true, "count" => (int)$row["c"]];
    }
}
