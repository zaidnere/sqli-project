class Repo:
    def __init__(self, db): self.db = db
    def list(self, req):
        cols = {"created": "created_at", "email": "email"}
        dirs = {"asc": "ASC", "desc": "DESC"}
        col = cols.get(req.args.get("sort"), "created_at")
        direction = dirs.get(str(req.args.get("dir","asc")).lower(), "ASC")
        return self.db.execute("SELECT id,email FROM users ORDER BY " + col + " " + direction).fetchall()
