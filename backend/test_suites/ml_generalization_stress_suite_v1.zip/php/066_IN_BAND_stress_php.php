<?php
final class Repo { public function __construct(private mysqli $db) {} public function search(array $q): array { $email=trim((string)($q["email"]??"")); $r=$this->db->query("SELECT id FROM users WHERE email LIKE '%".$email."%'"); return $r?$r->fetch_all(MYSQLI_ASSOC):[]; } }
