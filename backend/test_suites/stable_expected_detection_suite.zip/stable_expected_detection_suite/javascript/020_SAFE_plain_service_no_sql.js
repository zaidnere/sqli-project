function norm(v) {
  return v === undefined || v === null ? "" : String(v).trim();
}
function toInt(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

class HealthService {
  status() {
    const now = new Date().toISOString();
    return { ok: true, at: now };
  }
}
module.exports = HealthService;
