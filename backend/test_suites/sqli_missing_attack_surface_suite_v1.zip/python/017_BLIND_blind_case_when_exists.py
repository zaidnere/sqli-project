class Check:
    def __init__(self, db): self.db = db
    def allowed(self, req):
        key = req.args.get("key","")
        row = self.db.execute("SELECT CASE WHEN EXISTS(SELECT 1 FROM permissions WHERE resource_key='" + key + "') THEN 1 ELSE 0 END AS ok").fetchone()
        return row["ok"] == 1
