import java.sql.*;
public class Case {
  private final Connection c; private final ConfigService svc;
  public Case(Connection c, ConfigService svc){this.c=c;this.svc=svc;}
  public ResultSet run(String id)throws SQLException{
    Config cfg=svc.load(id); String fragment=cfg.whereClause;
    return c.createStatement().executeQuery("SELECT id,email FROM users WHERE "+fragment);
  }
  interface ConfigService{ Config load(String id); }
  static class Config{ String whereClause; String orderClause; }
}
