async function listArticles(db, page, pageSize) {
  const safePage = Math.max(1, Number(page));
  const safeSize = Math.min(100, Math.max(1, Number(pageSize)));
  const offset = (safePage - 1) * safeSize;
  const sql = `SELECT id, title FROM articles ORDER BY created_at DESC LIMIT ${safeSize} OFFSET ${offset}`;
  return db.all(sql);
}
module.exports = { listArticles };
