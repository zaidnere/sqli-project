import java.sql.*;
import java.util.*;

class Ctx {
    String tenantId;
    String actorId;
    Ctx(String tenantId, String actorId) {
        this.tenantId = tenantId;
        this.actorId = actorId;
    }
}

public class SafePrepared {
    private final Connection c;
    public SafePrepared(Connection c) { this.c = c; }

    public ResultSet find(Ctx ctx, String email) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "SELECT id,email FROM users WHERE tenant_id=? AND email=?"
        );
        ps.setString(1, ctx.tenantId);
        ps.setString(2, email);
        return ps.executeQuery();
    }
}
