async function page(db, req) {
  const sql = `SELECT id FROM logs LIMIT ${req.query.limit} OFFSET ${req.query.offset}`;
  return db.all(sql);
}
