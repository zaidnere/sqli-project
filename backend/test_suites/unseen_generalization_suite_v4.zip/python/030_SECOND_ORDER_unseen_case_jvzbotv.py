
def load_xhlwmls(conn, tenant):
    row = conn.execute("SELECT where_clause FROM saved_filters WHERE tenant_id = ?", (tenant,)).fetchone()
    return row[0]

def run_fn_lhlrern(request, conn):
    frag_vuelqie = load_xhlwmls(conn, request.user.tenant_id)
    sql_qlvbwft = "SELECT * FROM audit_log WHERE " + frag_vuelqie
    return conn.execute(sql_qlvbwft).fetchall()
