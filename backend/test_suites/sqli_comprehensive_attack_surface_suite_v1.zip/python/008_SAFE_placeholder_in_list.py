class SafeInListRepository:
    def __init__(self, db): self.db = db
    def by_ids(self, ids):
        clean = [int(x) for x in ids if str(x).isdigit()]
        marks = ",".join(["?"] * len(clean))
        return self.db.execute(f"SELECT id,sku FROM inventory WHERE id IN ({marks})", clean).fetchall()
