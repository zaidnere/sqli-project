import java.sql.*;
public class Case {
  private final Connection c; public Case(Connection c){this.c=c;}
  public ResultSet run(String tenant,String email)throws SQLException{
    PreparedStatement ps=c.prepareStatement("SELECT id,email FROM users WHERE tenant_id=? AND email=?");
    ps.setString(1,tenant); ps.setString(2,email); return ps.executeQuery();
  }
}
