<?php
declare(strict_types=1);
function norm($v): string { return $v === null ? "" : trim((string)$v); }
function clamp_int($v, int $lo, int $hi): int {
    $n = filter_var($v, FILTER_VALIDATE_INT);
    if ($n === false) $n = $lo;
    return max($lo, min($hi, $n));
}
function audit_event(string $e, array $p): void { error_log($e . ":" . json_encode($p)); }

final class DirectMysqliCustomerSearch {
    private mysqli $db;
    public function __construct(mysqli $db) { $this->db = $db; }
    public function search(array $q): array {
        $email = norm($q["email"] ?? "");
        $sql = "SELECT id,email FROM customers WHERE email='" . $email . "'";
        $r = $this->db->query($sql);
        return $r ? $r->fetch_all(MYSQLI_ASSOC) : [];
    }
}
