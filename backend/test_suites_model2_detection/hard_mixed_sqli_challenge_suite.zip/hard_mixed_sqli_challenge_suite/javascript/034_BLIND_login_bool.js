async function login(db, username, password) {
  const sql = `SELECT id FROM users WHERE username='${username}' AND password='${password}'`;
  const row = await db.get(sql);
  return Boolean(row);
}
