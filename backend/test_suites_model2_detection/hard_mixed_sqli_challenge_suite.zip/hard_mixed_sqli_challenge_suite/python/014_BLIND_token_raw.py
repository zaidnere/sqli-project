def valid_reset_token(conn, token):
    query = f"SELECT id FROM reset_tokens WHERE token = '{token}' AND used = 0"
    return bool(conn.execute(query).fetchone())
