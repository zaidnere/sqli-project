<?php
function load_f_bjgwdxf($pdo, $id) {
    $stmt = $pdo->prepare("SELECT where_clause FROM saved_filters WHERE id=?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row["where_clause"];
}
function run_fn_wexkmns($pdo, $id) {
    $where = load_f_kdjygeq($pdo, $id);
    $sql = "SELECT * FROM audit_log WHERE " . $where;
    return $pdo->query($sql)->fetchAll();
}
?>