import java.sql.*;
class Case056 {
  ResultSet run(Connection c, int id) throws Exception {
    PreparedStatement p = c.prepareStatement("SELECT where_clause FROM saved_reports WHERE id=?");
    p.setInt(1, id);
    ResultSet r = p.executeQuery();
    r.next();
    String fragment = r.getString(1);
    String sql = "SELECT id,total FROM orders WHERE " + fragment;
    return c.createStatement().executeQuery(sql);
  }
}
