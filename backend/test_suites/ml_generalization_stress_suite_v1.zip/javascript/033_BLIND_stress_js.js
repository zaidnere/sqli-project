class Tokens{ constructor(db){this.db=db;} async verify(req){ const t=String(req.headers["x-token"]||"");
 const row=await this.db.get("SELECT id FROM api_tokens WHERE token='"+t+"'"); return !!row; } }
module.exports=Tokens;
