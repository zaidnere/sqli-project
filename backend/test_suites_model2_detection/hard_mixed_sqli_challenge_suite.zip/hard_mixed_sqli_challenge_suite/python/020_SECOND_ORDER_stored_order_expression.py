def list_with_saved_sort(conn, profile_id):
    row = conn.execute("SELECT sort_expression FROM profiles WHERE id=?", (profile_id,)).fetchone()
    sort_expression = row[0]
    sql = "SELECT id,name FROM customers ORDER BY " + sort_expression
    return conn.execute(sql).fetchall()
