def norm(v):
    return "" if v is None else str(v).strip()

def to_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

class SafeDbValue:
    def __init__(self, conn):
        self.conn = conn

    def load_department(self, request):
        row = self.conn.execute(
            "SELECT department_code FROM users WHERE tenant_id=? AND id=?",
            [request["tenant"], to_int(request.get("user_id"))]
        ).fetchone()
        return row["department_code"] if row else ""

    def list_orders(self, request):
        dept = self.load_department(request)
        return self.conn.execute(
            "SELECT id FROM orders WHERE tenant_id=? AND department_code=?",
            [request["tenant"], dept]
        ).fetchall()
