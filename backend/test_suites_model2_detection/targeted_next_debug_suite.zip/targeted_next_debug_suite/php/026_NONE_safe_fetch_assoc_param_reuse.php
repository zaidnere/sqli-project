<?php
function archiveBioSafe($conn, $userId) {
    $stmt = $conn->prepare("SELECT bio FROM profiles WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) return;

    $bio = "bio: " . $row["bio"];
    $out = $conn->prepare("INSERT INTO audit_log(message) VALUES (?)");
    $out->bind_param("s", $bio);
    $out->execute();
}
?>
