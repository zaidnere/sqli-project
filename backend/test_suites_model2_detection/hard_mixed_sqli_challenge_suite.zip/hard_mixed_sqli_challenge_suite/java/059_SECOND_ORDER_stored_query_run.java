import java.sql.*;
class Case059 {
  ResultSet runAdminQuery(Connection c, int id) throws Exception {
    PreparedStatement p = c.prepareStatement("SELECT sql_text FROM admin_queries WHERE id=?");
    p.setInt(1, id);
    ResultSet rs = p.executeQuery(); rs.next();
    return c.createStatement().executeQuery(rs.getString("sql_text"));
  }
}
